// Futaba 0.6.8 QA scenarios (the delta of the 0.6.8 CHANGELOG). Registered into scenarios.mjs by register(E); every scenario runs under the
// studio's owned-process supervisor, in a private QA root under BASE/tmp, with private ports. Nothing here installs, focuses or clicks a mouse.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import net from 'node:net';
import { spawn, spawnSync } from 'node:child_process';
import { registerMerge } from './merge068.mjs';
import { registerMore } from './more068.mjs';
import { registerC7 } from './c7_068.mjs';
import { launch, makeRoot, setupLibrary, waitFor, sleep, win, PY, SEVENZ, BASE, pidAlive, portRefused, runInfoForEvidence, EXTRACT } from './lib.mjs';

const RC = 'I:/AI Projects/Worktrees/Comics Meta Organizer/rc-069';
const ENGINE = EXTRACT + '/resources/engine';
const TOOL = RC + '/tools/nested_comicinfo_merge.py';
const HOLD = RC + '/tests/debug_hold.py';
const H = BASE + '/evidence/harness';
const sha256File = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const sha256Stream = f => new Promise((resolve, reject) => { const h = crypto.createHash('sha256'); fs.createReadStream(f).on('data', d => h.update(d)).on('end', () => resolve(h.digest('hex'))).on('error', reject); });

export function register(E) {
  const { S, out, check, must } = E;
  const scenarios = E.scenarios;

  // -------------------------------------------------------------------------------------------------------------------
  // helpers
  // -------------------------------------------------------------------------------------------------------------------
  const api = (run, p, opts = {}) => fetch('http://127.0.0.1:' + run.ports.engine + p, { ...opts, headers: { Origin: 'http://127.0.0.1:' + run.ports.engine, 'Content-Type': 'application/json', ...(opts.headers || {}) }, signal: AbortSignal.timeout(opts.timeout || 30000) })
    .then(async r => ({ http: r.status, body: await r.json().catch(() => null) }));
  const post = (run, p, body, timeout) => api(run, p, { method: 'POST', body: JSON.stringify(body), timeout });
  const pyEnv = info => ({ ...process.env, COMICS_META_STATE_ROOT: info.state, QA_7Z: win(SEVENZ), PYTHONDONTWRITEBYTECODE: '1' });
  const pyRun = (args, env, timeout = 240000) => spawnSync(PY, ['-B', '-I', ...args], { env, windowsHide: true, encoding: 'utf8', timeout });
  const lastLines = (text, n) => String(text || '').split(/\r?\n/).filter(Boolean).slice(-n);
  const engineLog = info => { try { return fs.readFileSync(path.win32.join(info.state, 'logs', 'engine.log'), 'utf8'); } catch { return ''; } };
  const recoveryLines = info => engineLog(info).split(/\r?\n/).filter(l => /Interrupted write recovery/.test(l));
  const catalogPath = info => path.win32.join(info.state, 'data', 'catalog.sqlite');

  // Read-only look at the QA catalog (node:sqlite, mode ro through a URI is not offered, so the connection only runs SELECT).
  async function sql(info, query, ...params) {
    const { DatabaseSync } = await import('node:sqlite');
    const db = new DatabaseSync(catalogPath(info), { readOnly: true });
    try { db.exec('PRAGMA busy_timeout=10000'); return db.prepare(query).all(...params); } finally { db.close(); }
  }

  function approveState(bigMb, bigCount, extras) {
    return async info => {
      const lib = E.emptyLibrary(info);
      const done = pyRun([H + '/fixture_approve.py', info.root, lib, String(bigMb), String(bigCount), ...extras], pyEnv(info), 300000);
      if (done.status !== 0) throw new Error('approve fixture failed: ' + done.stderr + done.stdout);
      out.fixture = JSON.parse(done.stdout.trim().split('\n').slice(-1)[0]);
    };
  }
  const comicFolder = info => path.win32.join(info.root, 'library');
  const backupsOf = (lib, name) => { const d = path.win32.join(lib, '.comic-metadata-backups'); try { return fs.readdirSync(d).filter(n => n.startsWith(name + '.')).map(n => path.win32.join(d, n)); } catch { return []; } };
  const pendingFiles = info => { const d = path.win32.join(info.state, 'data', 'pending-writes'); try { return fs.readdirSync(d).map(n => path.win32.join(d, n)); } catch { return []; } };

  async function comicId(run, name) {
    const found = await waitFor(async () => { const r = await api(run, '/api/comics?q=' + encodeURIComponent(name.replace(/\.cbz$/, ''))); return r.http === 200 && r.body.rows.find(x => path.win32.basename(x.path) === name); }, 'catalog row of ' + name, 90000, 500);
    return found;
  }

  function descendantsOf(pid) {
    const done = pyRun([H + '/pstree.py', String(pid)], process.env, 30000);
    try { return JSON.parse(done.stdout.trim())[String(pid)] || []; } catch { return []; }
  }

  async function killAll(run, label) {
    const broker = (await run.engines()).slice(-1)[0].pid;
    const kids = descendantsOf(broker);
    const record = { label, shell: run.child.pid, broker, descendants: kids.map(k => k.pid + ':' + k.exe) };
    for (const k of kids.reverse()) { try { process.kill(k.pid); } catch { } }
    try { process.kill(broker); } catch { }
    try { process.kill(run.child.pid); } catch { }
    run.detach();
    await Promise.race([run.exited, sleep(15000)]);
    await sleep(2500);
    record.stillAlive = [run.child.pid, broker, ...kids.map(k => k.pid)].filter(pidAlive);
    return record;
  }

  // Dashboard text of the Kept backups panel, read from the real page code (the panel's own toggle handler), no click and no focus.
  async function keptPanelText(run) {
    const code = "(async()=>{const p=document.getElementById('keptBackups');if(!p)return {missing:true};p.open=true;p.dispatchEvent(new Event('toggle'));await new Promise(r=>setTimeout(r,2500));return {summary:(p.querySelector('summary')||{}).textContent,reasons:[...p.querySelectorAll('.kept-reason')].map(e=>e.textContent),rows:[...p.querySelectorAll('.kept-list > *')].map(e=>(e.innerText||'').replace(/\\s+/g,' ').slice(0,300))};})()";
    return run.inspector.evaluate('globalThis.__qa.rend(' + JSON.stringify(code) + ')', true, 30000);
  }

  async function backupsListing(run) { const r = await api(run, '/api/backups'); return r; }

  const comicInfoOf = file => { const r = spawnSync(SEVENZ, ['e', '-so', file, 'ComicInfo.xml'], { windowsHide: true, encoding: 'utf8', timeout: 120000, maxBuffer: 20e6 }); return r.status === 0 ? r.stdout : null; };

  async function relaunch(tag, info, policyExtra) {
    E.run = await launch(tag, { existing: info, policyExtra });
    out.run = runInfoForEvidence(E.run);
    out.expectedTray = await E.run.qa('expected()');
    check(tag + ': observer bound to the exact app', E.run.identity.version === '0.6.9' && E.run.identity.packaged === true, { pid: E.run.identity.pid, guards: E.run.identity.guards });
    await E.run.qa('sampleStart(40)');
    return E.run;
  }

  // -------------------------------------------------------------------------------------------------------------------
  // Q2 (undone): Quit cuts a manual Approve off in the middle of the write (the real path), next start recovers it.
  // -------------------------------------------------------------------------------------------------------------------
  scenarios['q2-quit-cut'] = async () => {
    const bigMb = Number(process.env.QA_BIG_MB || 300);
    await E.startup('q2cut', approveState(bigMb, 1, ['plain']), { policyExtra: { closureWaitSeconds: 2 } });
    const info = { tmp: E.run.tmp, root: E.run.root, state: E.run.state, locks: E.run.locks };
    const lib = comicFolder(info);
    const NAME = 'Big Approve 001 (2020).cbz', PLAIN = 'Plain Approve 004 (2020).cbz';
    const orig = out.fixture.files[NAME];
    check('QA policy closureWaitSeconds is 2 (the Quit cap used for the cut-off)', E.run.pol.policy.closureWaitSeconds === 2, { closureWaitSeconds: E.run.pol.policy.closureWaitSeconds, bigMb, size: orig.size });
    await E.run.qa('sampleStart(40)');
    await setupLibrary(E.run, lib);
    await E.readyEngine('q2cut first start', 1);
    const row = await comicId(E.run, NAME);
    const comic = path.win32.join(lib, NAME), temp = comic + '.metadata-tmp';
    check('the large fixture comic is in the catalog, unwritten', row && row.size === orig.size && !comicInfoOf(comic), { id: row && row.id, size: orig.size });
    const t0 = Date.now();
    let applyResult = 'pending';
    const approve = post(E.run, '/api/apply', { comic: row.id, issue: 9001 }, 180000).then(r => { applyResult = r; return r; }, e => { applyResult = 'connection ended: ' + (e && e.name); return null; });
    // the write is in progress when its temporary archive is growing
    const mid = await waitFor(() => { try { const st = fs.statSync(temp); return st.size >= 25 * 1024 * 1024 ? { size: st.size, ms: Date.now() - t0 } : false; } catch { return false; } }, 'temporary archive growing', 120000, 20);
    const pendingAtCut = pendingFiles(info).map(f => { try { const j = JSON.parse(fs.readFileSync(f, 'utf8')); return { file: path.basename(f), keys: Object.keys(j), hasAfter: 'after' in j, backup: path.basename(j.backup || '') }; } catch (e) { return { file: path.basename(f), unreadable: String(e.message) }; } });
    check('mid-write: temporary archive growing, its pending-write record on disk without an "after" signature, backup copy made', pendingAtCut.length === 1 && pendingAtCut[0].hasAfter === false && backupsOf(lib, NAME).length === 1, { temporaryBytes: mid.size, msAfterApprove: mid.ms, pending: pendingAtCut, backups: backupsOf(lib, NAME).map(f => path.basename(f)) });
    // Quit (the tray's own Quit callback), 2 s closure wait: the Closing cap force-stops the engine while the write runs
    const tQuit = Date.now();
    await E.run.qa("clickLater('&Quit',100)");
    E.run.detach();
    const exit = await Promise.race([E.run.exited, sleep(120000).then(() => null)]);
    const writeStillRunningAtExit = fs.existsSync(temp);
    out.cut = { exit: exit && { code: exit.code, signal: exit.signal }, quitToExitMs: exit ? exit.t - tQuit : null, applyResult: typeof applyResult === 'string' ? applyResult : { http: applyResult.http }, temporaryLeftAtExit: writeStillRunningAtExit };
    check('Quit cut the Approve off: the app exited 0 while the temporary archive and the pending record were still there', exit && exit.code === 0 && writeStillRunningAtExit && pendingFiles(info).length === 1, out.cut);
    await sleep(3000);
    out.cut.leftoverRecords = fs.readdirSync(info.locks).filter(n => /^leftover-/.test(n)).length;
    out.cut.recordedPidsAlive = (await Promise.resolve([])).length;
    const diskAfterCut = { temporaryExists: fs.existsSync(temp), temporaryBytes: fs.existsSync(temp) ? fs.statSync(temp).size : 0, pending: pendingFiles(info).length, backups: backupsOf(lib, NAME).length, comicSha: await sha256Stream(comic) };
    out.diskAfterCut = diskAfterCut;
    check('after the cut: the comic is byte-identical to the fixture, a partial temporary archive and a full backup are left', diskAfterCut.comicSha === orig.sha256 && diskAfterCut.temporaryExists && diskAfterCut.pending === 1 && diskAfterCut.backups === 1, diskAfterCut);
    // start again
    await relaunch('q2cut2', info, { closureWaitSeconds: 2 });
    await E.readyEngine('q2cut second start', 1);
    const lines = recoveryLines(info);
    out.recoveryLines = lines;
    const disk2 = { temporaryExists: fs.existsSync(temp), pending: pendingFiles(info).length, backups: backupsOf(lib, NAME).length, backupFolder: fs.existsSync(path.win32.join(lib, '.comic-metadata-backups')), comicSha: await sha256Stream(comic) };
    out.diskAfterRecovery = disk2;
    check('engine.log: "Interrupted write recovery: ... undone; its backup was deleted."', lines.length === 1 && /Big Approve 001 \(2020\)\.cbz: undone; its backup was deleted\./.test(lines[0]), { lines });
    check('after the next start: no .metadata-tmp, no pending record, no backup, comic byte-identical to the fixture', !disk2.temporaryExists && disk2.pending === 0 && disk2.backups === 0 && disk2.comicSha === orig.sha256, disk2);
    const history = await sql(info, 'SELECT id,path,backup,source FROM history');
    check('History: no row for the undone write (nothing was written)', history.length === 0, { rows: history.length });
    const kept = await backupsListing(E.run);
    check('Kept backups is empty: the undone write\'s backup was deleted once it equalled the comic', kept.http === 200 && kept.body.count === 0, { count: kept.body && kept.body.count });
    // the comic is writable again: a fresh Approve of the same comic goes through (before 0.6.8 a leftover temporary archive refused it)
    const row2 = await comicId(E.run, NAME);
    const again = await post(E.run, '/api/apply', { comic: row2.id, issue: 9001 }, 180000);
    const info2 = comicInfoOf(comic);
    check('positive control: the same comic then takes a new Approve (200, verified, ComicInfo written, backup removed)', again.http === 200 && again.body.verified === true && again.body.backup_removed_after_verification === true && /<Series>QA Approve Series</.test(info2 || '') && backupsOf(lib, NAME).length === 0, { http: again.http, body: again.body && { verified: again.body.verified, removed: again.body.backup_removed_after_verification }, series: /<Series>([^<]*)</.exec(info2 || '')?.[1] });
    const history2 = await sql(info, 'SELECT id,path,source FROM history');
    check('History shows the new write once (positive control)', history2.length === 1, { rows: history2.length });
    out.quit = await E.quitViaTray('after the recovery', { staleClaimsOk: true });
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  };

  // -------------------------------------------------------------------------------------------------------------------
  // Q2 (recorded): the engine is stopped right after the rename, before the history row: next start records it.
  // The catalog's write lock is held by the harness so the engine waits at its history insert (deterministic), then every process is ended.
  // -------------------------------------------------------------------------------------------------------------------
  scenarios['q2-after-rename'] = async () => {
    const bigMb = Number(process.env.QA_BIG_MB || 120);
    await E.startup('q2ren', approveState(bigMb, 1, ['plain']));
    const info = { tmp: E.run.tmp, root: E.run.root, state: E.run.state, locks: E.run.locks };
    const lib = comicFolder(info);
    const NAME = 'Big Approve 001 (2020).cbz';
    const orig = out.fixture.files[NAME];
    await E.run.qa('sampleStart(40)');
    await setupLibrary(E.run, lib);
    await E.readyEngine('q2ren first start', 1);
    const row = await comicId(E.run, NAME);
    const comic = path.win32.join(lib, NAME), temp = comic + '.metadata-tmp';
    const approve = post(E.run, '/api/apply', { comic: row.id, issue: 9001 }, 180000).then(r => r, e => 'connection ended: ' + (e && e.name));
    const pendingPath = () => pendingFiles(info)[0];
    // "after" is saved just before the write-through rename
    await waitFor(() => { try { const f = pendingPath(); return f && 'after' in JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return false; } }, 'pending record with its after signature', 120000, 5);
    const { DatabaseSync } = await import('node:sqlite');
    const lock = new DatabaseSync(catalogPath(info));
    lock.exec('PRAGMA busy_timeout=20000');
    lock.exec('BEGIN IMMEDIATE');  // the engine's history insert now waits (30 s busy timeout) behind this write lock
    const lockedAt = Date.now();
    const renamed = await waitFor(() => { try { const st = fs.statSync(comic); return st.size !== orig.size ? { size: st.size } : false; } catch { return false; } }, 'comic replaced by the rename', 60000, 5);
    await sleep(800);
    const histBefore = (() => { try { const db = new DatabaseSync(catalogPath(info), { readOnly: true }); const n = db.prepare('SELECT COUNT(*) n FROM history').get().n; db.close(); return n; } catch (e) { return 'unreadable ' + e.message; } })();
    const pre = { temporaryExists: fs.existsSync(temp), pending: pendingFiles(info).length, renamedSize: renamed.size, origSize: orig.size, historyRows: histBefore, backups: backupsOf(lib, NAME).length, lockHeldMs: Date.now() - lockedAt };
    check('at the stop: the comic is already the new archive, the engine waits at its history insert, no history row, the backup is on disk', pre.renamedSize !== pre.origSize && !pre.temporaryExists && pre.pending === 1 && pre.historyRows === 0 && pre.backups === 1, pre);
    out.stop = await killAll(E.run, 'every process of the app ended at once (a crash)');
    lock.exec('ROLLBACK'); lock.close();
    check('every process of the first session is gone', out.stop.stillAlive.length === 0, out.stop);
    const approveResult = await Promise.race([approve, sleep(1000).then(() => 'no answer')]);
    out.approveResult = typeof approveResult === 'string' ? approveResult : { http: approveResult.http };
    const comicShaBefore = await sha256Stream(comic);
    const pend = JSON.parse(fs.readFileSync(pendingFiles(info)[0], 'utf8'));
    out.pendingRecord = { keys: Object.keys(pend), after: pend.after, before: pend.before, writer: pend.writer, source: pend.source, backup: path.basename(pend.backup) };
    check('after the stop: the pending record has before and after signatures and the comic is the written archive', Array.isArray(pend.after) && pend.after[0] === renamed.size && comicShaBefore !== orig.sha256, out.pendingRecord);
    await relaunch('q2ren2', info);
    await E.readyEngine('q2ren second start', 1);
    const lines = recoveryLines(info);
    out.recoveryLines = lines;
    check('engine.log: "Interrupted write recovery: ... recorded; its backup is kept."', lines.length === 1 && /Big Approve 001 \(2020\)\.cbz: recorded; its backup is kept\./.test(lines[0]), { lines });
    const disk2 = { temporaryExists: fs.existsSync(temp), pending: pendingFiles(info).length, backups: backupsOf(lib, NAME).map(f => path.basename(f)), comicHasComicInfo: Boolean(comicInfoOf(comic)) };
    check('after the next start: no .metadata-tmp, no pending record, the backup kept, the comic carries the Approve\'s ComicInfo', !disk2.temporaryExists && disk2.pending === 0 && disk2.backups.length === 1 && disk2.comicHasComicInfo, disk2);
    const info2 = comicInfoOf(comic) || '';
    check('the written ComicInfo is the Approve\'s (Series, Number, Summary, Web)', /<Series>QA Approve Series</.test(info2) && /<Number>1</.test(info2) && /QA approve summary 1\./.test(info2) && /4000-9001/.test(info2), { series: /<Series>([^<]*)</.exec(info2)?.[1], number: /<Number>([^<]*)</.exec(info2)?.[1] });
    const history = await sql(info, 'SELECT h.id, h.path, h.backup, h.source, l.writer, l.origin, l.fields FROM history h LEFT JOIN write_ledger l ON l.history_id = h.id');
    out.history = history.map(h => ({ id: h.id, path: path.basename(h.path), backup: path.basename(h.backup), source: h.source, writer: h.writer, origin: h.origin }));
    check('History shows the write: one history row for this comic, ledger writer "manual", origin "recovered"', history.length === 1 && path.basename(history[0].path) === NAME && history[0].writer === 'manual' && history[0].origin === 'recovered' && history[0].backup === pend.backup, out.history);
    const catalogRow = (await sql(info, "SELECT status, size, CAST(mtime AS TEXT) mtime FROM comics WHERE path LIKE ?", '%' + NAME))[0];
    check('catalog row: status tagged, size equals the written archive', catalogRow && catalogRow.status === 'tagged' && catalogRow.size === fs.statSync(comic).size, { status: catalogRow && catalogRow.status });
    const kept = await backupsListing(E.run);
    out.keptApi = kept.body;
    check('Kept backups lists the backup as "delete_refused" ("Saved; backup could not be deleted")', kept.http === 200 && kept.body.count === 1 && kept.body.items[0].reason === 'delete_refused' && kept.body.items[0].name === NAME, { count: kept.body && kept.body.count, reason: kept.body && kept.body.items && kept.body.items[0] && kept.body.items[0].reason });
    const panel = await keptPanelText(E.run);
    out.keptPanel = panel;
    check('Kept backups page (the real panel code) shows the reason text "Saved; backup could not be deleted"', panel && Array.isArray(panel.reasons) && panel.reasons.includes('Saved; backup could not be deleted'), panel);
    out.quit = await E.quitViaTray('after the recovery', { staleClaimsOk: true });
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  };

  // -------------------------------------------------------------------------------------------------------------------
  // R1: a read-only comic through Approve is not saved, is reported "not verified", and its backup is listed "Save not verified"
  // -------------------------------------------------------------------------------------------------------------------
  scenarios['r1-readonly'] = async () => {
    await E.startup('r1', approveState(0, 0, ['readonly', 'plain']));
    const info = { tmp: E.run.tmp, root: E.run.root, state: E.run.state, locks: E.run.locks };
    const lib = comicFolder(info);
    const NAME = 'ReadOnly Approve 003 (2020).cbz', PLAIN = 'Plain Approve 004 (2020).cbz';
    const orig = out.fixture.files[NAME];
    await E.run.qa('sampleStart(40)');
    await setupLibrary(E.run, lib);
    await E.readyEngine('r1 first start', 1);
    const comic = path.win32.join(lib, NAME), temp = comic + '.metadata-tmp';
    const row = await comicId(E.run, NAME);
    check('the fixture comic is read-only', (fs.statSync(comic).mode & 0o200) === 0, { mode: (fs.statSync(comic).mode & 0o777).toString(8) });
    const tApprove = Date.now();
    const result = await post(E.run, '/api/apply', { comic: row.id, issue: 9003 }, 120000);
    const approveMs = Date.now() - tApprove;
    out.applyResult = { http: result.http, answeredAfterMs: approveMs, body: result.body && { error: result.body.error, verified: result.body.verified, backup: result.body.backup && path.basename(result.body.backup), hasBackupId: Boolean(result.body.backup_id) } };
    check('Approve answers "The change was not verified..." (HTTP 400, verified false, a retained backup named)', approveMs < 6000 && result.http === 400 && result.body.verified === false && /not verified/i.test(result.body.error || '') && Boolean(result.body.backup), out.applyResult);
    const backups = backupsOf(lib, NAME);
    const disk = { comicSha: await sha256Stream(comic), temporaryExists: fs.existsSync(temp), pending: pendingFiles(info).length, backups: backups.map(f => path.basename(f)), backupSha: backups[0] ? await sha256Stream(backups[0]) : null, comicReadOnly: (fs.statSync(comic).mode & 0o200) === 0, backupReadOnly: backups[0] ? (fs.statSync(backups[0]).mode & 0o200) === 0 : null };
    out.disk = disk;
    check('the comic is unchanged and still read-only; no .metadata-tmp, no pending record; one backup equal to the original', disk.comicSha === orig.sha256 && disk.comicReadOnly && !disk.temporaryExists && disk.pending === 0 && disk.backups.length === 1 && disk.backupSha === orig.sha256, disk);
    const kept = await backupsListing(E.run);
    out.keptApi = kept.body;
    check('Kept backups lists the backup as "save_not_verified"', kept.http === 200 && kept.body.count === 1 && kept.body.items[0].reason === 'save_not_verified' && kept.body.items[0].name === NAME, { count: kept.body && kept.body.count, reason: kept.body && kept.body.items && kept.body.items[0] && kept.body.items[0].reason });
    const panel = await keptPanelText(E.run);
    out.keptPanel = panel;
    check('Kept backups page (the real panel code) shows "Save not verified"', panel && Array.isArray(panel.reasons) && panel.reasons.includes('Save not verified'), panel);
    const history = await sql(info, 'SELECT id FROM history');
    check('History: no row (nothing was written)', history.length === 0, { rows: history.length });
    // positive control: the plain (writable) comic through the same path is saved and verified, backup removed
    const prow = await comicId(E.run, PLAIN);
    const good = await post(E.run, '/api/apply', { comic: prow.id, issue: 9004 }, 120000);
    check('positive control: a writable comic through the same Approve is verified and its backup removed', good.http === 200 && good.body.verified === true && good.body.backup_removed_after_verification === true && backupsOf(lib, PLAIN).length === 0, { http: good.http, verified: good.body && good.body.verified });
    out.quit = await E.quitViaTray('after the read-only Approve', { staleClaimsOk: true });
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  };
  E.h = { killAll, api, post, pyEnv, pyRun, sql, catalogPath, comicFolder, backupsOf, pendingFiles, comicId, descendantsOf, keptPanelText, backupsListing, comicInfoOf, relaunch, recoveryLines, engineLog, sha256Stream, lastLines };
  registerMerge(E);
  registerMore(E);
  registerC7(E);
}
