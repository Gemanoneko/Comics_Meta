"""Futaba 0.6.9 harness helper (W1): "another program" that has a comic open for reading and writing, changes it, and closes it.
Commands, one per stdin line (packaged python, -B -I):
  hold     open <file> with GENERIC_READ | GENERIC_WRITE and FILE_SHARE_READ | FILE_SHARE_WRITE (no delete share): the app can read the
           comic, but a rename over it is refused while this handle is open (what a reader or an editor does)
  change   while the handle is held: add one page to the zip through a second, ordinary read-write open (a real change of the comic's
           size and content); prints the new size
  release  close the handle
End of stdin releases too.
Usage: holdrw.py <file>"""
import ctypes as C
import json
import os
import sys
import zipfile
from ctypes import wintypes as W

K = C.WinDLL('kernel32', use_last_error=True)
K.CreateFileW.restype = W.HANDLE
K.CreateFileW.argtypes = [W.LPCWSTR, W.DWORD, W.DWORD, C.c_void_p, W.DWORD, W.DWORD, W.HANDLE]
K.CloseHandle.argtypes = [W.HANDLE]
INVALID = W.HANDLE(-1).value
path = sys.argv[1]
handle = None
print('ready', flush=True)
for line in sys.stdin:
    command = line.strip()
    if command == 'hold' and handle is None:
        handle = K.CreateFileW(path, 0x80000000 | 0x40000000, 0x1 | 0x2, None, 3, 0x80, None)
        if handle == INVALID or handle is None:
            print('open failed %d' % C.get_last_error(), flush=True)
            raise SystemExit(2)
        print('held', flush=True)
    elif command == 'change' and handle is not None:
        before = os.stat(path)
        with zipfile.ZipFile(path, 'a') as archive:
            archive.writestr('added-by-another-program.txt', b'Added while the app was waiting to rename. Futaba QA 0.6.9 W1.\n')
        after = os.stat(path)
        print(json.dumps({'changed': True, 'before': before.st_size, 'size': after.st_size}), flush=True)
    elif command == 'release' and handle is not None:
        K.CloseHandle(handle)
        handle = None
        print('released', flush=True)
if handle is not None:
    K.CloseHandle(handle)
    print('released', flush=True)
