// Futaba 0.6.8 QA: Judy's Quit-copy rev 3 (Docs/ComicsMetaOrganizer_ClosureBanner_UX_2026-11-18.md, section "Rev 3", checks C7 1 to 11).
// Everything is read from inside the app (the dialog's DOM, sampled by the observer every 40 ms): no OS key, mouse or focus, no visible window.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { launch, setupLibrary, waitFor, sleep, win, BASE, pidAlive, portRefused, runInfoForEvidence, EXTRACT } from './lib.mjs';

const RC = 'I:/AI Projects/Worktrees/Comics Meta Organizer/rc-069';
const SPEC = 'I:/AI Projects/Studio Illuminati/WIP/Comics Meta Organizer/Docs/ComicsMetaOrganizer_ClosureBanner_UX_2026-11-18.md';
const MANIFEST = 'I:/AI Projects/Temp/cmo-rc069/source-manifest-67c7b53.json';
export const PAUSING = 'Pausing \u2014 finishing the current operation. Progress is saved.';
export const ENDING = 'Stopping the local service\u2026';
export const ROW1 = n => 'This can take up to ' + n + ' seconds.';
export const ROW2 = 'Cannot cancel: the app is already closing.';
export const ROW3 = 'The app is already closing and exits by itself.';
const OLD_CANCEL = 'Stop quitting. Processing resumes unless you had paused it.';
const OLD_FORCE = 'Exit without waiting. An interrupted write keeps its recovery backup.';
const sha = b => crypto.createHash('sha256').update(b).digest('hex');

// The dialog samples of one quit (observer events), judged against rev 3. `dlg` = events of kind sample whose snap.file is stopping.html.
export function c7Checks(E, { dlg, click, exit, wait, tag, expectEnding = true }) {
  const { check } = E;
  const states = dlg.map(s => ({ t: s.t, status: s.snap.status && s.snap.status.text, detail: s.snap.detail && s.snap.detail.text, role: s.snap.detail && s.snap.detail.role, cancel: s.snap.cancel, force: s.snap.force, actionsHidden: s.snap.actions && s.snap.actions.hidden, iw: s.snap.iw, sw: s.snap.sw, cw: s.snap.cw, detailRect: s.snap.detail && s.snap.detail.rect, actionsRect: s.snap.actions && s.snap.actions.rect }));
  const rel = t => t - click.t;
  const closing = states.filter(s => /Closing\u2026$/.test(s.status || ''));
  const closingStart = closing[0] && closing[0].t;
  const ending = states.find(s => s.status === ENDING);
  const sentence = closing.find(s => s.detail === ROW1(2 * wait));
  const early = closing.filter(s => closingStart !== undefined && s.t - closingStart < 4500);
  const res = {};
  res.closing = closingStart === undefined ? null : { startMs: rel(closingStart), samples: closing.length, firstStatus: closing[0].status };
  // C7 1: the Closing detail is empty, then exactly "up to 2 x wait seconds" 5.0 s (+-0.5 s) after Closing began; ending ~wait s after Closing began; second sentence 10 s into the ending
  res.sentenceAfterClosingMs = sentence && closingStart !== undefined ? sentence.t - closingStart : null;
  res.endingAfterClosingMs = ending && closingStart !== undefined ? ending.t - closingStart : null;
  res.lateAfterEndingMs = (() => { const late = states.find(s => s.status === ENDING && /recovery backup/.test(s.detail || '')); return late && ending ? late.t - ending.t : null; })();
  check(tag + ' C7-1: Closing shows its status with the detail EMPTY first (every sample in the first 4.5 s), then exactly "' + ROW1(2 * wait) + '" 5.0 s (+-0.5 s) after Closing began', closingStart !== undefined && early.length > 0 && early.every(s => s.detail === '') && Boolean(sentence) && res.sentenceAfterClosingMs >= 4500 && res.sentenceAfterClosingMs <= 5500, { closing: res.closing, earlySamples: early.length, sentenceAfterClosingMs: res.sentenceAfterClosingMs, sentence: sentence && sentence.detail });
  check(tag + ' C7-1: the ending state "' + ENDING + '" / "' + ROW1(wait) + '" shows about ' + wait + ' s after Closing began, and the 10 s sentence 10.0 s after that', Boolean(ending) && ending.detail === ROW1(wait) && res.endingAfterClosingMs >= wait * 1000 - 500 && res.endingAfterClosingMs <= wait * 1000 + 1500 && res.lateAfterEndingMs >= 9500 && res.lateAfterEndingMs <= 11500, { endingAfterClosingMs: res.endingAfterClosingMs, endingDetail: ending && ending.detail, lateAfterEndingMs: res.lateAfterEndingMs });
  // C7 2: the stated-remaining test: for every text with a number N, exit time - first sight of the text <= N + 2 s
  const firsts = []; const seen = new Set();
  for (const s of states) { const key = (s.status || '') + '|' + (s.detail || ''); if (seen.has(key)) continue; seen.add(key); const m = /up to (\d+) seconds?/.exec(s.detail || ''); if (m) firsts.push({ atMs: rel(s.t), status: s.status, detail: s.detail, N: Number(m[1]), remainingMs: exit.t - s.t, limitMs: (Number(m[1]) + 2) * 1000, ok: exit.t - s.t <= (Number(m[1]) + 2) * 1000 }); }
  res.stated = firsts;
  check(tag + ' C7-2: stated-remaining test: for every sampled text with a number N, (exit - time it first appeared) <= N + 2 s; Closing carries a number at all (0.6.7 had none there)', firsts.length >= 2 && firsts.every(f => f.ok) && firsts.some(f => /Closing/.test(f.status)), { checked: firsts.map(f => ({ atMs: f.atMs, text: f.detail, N: f.N, remainingMs: f.remainingMs, limitMs: f.limitMs, ok: f.ok })) });
  if (wait === 12 || wait === 30) check(tag + ' C7-3: exit within 2 x wait + 1 + 2 s of Closing beginning', closingStart !== undefined && exit.t - closingStart <= (2 * wait + 1 + 2) * 1000, { exitAfterClosingMs: exit.t - closingStart, limitMs: (2 * wait + 1 + 2) * 1000 });
  // C7 5 (live part): both buttons disabled with rows 2 and 3 as their tooltips; no "Waiting for", no "Quit now exits without waiting" in any Closing detail; the detail is a live region
  const bad = closing.filter(s => !(s.cancel && s.force && s.cancel.disabled === true && s.force.disabled === true && s.cancel.hidden === false && s.force.hidden === false && s.cancel.title === ROW2 && s.force.title === ROW3));
  const suppressed = closing.filter(s => /Waiting for|Quit now exits without waiting/.test(s.detail || ''));
  res.tooltips = { cancel: closing[0] && closing[0].cancel && closing[0].cancel.title, force: closing[0] && closing[0].force && closing[0].force.title, cancelText: closing[0] && closing[0].cancel && closing[0].cancel.text };
  check(tag + ' C7-5 (live dialog): in every Closing sample both buttons are disabled and shown, their tooltips are exactly "' + ROW2 + '" and "' + ROW3 + '"', closing.length > 0 && bad.length === 0, { closingSamples: closing.length, notMatching: bad.length, ...res.tooltips });
  check(tag + ' C7-5 (live dialog): no "Waiting for" and no "Quit now exits without waiting" in any Closing detail; the detail is a live region (role status)', closing.length > 0 && suppressed.length === 0 && closing.every(s => s.role === 'status'), { closingSamples: closing.length, suppressedLines: suppressed.length });
  // Pausing stage unchanged: pausing text, buttons enabled, the old tooltips
  const pausing = states.filter(s => s.status === PAUSING);
  check(tag + ' Pausing stage unchanged: its text, both buttons enabled, the 0.6.7 tooltips', pausing.length > 0 && pausing.every(s => s.cancel.disabled === false && s.force.disabled === false && s.cancel.title === OLD_CANCEL && s.force.title === OLD_FORCE && (s.detail === '' || /^Waiting for/.test(s.detail))), { samples: pausing.length, cancelTitle: pausing[0] && pausing[0].cancel.title, forceTitle: pausing[0] && pausing[0].force.title });
  // C7 7 (live part): the ending state hides the buttons
  if (expectEnding) check(tag + ' C7-7 (live dialog): in the ending state the action row is hidden (no buttons, no gap)', Boolean(ending) && states.filter(s => s.status === ENDING).every(s => s.actionsHidden === true), { endingSamples: states.filter(s => s.status === ENDING).length });
  // C7 9 (live part): the real dialog's rects before and after the sentence appears (offscreen)
  const before = closing.find(s => s.detail === '' && s.detailRect), after = sentence;
  const rects = s => s && { inner: s.iw, detail: s.detailRect, actions: s.actionsRect, cancel: s.cancel && s.cancel.rect, force: s.force && s.force.rect, scroll: [s.sw, s.cw] };
  const fits = s => s && s.cancel.rect[3] >= 40 && s.force.rect[3] >= 40 && s.cancel.rect[0] >= 0 && s.force.rect[0] + s.force.rect[2] <= s.iw && s.sw <= s.cw && (s.detailRect[3] === 0 || s.detailRect[1] + s.detailRect[3] <= s.actionsRect[1] + 0.5);
  res.rects = { before: rects(before), after: rects(after) };
  check(tag + ' C7-9 (live dialog, offscreen): before and after the sentence appears, the detail and the buttons do not overlap, both buttons are at least 40 px high and inside the window, nothing scrolls sideways', Boolean(before) && Boolean(after) && fits(before) && fits(after), res.rects);
  E.out['c7-' + tag.replace(/\W+/g, '_')] = res;
  return res;
}

export function registerC7(E) {
  const { S, out, check, must } = E;
  const h = E.h;
  const dialogSamples = (ev, click) => ev.filter(e => e.kind === 'sample' && e.snap && e.snap.file === 'stopping.html' && e.t >= click.t);

  // C7 4: a healthy quit, five runs from the ready dashboard (tray Quit): the Closing detail is empty in every sample; the sentence never shows
  E.scenarios['c7-healthy'] = async () => {
    await E.startup('c7h', async info => { E.emptyLibrary(info); });
    const info = { tmp: E.run.tmp, root: E.run.root, state: E.run.state, locks: E.run.locks };
    await E.run.qa('sampleStart(40)');
    await setupLibrary(E.run, path.win32.join(info.root, 'library'));
    await E.readyEngine('c7h run 1', 1);
    out.runs = [];
    for (let i = 1; i <= 5; i++) {
      if (i > 1) { await h.relaunch('c7h' + i, info); await E.readyEngine('c7h run ' + i, 1); }
      const q = await E.quitViaTray('healthy quit ' + i, { staleClaimsOk: true });
      const ev = E.run.readEvents();
      const click = ev.filter(e => e.kind === 'tray-click' && e.label === '&Quit').pop();
      const dlg = dialogSamples(ev, click);
      const closing = dlg.filter(s => /Closing\u2026$/.test(s.snap.status.text));
      const withNumber = dlg.filter(s => /seconds?\./.test(s.snap.detail.text) && s.snap.status.text !== ENDING);
      const run = { i, exitCode: q.exit && q.exit.code, quitToExitMs: q.quitToExitMs, samples: dlg.length, closingSamples: closing.length, closingDetails: [...new Set(closing.map(s => s.snap.detail.text))], endingSeen: dlg.some(s => s.snap.status.text === ENDING), numberSeenOutsideEnding: withNumber.length, stages: [...new Set(dlg.map(s => s.snap.status.text))] };
      out.runs.push(run);
      check('C7-4 healthy quit ' + i + ' of 5 (tray Quit from the ready dashboard): the Closing detail is empty in every sample, no time sentence anywhere, no ending state, exit 0', run.exitCode === 0 && run.closingSamples > 0 && run.closingDetails.length === 1 && run.closingDetails[0] === '' && run.numberSeenOutsideEnding === 0 && !run.endingSeen, run);
    }
    out.pass = S.list.every(s => s.ok !== false);
  };

  // C7 6: Quit now during Pausing (no Closing stage), with the broker frozen so the forced path really lasts
  E.scenarios['c7-quitnow'] = async () => {
    const wait = 30;
    await E.startup('c7q', async info => { E.emptyLibrary(info); });
    await E.run.qa('sampleStart(40)');
    await setupLibrary(E.run, path.win32.join(E.run.root, 'library'));
    await E.readyEngine('c7q', 1);
    const broker = (await E.run.engines()).slice(-1)[0].pid;
    const hold = await E.hold(broker, { mode: 'freeze', seconds: 100 });
    await E.run.qa("clickLater('&Quit',300)");
    await E.run.qa("dialogClickLater('force',2300)");
    E.run.detach();
    const exit = await Promise.race([E.run.exited, sleep(150000).then(() => null)]);
    const ev = E.run.readEvents();
    const click = ev.filter(e => e.kind === 'tray-click' && e.label === '&Quit').pop();
    const clicked = ev.filter(e => e.kind === 'dialog-click').pop();
    const dlg = dialogSamples(ev, click);
    const ending = dlg.find(s => s.snap.status.text === ENDING);
    const closing = dlg.filter(s => /Closing\u2026$/.test(s.snap.status.text));
    out.quitNow = { dialogClick: clicked, endingAtMs: ending && ending.t - click.t, endingDetail: ending && ending.snap.detail.text, closingSamples: closing.length, exitMsAfterEnding: exit && ending ? exit.t - ending.t : null, exitCode: exit && exit.code, clickToExitMs: exit ? exit.t - click.t : null, stages: [...new Set(dlg.map(s => s.snap.status.text))] };
    check('C7-6: Quit now clicked in the Pausing stage (a DOM click on the dialog button, enabled at that moment)', clicked && clicked.found === true && clicked.disabled === false && clicked.status === PAUSING, clicked);
    check('C7-6: no Closing stage is shown; the ending state reads "' + ROW1(wait) + '"', closing.length === 0 && Boolean(ending) && ending.snap.detail.text === ROW1(wait) && ending.snap.status.text === ENDING, { closingSamples: closing.length, endingDetail: out.quitNow.endingDetail, stages: out.quitNow.stages });
    check('C7-6: the process ends within ' + wait + ' s + 1 s + 2 s of the ending state beginning (broker frozen, never answered), exit 0', exit !== null && exit.code === 0 && exit.t - ending.t <= (wait + 1 + 2) * 1000, { exitMsAfterEnding: out.quitNow.exitMsAfterEnding, limitMs: (wait + 3) * 1000, exitCode: out.quitNow.exitCode });
    const first = dlg.filter(s => /up to (\d+) seconds?/.test(s.snap.detail.text)).slice(0, 1);
    check('C7-2 (Quit now path): stated-remaining test on the ending text: exit - first sight <= N + 2 s', first.length === 1 && exit.t - first[0].t <= (wait + 2) * 1000, { remainingMs: first[0] && exit.t - first[0].t, limitMs: (wait + 2) * 1000 });
    await hold.release();
    await sleep(8000);
    out.enginePortRefused = await portRefused(E.run.ports.engine);
    out.pass = S.list.every(s => s.ok !== false);
  };

  // C7 5 (DOM feed), 7, 8, 9, 10, 11 and the "no literal 30 or 60" part of 3: the packaged dialog page fed states in harness-only offscreen windows,
  // with the 0.6.7 page as the positive control.
  E.scenarios['c7-dom'] = async () => {
    const require = createRequire(import.meta.url);
    const asar = require(RC + '/node_modules/@electron/asar');
    const manifest = JSON.parse(fs.readFileSync(MANIFEST, 'utf8'));
    const entry = n => manifest.files.find(f => f.path === n)?.sha256;
    const work = path.win32.join(BASE, 'work', 'dom');
    const copies = {};
    for (const v of ['068', '067']) fs.mkdirSync(path.win32.join(work, v), { recursive: true });
    for (const f of ['stopping.html', 'stopping.js', 'shell.css']) {
      const buf = asar.extractFile(EXTRACT + '/resources/app.asar', 'desktop/' + f);
      fs.writeFileSync(path.win32.join(work, '068', f), buf);
      copies['068/' + f] = { sha256: sha(buf), manifest: entry('desktop/' + f) };
      fs.writeFileSync(path.win32.join(work, '067', f), execFileSync('git', ['-C', RC, 'show', '9d1ad1af7c3e3f6c0db86b052d8372c8f1c5ad1b:desktop/' + f], { maxBuffer: 5e6 }));
    }
    const norm = b => sha(Buffer.from(Buffer.from(b).toString('latin1').split('\r').join(''), 'latin1'));
    check('the dialog page under test is the packaged one: stopping.html, stopping.js, shell.css extracted from app.asar equal the source manifest (line endings normalised); the 0.6.7 copies come from git 9d1ad1a', ['stopping.html', 'stopping.js', 'shell.css'].every(f => norm(fs.readFileSync(path.win32.join(work, '068', f))) === entry('desktop/' + f) || copies['068/' + f].sha256 === entry('desktop/' + f)), copies);
    const stubPath = path.win32.join(work, 'preload-stub.cjs');
    fs.writeFileSync(stubPath, "window.__cb=null;window.__actions=[];window.comicDesktop={onState(cb){window.__cb=cb;return ()=>{};},action(a){window.__actions.push(a);return Promise.resolve();}};\n");
    await E.startup('c7dom', async info => { E.emptyLibrary(info); });
    await waitFor(async () => { const p = await E.run.qa('page()', true); return /setup\.html$/.test(p.url) && p.ready === 'complete'; }, 'setup page (app ready)', 60000);
    const SNAP = "(()=>{const $=id=>document.getElementById(id);const rc=e=>{const b=e.getBoundingClientRect();return {x:b.x,y:b.y,w:b.width,h:b.height,r:b.right,b:b.bottom};};const bt=id=>{const b=$(id);return {text:b.textContent,disabled:b.disabled,hidden:b.hidden,title:b.title,rect:rc(b)};};return {title:$('title').textContent,status:$('status').textContent,detail:$('detail').textContent,role:$('detail').getAttribute('role'),actionsHidden:$('actions').hidden,detailRect:rc($('detail')),actionsRect:rc($('actions')),cancel:bt('cancel'),force:bt('force'),iw:innerWidth,ih:innerHeight,sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,sh:document.documentElement.scrollHeight,ch:document.documentElement.clientHeight};})()";
    async function feed(version, states, width = 440) {
      const url = pathToFileURL(path.win32.join(work, version, 'stopping.html')).href;
      const id = await E.run.qa('domOpen(' + JSON.stringify(url) + ',' + JSON.stringify(stubPath) + ',' + width + ',400)', true, 30000);
      const snaps = [];
      try {
        for (const st of states) snaps.push(await E.run.qa('domEval(' + id + ',' + JSON.stringify('(()=>{window.__cb(' + JSON.stringify(st) + ');return ' + SNAP + ';})()') + ')', true, 20000));
      } finally { await E.run.qa('domClose(' + id + ')', true); }
      return snaps;
    }
    const upd = { update: { version: '0.6.9' } };
    const closing = (o = {}) => ({ ...upd, stopping: { mode: 'quit', stage: 'closing', waitSeconds: 30, late: false, elapsed: 1000, control: { waiting_for: [] }, ...o } });
    // --- C7-5 feed: elapsed 70000, waiting_for metadata, late set
    const f5 = { ...closing({ late: true, elapsed: 70000, control: { waiting_for: ['metadata'] } }) };
    const [n5] = await feed('068', [f5]);
    const [o5] = await feed('067', [{ ...f5, stopping: { ...f5.stopping } }]);
    out.c75 = { new: { detail: n5.detail, cancel: n5.cancel.title, force: n5.force.title, cancelDisabled: n5.cancel.disabled, forceDisabled: n5.force.disabled }, old067: { detail: o5.detail, cancel: o5.cancel.title, force: o5.force.title } };
    check('C7-5 DOM feed (closing, elapsed 70000, waiting_for [metadata], late set): the packaged detail is EXACTLY "' + ROW1(60) + '", both buttons disabled, tooltips rows 2 and 3 character for character', n5.detail === ROW1(60) && n5.cancel.title === ROW2 && n5.force.title === ROW3 && n5.cancel.disabled && n5.force.disabled && n5.role === 'status', out.c75.new);
    check('C7-5 positive control: the SAME feed on the 0.6.7 dialog shows the old suffix ("Waiting for: comic processing" and "Quit now exits without waiting") and the old tooltips', /Waiting for: comic processing/.test(o5.detail) && /Quit now exits without waiting\. An interrupted write keeps its recovery backup\./.test(o5.detail) && o5.cancel.title === OLD_CANCEL && o5.force.title === OLD_FORCE, out.c75.old067);
    // --- C7-1/3 by feed: empty before late, the sentence with late; policy 12 -> 24; 1 -> 2 seconds
    const [e1, l1] = await feed('068', [closing({ late: false, elapsed: 1000 }), closing({ late: true, elapsed: 5200 })]);
    const [l12] = await feed('068', [closing({ late: true, waitSeconds: 12, elapsed: 5200 })]);
    const [l1s] = await feed('068', [closing({ late: true, waitSeconds: 1, elapsed: 5200 })]);
    out.c71 = { before5s: e1.detail, after5s: l1.detail, policy12: l12.detail, policy1: l1s.detail };
    check('C7-1 DOM feed: Closing detail is empty before the 5 s flag and exactly "' + ROW1(60) + '" with it; with the policy at 12 it reads "' + ROW1(24) + '"', e1.detail === '' && l1.detail === ROW1(60) && l12.detail === ROW1(24), out.c71);
    // --- C7-10: number 1
    const [en1, en1late, en30late] = [
      (await feed('068', [{ ...upd, stopping: { mode: 'quit', stage: 'ending', waitSeconds: 1, late: false } }]))[0],
      (await feed('068', [{ ...upd, stopping: { mode: 'quit', stage: 'ending', waitSeconds: 1, late: true } }]))[0],
      (await feed('068', [{ ...upd, stopping: { mode: 'quit', stage: 'ending', waitSeconds: 30, late: true } }]))[0]];
    out.c710 = { one: en1.detail, oneLate: en1late.detail, thirtyLate: en30late.detail, status: en1.status, actionsHidden: en1.actionsHidden };
    check('C7-10: ending state with waitSeconds 1 reads exactly "This can take up to 1 second."; with the late flag the old second sentence follows; with 30 it reads "up to 30 seconds."', en1.detail === 'This can take up to 1 second.' && en1late.detail === 'This can take up to 1 second. An interrupted write keeps its recovery backup.' && en30late.detail === 'This can take up to 30 seconds. An interrupted write keeps its recovery backup.' && en1.status === ENDING && en1.actionsHidden === true, out.c710);
    // --- C7-7 (feed): once ending, Escape and later states change nothing
    const [endSnap, afterLater] = await (async () => {
      const url = pathToFileURL(path.win32.join(work, '068', 'stopping.html')).href;
      const id = await E.run.qa('domOpen(' + JSON.stringify(url) + ',' + JSON.stringify(stubPath) + ',440,400)', true, 30000);
      try {
        const run = code => E.run.qa('domEval(' + id + ',' + JSON.stringify(code) + ')', true, 20000);
        const a = await run('(()=>{window.__cb(' + JSON.stringify({ ...upd, stopping: { mode: 'quit', stage: 'ending', waitSeconds: 30, late: false } }) + ');return ' + SNAP + ';})()');
        const b = await run('(()=>{document.dispatchEvent(new KeyboardEvent("keydown",{key:"Escape",bubbles:true}));window.__cb(' + JSON.stringify(closing({ late: true })) + ');return {snap:' + SNAP + ',actions:window.__actions};})()');
        return [a, b];
      } finally { await E.run.qa('domClose(' + id + ')', true); }
    })();
    check('C7-7 DOM: in the ending state Escape sends nothing (no cancelStop action) and a later Closing state changes nothing (the ending text stays, buttons hidden)', afterLater.actions.length === 0 && afterLater.snap.status === ENDING && afterLater.snap.detail === ROW1(30) && afterLater.snap.actionsHidden === true, { actions: afterLater.actions, status: afterLater.snap.status, detail: afterLater.snap.detail });
    // --- C7-8: install mode regression
    const inst = (o = {}) => ({ ...upd, stopping: { mode: 'install', stage: 'closing', waitSeconds: 30, late: false, elapsed: 1000, control: { waiting_for: [] }, ...o } });
    const [i1, i2] = await feed('068', [inst(), inst({ late: true, elapsed: 6000 })]);
    const [io] = await feed('067', [inst({ late: true, elapsed: 6000 })]);
    out.c78 = { title: i1.title, status: i1.status, detail: i1.detail, detailLate: i2.detail, cancelText: i1.cancel.text, cancelTitle: i1.cancel.title, forceHidden: i1.force.hidden, old067: { status: io.status, detail: io.detail, cancelTitle: io.cancel.title } };
    check('C7-8 install mode: Closing reads "Gemma released from GPU. The app restarts to install.", no time sentence (even with the late flag), "Cancel install" with its tooltip unchanged, Quit now hidden; identical to the 0.6.7 page', i1.status === 'Gemma released from GPU. The app restarts to install.' && i1.detail === '' && i2.detail === '' && i1.cancel.text === 'Cancel install' && i1.cancel.title === 'Stop the install. Processing resumes unless you had paused it.' && i1.force.hidden === true && io.status === i1.status && io.detail === '' && io.cancel.title === i1.cancel.title && i1.title === 'Installing v0.6.9', out.c78);
    // --- C7-9: rects at 440 px (content width), before and after the sentence appears
    const [r1, r2] = await feed('068', [closing({ late: false, elapsed: 1000 }), closing({ late: true, elapsed: 5200 })], 440);
    const fits = s => s.cancel.rect.h >= 40 && s.force.rect.h >= 40 && s.cancel.rect.x >= 0 && s.force.rect.r <= s.iw && s.sw <= s.cw && s.sh <= s.ch && (s.detail === '' || s.detailRect.b <= s.actionsRect.y + 0.5) && s.actionsRect.b <= s.ih && s.cancel.rect.r <= s.force.rect.x + 0.5;
    out.c79 = { inner: [r1.iw, r1.ih], before: { detailH: r1.detailRect.h, cancel: r1.cancel.rect, force: r1.force.rect, scroll: [r1.sw, r1.cw, r1.sh, r1.ch] }, after: { detailH: r2.detailRect.h, detailBottom: r2.detailRect.b, actionsTop: r2.actionsRect.y, cancel: r2.cancel.rect, force: r2.force.rect, scroll: [r2.sw, r2.cw, r2.sh, r2.ch] } };
    check('C7-9 DOM at 440 px: before and after the sentence appears the detail and the buttons do not overlap, both buttons are at least 40 px high and fully inside the window, nothing scrolls', fits(r1) && fits(r2) && r2.detailRect.h > r1.detailRect.h, out.c79);
    // --- C7-3 / source: no literal 30 or 60 as a time in the dialog page or the shell's stage state
    const mainJs = asar.extractFile(EXTRACT + '/resources/app.asar', 'desktop/main.cjs').toString('utf8');
    const stopJs = fs.readFileSync(path.win32.join(work, '068', 'stopping.js'), 'utf8');
    const lit = /\b(?:30|60)\s*seconds\b|up to (?:30|60)\b|['"`](?:30|60)['"`]/;
    const stopLines = stopJs.split('\n').filter(l => lit.test(l)), mainLines = mainJs.split('\n').filter(l => lit.test(l));
    check('C7-3 source: no literal 30 or 60 as a stated time in the packaged desktop/stopping.js or the stage state in desktop/main.cjs (the numbers come from the policy field)', stopLines.length === 0 && mainLines.length === 0, { stoppingJsHits: stopLines.length, mainCjsHits: mainLines.length, positiveControlPattern: lit.test('This can take up to 30 seconds.') });
    // --- C7-11: shipped strings vs the spec text, character by character
    const spec = fs.readFileSync(SPEC, 'utf8');
    const rows = [['row 1', 'This can take up to 60 seconds.', n5.detail], ['row 2', ROW2, n5.cancel.title], ['row 3', ROW3, n5.force.title], ['row 4 (ending, unchanged)', 'This can take up to 30 seconds.', en30late.detail.split(' An interrupted')[0]], ['row 5 (closing status, unchanged)', 'Gemma released from GPU. Closing\u2026', null]];
    const [c5] = await feed('068', [closing({ late: false })]);
    rows[4][2] = c5.status;
    const compared = rows.map(([name, specText, shipped]) => ({ name, inSpec: spec.includes(specText), equal: specText === shipped, shipped }));
    out.c711 = compared;
    check('C7-11: the shipped strings of rows 1 to 5 equal the Rev 3 section character by character (each is found verbatim in the spec file)', compared.every(c => c.inSpec && c.equal), { compared });
    out.quit = await E.quitViaTray('c7-dom end', { staleClaimsOk: true });
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  };
}
