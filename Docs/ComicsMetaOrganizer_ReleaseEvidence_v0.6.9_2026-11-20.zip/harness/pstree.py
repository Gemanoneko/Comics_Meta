"""Futaba 0.6.8 harness helper: list the descendants of a process (Toolhelp snapshot, no PowerShell, read only).
Usage (packaged python, -B -I): pstree.py <pid> [<pid> ...]
Prints one JSON line: {"<pid>": [{"pid":..,"ppid":..,"exe":..}, ...descendants...]}"""
import ctypes as C
import json
import sys
from ctypes import wintypes as W

TH32CS_SNAPPROCESS = 2


class ENTRY(C.Structure):
    _fields_ = [('dwSize', W.DWORD), ('cntUsage', W.DWORD), ('th32ProcessID', W.DWORD), ('th32DefaultHeapID', C.c_void_p),
                ('th32ModuleID', W.DWORD), ('cntThreads', W.DWORD), ('th32ParentProcessID', W.DWORD),
                ('pcPriClassBase', C.c_long), ('dwFlags', W.DWORD), ('szExeFile', C.c_wchar * 260)]


K = C.WinDLL('kernel32', use_last_error=True)
K.CreateToolhelp32Snapshot.restype = W.HANDLE
K.CreateToolhelp32Snapshot.argtypes = [W.DWORD, W.DWORD]
K.Process32FirstW.argtypes = [W.HANDLE, C.POINTER(ENTRY)]
K.Process32NextW.argtypes = [W.HANDLE, C.POINTER(ENTRY)]
K.CloseHandle.argtypes = [W.HANDLE]


def processes():
    snapshot = K.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    rows = []
    entry = ENTRY()
    entry.dwSize = C.sizeof(ENTRY)
    ok = K.Process32FirstW(snapshot, C.byref(entry))
    while ok:
        rows.append({'pid': entry.th32ProcessID, 'ppid': entry.th32ParentProcessID, 'exe': entry.szExeFile})
        ok = K.Process32NextW(snapshot, C.byref(entry))
    K.CloseHandle(snapshot)
    return rows


def descendants(root, rows):
    found, queue = [], [root]
    while queue:
        parent = queue.pop()
        for row in rows:
            if row['ppid'] == parent and row['pid'] != parent and row['pid'] not in [f['pid'] for f in found]:
                found.append(row)
                queue.append(row['pid'])
    return found


if __name__ == '__main__':
    rows = processes()
    print(json.dumps({str(pid): descendants(int(pid), rows) for pid in sys.argv[1:]}))
