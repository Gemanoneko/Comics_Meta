// Futaba 0.6.8 QA scenarios, part 3: q1 (unopenable claim lock), Q3 (a late exit of an old broker), q2 (store-dated nested-only comics).
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { launch, setupLibrary, waitFor, sleep, win, PY, BASE, pidAlive, portRefused, runInfoForEvidence, EXTRACT } from './lib.mjs';

const ENGINE = EXTRACT + '/resources/engine';
const H = BASE + '/evidence/harness';
const HEAD = 'The previous session is still closing.';

export function registerMore(E) {
  const { S, out, check, must } = E;
  const h = E.h;
  const startupSnap = async () => { const r = JSON.parse(await E.run.inspector.evaluate("JSON.stringify(globalThis.__qa.samples.filter(s=>s.snap&&s.snap.file==='startup.html').slice(-1))")); return r[0] && r[0].snap; };
  const everSaw = async text => JSON.parse(await E.run.inspector.evaluate("JSON.stringify(globalThis.__qa.samples.filter(s=>s.snap&&s.snap.file==='startup.html'&&s.snap.status&&s.snap.status.text.indexOf(" + JSON.stringify(text) + ")>=0).length)")) > 0;
  const freshPid = () => { for (let pid = 3999996; pid > 3999000; pid -= 4) if (!pidAlive(pid)) return pid; throw new Error('no free pid'); };
  const leftoverRecord = (info, owner, ageSeconds) => { const f = path.win32.join(info.locks, 'leftover-' + owner + '.json'); fs.writeFileSync(f, JSON.stringify({ schema: 1, owner, written: Date.now() / 1000 - ageSeconds, members: null, source: 'shell' })); return f; };

  // -------------------------------------------------------------------------------------------------------------------
  // q1: a read-only claim lock nobody holds + a shell-written leftover record (members null) starts normally; a HELD lock still waits.
  // -------------------------------------------------------------------------------------------------------------------
  E.scenarios['q1-claims'] = async () => {
    await E.startup('q1', async info => { E.emptyLibrary(info); });
    const info = { tmp: E.run.tmp, root: E.run.root, state: E.run.state, locks: E.run.locks };
    const lib = path.win32.join(info.root, 'library');
    await setupLibrary(E.run, lib);
    await E.readyEngine('q1 setup run', 1);
    out.firstRun = await E.quitViaTray('q1 first run (sets the library up)');
    must(out.firstRun.exit && out.firstRun.exit.code === 0, 'first run quit');
    const claimsDir = path.win32.join(info.locks, 'claims');
    // A genuine claim pair of a dead engine: the app is started and every process of it is ended at once (a crash), which leaves the
    // engine's own claims/engine-<owner>-<pid>-<id>.lock and .json behind, exactly as the 0.6.7 passes saw after an outside end.
    async function crash(tag) {
      for (const n of fs.existsSync(claimsDir) ? fs.readdirSync(claimsDir) : []) { const f = path.win32.join(claimsDir, n); try { fs.chmodSync(f, 0o666); fs.unlinkSync(f); } catch { } }  // the earlier phase's files only
      await h.relaunch(tag, info);
      await E.readyEngine(tag + ' (to be ended)', 1);
      const stop = await h.killAll(E.run, tag + ': every process of the app ended at once');
      const names = fs.readdirSync(claimsDir).filter(n => /^engine-[0-9a-f]{64}-\d+-[0-9a-f]{12}\.(lock|json)$/.test(n));
      const locks = names.filter(n => n.endsWith('.lock')).map(n => path.win32.join(claimsDir, n)), lock = locks[0], rec = names.find(n => n.endsWith('.json'));
      const owner = /^engine-([0-9a-f]{64})-/.exec(path.win32.basename(lock))[1];
      return { stop, lock, locks, json: path.win32.join(claimsDir, rec), owner, names: names.length };
    }
    // --- the case Senua probed: a record without a process list, 1 day old, and a read-only claim lock nobody holds
    const c1 = await crash('q1x');
    check('q1 fixture: a crash left the engine\'s genuine claim lock and record (every process of the first session gone)', c1.stop.stillAlive.length === 0 && fs.existsSync(c1.lock) && fs.existsSync(c1.json), { claimFiles: c1.names, stillAlive: c1.stop.stillAlive });
    const record = leftoverRecord(info, c1.owner, 86400);
    for (const l of c1.locks) fs.chmodSync(l, 0o444);  // every claim lock of that engine, not only one
    const claimBody = JSON.parse(fs.readFileSync(c1.json, 'utf8'));
    check('q1 fixture: a shell-written leftover record (members null, 1 day old) for that engine, and its claim lock made read-only (nobody holds it)', fs.existsSync(record) && c1.locks.every(l => (fs.statSync(l).mode & 0o200) === 0) && JSON.parse(fs.readFileSync(record, 'utf8')).members === null && claimBody.pid && !pidAlive(claimBody.pid), { lockReadOnly: c1.locks.length + ' claim locks', ageSeconds: 86400, claimPid: claimBody.pid, claimPidAlive: pidAlive(claimBody.pid), role: claimBody.role });
    const t0 = Date.now();
    await h.relaunch('q1b', info);
    const outcome = await waitFor(async () => { const st = await E.run.qa('state()', true); return ['ready', 'setup', 'failed'].includes(st.service) && st; }, 'start outcome', 90000, 200);
    const tReady = Date.now() - t0;
    const page = await E.run.qa('page()', true);
    const sawWaiting = await everSaw(HEAD);
    const log = h.engineLog(info);
    out.q1 = { service: outcome.service, failure: outcome.failure || null, startMs: tReady, page: page.url.replace(/:\d+/, ':<port>').split('/').slice(-1)[0] || 'dashboard', recordLeft: fs.existsSync(record), sawPreviousSessionScreen: sawWaiting,
      logLines: log.split(/\r?\n/).filter(l => /Leftover record|Claim lock/.test(l)) };
    check('q1: the start is normal (ready, dashboard, no "previous session still closing" screen at any moment) and the leftover record is gone', outcome.service === 'ready' && !outcome.failure && !sawWaiting && !fs.existsSync(record), out.q1);
    check('q1: engine.log says the record had no process list, its claims were checked, 0 held, nothing left, record removed', out.q1.logLines.some(l => /no process list, so its engine claims are checked: 0 held/.test(l)) && out.q1.logLines.some(l => /nothing of that session is left; record removed/.test(l)), { lines: out.q1.logLines });
    out.q1quit = await E.quitViaTray('q1 normal start', { staleClaimsOk: true });
    // --- positive control: the same, but a live process really holds the (read-only) claim lock
    const c2 = await crash('q1y');
    const record2 = leftoverRecord(info, c2.owner, 86400);
    const holder = spawn(PY, ['-B', '-I', H + '/holdclaim.py', win(ENGINE), c2.lock], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    let hout = ''; holder.stdout.on('data', d => { hout += d; });
    const holderExit = new Promise(resolve => holder.once('exit', code => resolve(code)));
    await waitFor(() => /locked/.test(hout), 'claim lock held', 20000, 50);
    fs.chmodSync(c2.lock, 0o444);  // read-only AND held: what the old code could not tell apart from "nobody holds it"
    check('q1 positive-control fixture: a leftover record (members null) and the engine\'s claim lock, read-only, really held by a live process', fs.existsSync(record2) && (fs.statSync(c2.lock).mode & 0o200) === 0 && /locked/.test(hout), { holder: hout.trim().split('\n').slice(-1)[0].slice(0, 24) });
    const t1 = Date.now();
    await h.relaunch('q1c', info);
    const waiting = await waitFor(async () => { const st = await E.run.qa('state()', true); return ['ready', 'setup', 'failed'].includes(st.service) && st; }, 'positive-control outcome', 90000, 200);
    await sleep(600);
    const snap = await startupSnap();
    out.q1control = { service: waiting.service, failure: waiting.failure || null, afterMs: Date.now() - t1, heading: snap && snap.status && snap.status.text, detail: snap && snap.detail && snap.detail.text, buttons: snap && ['retry', 'logs', 'quit'].map(k => snap[k] && snap[k].text + (snap[k].disabled ? ' (disabled)' : '')), recordLeft: fs.existsSync(record2) };
    check('q1 positive control: a HELD lock still shows "The previous session is still closing." (failure PREVIOUS_CLOSING) and keeps the record', waiting.service === 'failed' && waiting.failure === 'PREVIOUS_CLOSING' && snap && snap.status.text === HEAD && fs.existsSync(record2), out.q1control);
    // Quit from this top-level screen (tray Quit), then start again with the holder still alive: the same screen again
    out.quitPrevScreen = await E.quitViaTray('previous-session screen', { staleClaimsOk: true, delay: 300 });
    await h.relaunch('q1c2', info);
    const again = await waitFor(async () => { const st = await E.run.qa('state()', true); return ['ready', 'setup', 'failed'].includes(st.service) && st; }, 'positive-control outcome (second start)', 90000, 200);
    check('q1 positive control, second start with the lock still held: the same "previous session still closing" screen again (failure PREVIOUS_CLOSING), record kept', again.service === 'failed' && again.failure === 'PREVIOUS_CLOSING' && fs.existsSync(record2), { service: again.service, failure: again.failure });
    // release the holder: Try again then starts normally and the record goes
    try { holder.stdin.end(); } catch { }
    await Promise.race([holderExit, sleep(15000)]);
    await sleep(500);
    const tc = Date.now();
    await E.run.qa('clickRetry()', true);
    const after = await waitFor(async () => { const st = await E.run.qa('state()', true); return ['ready', 'setup'].includes(st.service) && st; }, 'start after the holder ended', 90000, 200);
    out.q1after = { service: after.service, recordLeft: fs.existsSync(record2), msAfterTryAgain: Date.now() - tc };
    check('q1 positive control, released: the holder ends, Try again starts normally and the record is removed', after.service === 'ready' && !fs.existsSync(record2), out.q1after);
    out.q1controlQuit = await E.quitViaTray('q1 control end', { staleClaimsOk: true });
    // --- edge probe (observation only, outside the brief's list): the same read-only claim locks but their .json records are gone
    const c3 = await crash('q1z');
    for (const n of fs.readdirSync(claimsDir).filter(n => n.endsWith('.json'))) { try { fs.unlinkSync(path.win32.join(claimsDir, n)); } catch { } }
    for (const l of c3.locks) fs.chmodSync(l, 0o444);
    const record3 = leftoverRecord(info, c3.owner, 86400);
    await h.relaunch('q1d', info);
    const edge = await waitFor(async () => { const st = await E.run.qa('state()', true); return ['ready', 'setup', 'failed'].includes(st.service) && st; }, 'edge probe outcome', 90000, 200);
    await sleep(500);
    const esnap = await startupSnap();
    const logText = h.engineLog(info);
    out.edgeProbe = { service: edge.service, failure: edge.failure || null, heading: esnap && esnap.status && esnap.status.text, recordLeft: fs.existsSync(record3), claimFilesLeft: fs.readdirSync(claimsDir).length, logLines: logText.split(/\r?\n/).filter(l => /Another Comics Meta|Claim lock|no process list/.test(l)).slice(-4) };
    // 0.6.9 (Futaba's 0.6.8 finding 1, library_lock._open_claim): the same probe is now an assertion: the start reaches the dashboard
    check('0.6.9 edge probe (0.6.8 finding 1, the brief\'s item 6): read-only claim locks nobody holds, their .json records missing (plus the shell-written leftover record): the start reaches the DASHBOARD (ready, no failure, no "previous session" screen)', edge.service === 'ready' && !edge.failure && !(await everSaw(HEAD)) && out.edgeProbe.heading !== 'Could not start the local service', out.edgeProbe);
    out.quit = await E.quitViaTray('q1 edge probe end', { staleClaimsOk: true });
    // --- edge 2: the same without any leftover record (only library_lock's claim scan applies)
    const c4 = await crash('q1e2');
    for (const n of fs.readdirSync(claimsDir).filter(n => n.endsWith('.json'))) { try { fs.unlinkSync(path.win32.join(claimsDir, n)); } catch { } }
    for (const l of c4.locks) fs.chmodSync(l, 0o444);
    await h.relaunch('q1e2b', info);
    const edge2 = await waitFor(async () => { const st = await E.run.qa('state()', true); return ['ready', 'setup', 'failed'].includes(st.service) && st; }, 'edge 2 outcome', 90000, 200);
    out.edge2 = { service: edge2.service, failure: edge2.failure || null, claimFilesLeft: fs.readdirSync(claimsDir).length, logLines: h.engineLog(info).split(/\r?\n/).filter(l => /Another Comics Meta|cannot be opened|Claim lock|no process list/.test(l)).slice(-4) };
    check('0.6.9 edge 2: the same read-only locks with no .json records and NO leftover record: the start reaches the dashboard', edge2.service === 'ready' && !edge2.failure, out.edge2);
    out.quitEdge2 = await E.quitViaTray('q1 edge 2 end', { staleClaimsOk: true });
    // --- control D: a read-only lock with no .json record that a live process REALLY holds still refuses (LIBRARY_BUSY), and starts once it is released
    const c5 = await crash('q1d2');
    for (const n of fs.readdirSync(claimsDir).filter(n => n.endsWith('.json'))) { try { fs.unlinkSync(path.win32.join(claimsDir, n)); } catch { } }
    const holder5 = spawn(PY, ['-B', '-I', H + '/holdclaim.py', win(ENGINE), c5.lock], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    let h5 = ''; holder5.stdout.on('data', d => { h5 += d; });
    const holder5Exit = new Promise(resolve => holder5.once('exit', code => resolve(code)));
    await waitFor(() => /locked/.test(h5), 'claim lock held (control D)', 20000, 50);
    for (const l of c5.locks) fs.chmodSync(l, 0o444);  // read-only AND really held, its record missing
    check('0.6.9 control D fixture: a claim lock, read-only, really held by a live process, its .json record missing, no leftover record', c5.locks.every(l => (fs.statSync(l).mode & 0o200) === 0) && /locked/.test(h5) && !fs.readdirSync(claimsDir).some(n => n.endsWith('.json')), { locks: c5.locks.length });
    await h.relaunch('q1d3', info);
    const ctl = await waitFor(async () => { const st = await E.run.qa('state()', true); return ['ready', 'setup', 'failed'].includes(st.service) && st; }, 'control D outcome', 90000, 200);
    await sleep(600);
    const csnap = await startupSnap();
    out.controlD = { service: ctl.service, failure: ctl.failure || null, heading: csnap && csnap.status && csnap.status.text, detail: csnap && csnap.detail && csnap.detail.text, logLines: h.engineLog(info).split(/\r?\n/).filter(l => /Another Comics Meta|cannot be opened|Claim lock/.test(l)).slice(-3) };
    check('0.6.9 control D: the really held read-only lock still REFUSES the start (failed screen, LIBRARY_BUSY "Another Comics Meta copy is using this library")', ctl.service === 'failed' && ctl.failure === 'LIBRARY_BUSY', out.controlD);
    out.quitControlD = await E.quitViaTray('q1 control D screen', { staleClaimsOk: true });
    try { holder5.stdin.end(); } catch { }
    await Promise.race([holder5Exit, sleep(15000)]);
    await sleep(500);
    await h.relaunch('q1d4', info);
    const rel = await waitFor(async () => { const st = await E.run.qa('state()', true); return ['ready', 'setup', 'failed'].includes(st.service) && st; }, 'control D after release', 90000, 200);
    out.controlDReleased = { service: rel.service, failure: rel.failure || null };
    check('0.6.9 control D, released: with the holder ended the next start reaches the dashboard', rel.service === 'ready' && !rel.failure, out.controlDReleased);
    out.quit = await E.quitViaTray('q1 control D end', { staleClaimsOk: true });
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  };

  // -------------------------------------------------------------------------------------------------------------------
  // Q3: the old broker is frozen, the start fails, Retry starts a new broker beside it, the old broker thaws and exits late:
  // the new engine stays ready (before 0.6.8 its exit marked the healthy engine not ready and the auto-restart force-stopped it).
  // -------------------------------------------------------------------------------------------------------------------
  E.scenarios['q3-late-exit'] = async () => {
    const WAIT = 12;
    let attempt = 0, froze = null;
    while (!froze && attempt < 4) {
      attempt++;
      await E.startup('q3a' + attempt, async info => { E.emptyLibrary(info); }, { policyExtra: { closureWaitSeconds: WAIT } });
      await E.run.qa('sampleStart(40)');
      const info = { tmp: E.run.tmp, root: E.run.root, state: E.run.state, locks: E.run.locks };
      const broker = (await waitFor(async () => { const e = await E.run.engines(); return e.length >= 1 && e[0]; }, 'broker spawned', 20000, 10)).pid;
      const tSpawn = Date.now();
      const holdA = await E.hold(broker, { mode: 'freeze', seconds: 400 });
      const tHeld = Date.now();
      const kids = h.descendantsOf(broker);
      for (const k of kids.slice().reverse()) { try { process.kill(k.pid); } catch { } }
      const tKilled = Date.now();
      const st = await E.run.qa('state()', true);
      const ready = await E.run.engines().then(e => e.length).catch(() => -1);
      out['attempt' + attempt] = { brokerPid: broker, freezeHeldAfterMs: tHeld - tSpawn, childrenKilledAfterMs: tKilled - tSpawn, children: kids.map(k => k.pid + ':' + k.exe), serviceAtKill: st.service, startupPhase: st.startupPhase };
      if (st.service === 'starting') { froze = { broker, holdA, info }; break; }
      // the engine reached ready before the freeze: start over
      try { await holdA.release(); } catch { }
      await sleep(500);
      try { E.run.child.kill(); } catch { }
      await Promise.race([E.run.exited, sleep(8000)]);
    }
    must(froze, 'old broker frozen and its engine ended while the shell was still starting');
    const { broker: oldBroker, holdA, info } = froze;
    check('the first broker is frozen (tests/debug_hold.py --mode freeze) and its engine process ended while the shell was still starting it: the endpoint cannot answer', out['attempt' + attempt].serviceAtKill === 'starting', out['attempt' + attempt]);
    // the shell gives up on the unresponsive start, force-stops (gives up after the closure wait + 1 s), and shows the failed screen
    const t0 = Date.now();
    const failed = await waitFor(async () => { const s = await E.run.qa('state()', true); return s.service === 'failed' && s; }, 'failed screen', 120000, 300);
    out.failed = { failure: failed.failure, afterMs: Date.now() - t0 };
    check('the start failed after the unresponsive-start wait and the forced stop (failure START_UNRESPONSIVE)', failed.failure === 'START_UNRESPONSIVE', out.failed);
    const brokersBeforeRetry = (await E.run.engines()).length;
    // Retry: the same control the failed screen offers (a DOM click in the offscreen renderer)
    const tRetry = Date.now();
    await E.run.qa('clickRetry()', true);
    const second = await waitFor(async () => { const e = await E.run.engines(); const s = await E.run.qa('state()', true); return e.length === 2 && !e[1].exit && ['ready', 'setup'].includes(s.service) && { newBroker: e[1].pid, service: s.service }; }, 'new broker ready after Retry', 150000, 300);
    out.retry = { newBroker: second.newBroker, oldBroker, retryToReadyMs: Date.now() - tRetry, brokersBefore: brokersBeforeRetry, service: second.service };
    check('Retry started a NEW broker beside the frozen one and it is ready (old broker still frozen and alive)', second.newBroker !== oldBroker && pidAlive(oldBroker) && second.service !== 'failed', out.retry);
    const newStatus = await E.run.shellStatus();
    check('the new engine is owned and answering (HTTP 200, version 0.6.8)', newStatus.http === 200 && newStatus.body.owned === true && newStatus.body.version === '0.6.9', { http: newStatus.http, owned: newStatus.body.owned, version: newStatus.body.version });
    // thaw the old broker: it ends late
    const tThaw = Date.now();
    await holdA.release();
    const oldExit = await waitFor(async () => { const e = (await E.run.engines())[0]; return e.exit && e; }, 'old broker exit recorded', 60000, 100).catch(() => null);
    out.oldBrokerExit = oldExit && { code: oldExit.exit.code, signal: oldExit.exit.signal, afterThawMs: oldExit.exit.t - tThaw };
    check('after the thaw the OLD broker exits (its late exit reached the shell)', Boolean(oldExit), out.oldBrokerExit || { note: 'old broker did not exit within 60 s' });
    // watch the new engine for 25 s: it must stay ready, not be restarted, not be force-stopped
    const watch = [];
    const tw = Date.now();
    while (Date.now() - tw < 25000) {
      const e = await E.run.engines();
      const s = await E.run.qa('state()', true);
      const st = await E.run.shellStatus().then(r => r.http, () => 'no answer');
      watch.push({ t: Date.now() - tw, brokers: e.length, newExit: e[1] && e[1].exit, service: s.service, statusHttp: st });
      await sleep(1000);
    }
    const bad = watch.filter(w => w.brokers !== 2 || w.newExit || !['ready', 'setup'].includes(w.service) || w.statusHttp !== 200);
    out.watch = { samples: watch.length, bad: bad.slice(0, 5), last: watch[watch.length - 1] };
    check('Q3: for 25 s after the old broker thawed and exited, the new engine stayed ready: still 2 brokers (no restart), the new broker never exited, the shell service never left ready/setup, /api/shell/status answered 200 every second', bad.length === 0 && Boolean(oldExit), out.watch);
    const sh = await E.run.shellStatus();
    check('the new engine is still the same owned engine afterwards', sh.http === 200 && sh.body.owned === true && pidAlive(second.newBroker), { http: sh.http, newBrokerAlive: pidAlive(second.newBroker) });
    // positive control: the CURRENT broker's exit still counts (the shell restarts the engine)
    const tk = Date.now();
    process.kill(second.newBroker);
    const restarted = await waitFor(async () => { const e = await E.run.engines(); const s = await E.run.qa('state()', true); return e.length >= 3 && !e[e.length - 1].exit && ['ready', 'setup'].includes(s.service) && { brokers: e.length, newest: e[e.length - 1].pid }; }, 'restart after the current broker was ended', 60000, 300).catch(() => null);
    out.control = restarted && { ...restarted, afterMs: Date.now() - tk };
    check('positive control: ending the CURRENT broker from outside still makes the shell restart the engine (a third broker, ready)', Boolean(restarted), out.control || { note: 'no restart seen' });
    out.quit = await E.quitViaTray('Q3 end', { staleClaimsOk: true });
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  };
}
