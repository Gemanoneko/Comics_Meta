"""Futaba 0.6.8 harness helper (q1 positive control): hold one engine claim lock (byte 0, the app's own file_lock) until stdin closes.
Usage (packaged python, -B -I): holdclaim.py <engine folder> <lock file>
Prints "locked <path>" once it holds the byte, "released" when stdin closes."""
import sys
from pathlib import Path

sys.path.insert(0, sys.argv[1])
import file_lock

path = Path(sys.argv[2])
fd = file_lock.open_lock(path, create=True)
if not file_lock.try_lock(fd):
    print('could not lock', flush=True)
    raise SystemExit(2)
print('locked ' + str(path), flush=True)
sys.stdin.read()
file_lock.unlock(fd)
print('released', flush=True)
