"""Futaba 0.6.8 harness helper (R2, a real stopped merge): open one file with FILE_SHARE_READ only (a reader that lets nobody write) the
moment stdin gets a line, and hold it until stdin closes. The merge tool's flush of the written archive then cannot open it for writing.
Usage (packaged python, -B -I): holdshare.py <file>"""
import ctypes as C
import sys
from ctypes import wintypes as W

K = C.WinDLL('kernel32', use_last_error=True)
K.CreateFileW.restype = W.HANDLE
K.CreateFileW.argtypes = [W.LPCWSTR, W.DWORD, W.DWORD, C.c_void_p, W.DWORD, W.DWORD, W.HANDLE]
K.CloseHandle.argtypes = [W.HANDLE]
INVALID = W.HANDLE(-1).value
print('ready', flush=True)
sys.stdin.readline()
handle = K.CreateFileW(sys.argv[1], 0x80000000, 0x1, None, 3, 0x80, None)  # GENERIC_READ, FILE_SHARE_READ, OPEN_EXISTING
if handle == INVALID or handle is None:
    print('open failed %d' % C.get_last_error(), flush=True)
    raise SystemExit(2)
print('held', flush=True)
sys.stdin.read()
K.CloseHandle(handle)
print('released', flush=True)
