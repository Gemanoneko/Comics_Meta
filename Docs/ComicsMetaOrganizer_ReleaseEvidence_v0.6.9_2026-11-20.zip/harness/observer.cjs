(function () {
  // Futaba 0.6.7 QA observer: evaluated on the first call frame of the packaged main process (before main.cjs runs).
  // It records, guards and exposes the REAL tray menu callbacks; it never stands in for app behaviour.
  const fs = require('node:fs'), path = require('node:path'), cp = require('node:child_process'), crypto = require('node:crypto');
  const electron = require('electron');
  const CFG = __CFG__;
  const { app, BrowserWindow, Tray, Notification, dialog, shell, nativeImage, Menu } = electron;
  const q = globalThis.__qa = { cfg: CFG, engines: [], violations: [], guards: [], menu: null, trayLog: [], otherSpawns: [], loads: [] };
  const sha = b => crypto.createHash('sha256').update(b).digest('hex');
  const ev = (kind, data) => {
    const rec = { t: Date.now(), kind, ...(data || {}) };
    try { fs.appendFileSync(CFG.events, JSON.stringify(rec) + '\n'); } catch (e) { }
    return rec;
  };
  const violate = label => { const v = { guard: label, t: Date.now() }; q.violations.push(v); ev('violation', v); };
  const guard = (owner, name, label, block) => {
    const original = owner && owner[name];
    if (typeof original !== 'function') return false;
    owner[name] = function () {
      violate(label);
      if (block) return label.endsWith('Sync') || /Sync$/.test(name) ? undefined : Promise.resolve({ canceled: true, filePaths: [], response: 0 });
      return original.apply(this, arguments);
    };
    q.guards.push(label);
    return true;
  };
  // 1-7: window visibility / focus APIs
  for (const n of ['show', 'showInactive', 'focus', 'moveTop', 'setAlwaysOnTop', 'flashFrame', 'maximize', 'restore'])
    guard(BrowserWindow.prototype, n, 'BrowserWindow.' + n, false);
  // app focus
  guard(app, 'focus', 'app.focus', false);
  // webContents focus on every contents
  app.on('web-contents-created', (_e, wc) => {
    const original = wc.focus;
    wc.focus = function () { violate('webContents.focus'); return original.apply(this, arguments); };
    wc.on('did-finish-load', () => { const rec = { url: wc.getURL(), t: Date.now() }; q.loads.push(rec); ev('load', rec); });
    wc.on('render-process-gone', (_ev, d) => ev('render-gone', { reason: d.reason }));
    // 0.6.7: every change of the startup screen's heading, logged from inside the page (the start phases are too short for a poll).
    const MUT = "(()=>{if(window.__qamut)return;window.__qamut=1;const s=document.getElementById('status');if(!s)return;const log=()=>console.log('QAMUT '+JSON.stringify({s:s.textContent}));new MutationObserver(log).observe(s,{childList:true,characterData:true,subtree:true});log();})()";
    wc.on('dom-ready', () => { try { if (/startup\.html/.test(wc.getURL())) wc.executeJavaScript(MUT).catch(() => { }); } catch (e) { } });
    wc.on('console-message', (...a) => { try { const msg = (a[0] && typeof a[0] === 'object' && 'message' in a[0]) ? a[0].message : a[2]; if (typeof msg === 'string' && msg.startsWith('QAMUT ')) ev('status-mut', JSON.parse(msg.slice(6))); } catch (e) { } });
  });
  q.guards.push('webContents.focus');
  // notifications, dialogs, shell
  const NotificationShow = Notification && Notification.prototype && Notification.prototype.show;
  if (NotificationShow) { Notification.prototype.show = function () { violate('Notification.show'); return NotificationShow.apply(this, arguments); }; q.guards.push('Notification.show'); }
  for (const n of ['showOpenDialog', 'showOpenDialogSync', 'showSaveDialog', 'showSaveDialogSync', 'showMessageBox', 'showMessageBoxSync', 'showErrorBox'])
    guard(dialog, n, 'dialog.' + n, true);
  for (const n of ['openExternal', 'openPath', 'showItemInFolder']) guard(shell, n, 'shell.' + n, true);
  // child processes: only the engine broker spawn is expected
  const realSpawn = cp.spawn;
  cp.spawn = function (file, args, options) {
    const isEngine = Array.isArray(args) && args.length > 1 && /engine_host\.py$/.test(String(args[1])) && /python\.exe$/i.test(String(file));
    if (!isEngine) {
      const rec = { file: String(file), args: (args || []).slice(0, 4).map(String) };
      q.otherSpawns.push(rec); violate('child_process.spawn(other)'); ev('other-spawn', rec);
    }
    const child = realSpawn.apply(this, arguments);
    if (isEngine) {
      const item = { pid: child.pid, token: options && options.env && options.env.COMICS_META_SHELL_TOKEN, owner: options && options.env && options.env.COMICS_META_CLAIM_OWNER, startedAt: Date.now(), exit: null };
      q.engines.push(item);
      child.once('exit', (code, signal) => { item.exit = { code, signal, t: Date.now() }; ev('engine-exit', { pid: child.pid, code, signal }); });
      ev('engine-start', { pid: child.pid, index: q.engines.length - 1 });
    }
    return child;
  };
  for (const n of ['exec', 'execFile', 'fork', 'spawnSync', 'execSync', 'execFileSync']) {
    const original = cp[n];
    if (typeof original === 'function') { cp[n] = function () { violate('child_process.' + n); ev('other-spawn', { api: n }); return original.apply(this, arguments); }; q.guards.push('child_process.' + n); }
  }
  q.guards.push('child_process.spawn(other)');
  // tray: record every image the app hands to the real Tray.setImage, and the real menu
  const imageSummary = image => {
    const b1 = image.toBitmap({ scaleFactor: 1 }), b05 = image.toBitmap({ scaleFactor: 0.5 });
    return { bm1: sha(b1), len1: b1.length, bm05: sha(b05), len05: b05.length, size1: image.getSize(1) };
  };
  const realSetImage = Tray.prototype.setImage;
  Tray.prototype.setImage = function (image) {
    const rec = { t: Date.now(), ...imageSummary(image) };
    q.trayLog.push({ type: 'image', ...rec }); ev('tray-image', rec);
    return realSetImage.call(this, image);
  };
  const realTip = Tray.prototype.setToolTip;
  Tray.prototype.setToolTip = function (tip) { q.trayLog.push({ type: 'tip', tip: String(tip), t: Date.now() }); ev('tray-tip', { tip: String(tip) }); return realTip.call(this, tip); };
  const realMenu = Tray.prototype.setContextMenu;
  Tray.prototype.setContextMenu = function (menu) {
    q.menu = menu;
    ev('tray-menu', { items: menu.items.map(i => ({ label: i.label, enabled: i.enabled, type: i.type })) });
    return realMenu.call(this, menu);
  };
  process.on('exit', code => ev('main-exit', { code }));
  // expected bitmaps, built the way main.cjs trayImage() builds them, from the packaged archive
  q.expected = () => {
    const out = {};
    const dir = path.join(app.getAppPath(), 'desktop', 'assets');
    for (const name of ['processing', 'paused', 'verification', 'error']) {
      const big = path.join(dir, 'tray-' + name + '.png'), small = path.join(dir, 'tray-' + name + '-16.png');
      const image = nativeImage.createFromPath(big);
      image.addRepresentation({ scaleFactor: 0.5, buffer: fs.readFileSync(small) });
      out[name] = { file: sha(fs.readFileSync(big)), file16: sha(fs.readFileSync(small)), ...imageSummary(image) };
    }
    return out;
  };
  // hashes of the files this very process runs from (the tested runtime)
  q.binaries = () => { const raw = require('original-fs'); return { exe: sha(raw.readFileSync(process.execPath)), asar: sha(raw.readFileSync(path.join(process.resourcesPath, 'app.asar'))), execPath: process.execPath, resources: process.resourcesPath }; };
  q.win = () => BrowserWindow.getAllWindows().find(w => !w.isDestroyed());
  q.windows = () => BrowserWindow.getAllWindows().map(w => ({ destroyed: w.isDestroyed(), url: w.isDestroyed() ? null : w.webContents.getURL(), visible: w.isDestroyed() ? null : w.isVisible(), focused: w.isDestroyed() ? null : w.isFocused(), minimized: w.isDestroyed() ? null : w.isMinimized(), offscreen: w.isDestroyed() ? null : w.webContents.isOffscreen() }));
  q.menuItems = () => (q.menu ? q.menu.items.map(i => ({ label: i.label, enabled: i.enabled })) : null);
  q.page = () => q.win().webContents.executeJavaScript("(()=>{const n=document.querySelector('.shell-notice');const noticeOpen=!!n&&!n.hidden;const retry=document.getElementById('retry');const actions=document.getElementById('actions');return {url:location.href,title:document.title,text:(document.body&&document.body.innerText||'').slice(0,400),notice:noticeOpen?n.innerText.split(String.fromCharCode(10)).join(' ').slice(0,240):null,tryAgain:noticeOpen&&Array.from(n.querySelectorAll('button')).some(b=>b.textContent==='Try again'&&!b.disabled),retryVisible:!!retry&&!retry.hidden&&!(actions&&actions.hidden),ready:document.readyState};})()");
  q.rend = code => q.win().webContents.executeJavaScript(code);
  q.state = () => q.win().webContents.executeJavaScript("new Promise((resolve,reject)=>{let off;const timer=setTimeout(()=>reject(Error('Shell snapshot timeout')),5000);off=window.comicDesktop.onState(value=>{clearTimeout(timer);off&&off();resolve(value);});})");
  q.action = name => { q.actionPromise = q.win().webContents.executeJavaScript('window.comicDesktop.action(' + JSON.stringify(name) + ')'); return q.actionPromise; };
  q.clickRetry = () => { ev('retry-click', {}); return q.win().webContents.executeJavaScript("(()=>{const b=document.getElementById('retry'),a=document.getElementById('actions');if(b&&!b.hidden&&!b.disabled&&!(a&&a.hidden)){b.click();return 'startup-screen-retry';}const n=document.querySelector('.shell-notice');if(n&&!n.hidden){const t=Array.from(n.querySelectorAll('button')).find(x=>x.textContent==='Try again'&&!x.disabled);if(t){t.click();return 'dashboard-try-again';}}return false;})()"); };
  q.click = label => {
    const item = q.menu && q.menu.items.find(i => i.label === label && i.enabled);
    if (!item) throw Error('Real tray item unavailable: ' + label);
    ev('tray-click', { label });
    q.lastClick = Promise.resolve(item.click());
    return 'real ' + label + ' requested';
  };
  q.clickLater = (label, ms) => { setTimeout(() => { try { const item = q.menu && q.menu.items.find(i => i.label === label && i.enabled); ev('tray-click', { label, later: ms, found: !!item }); if (item) item.click(); } catch (e) { ev('tray-click-error', { message: String(e && e.message) }); } }, ms); return 'scheduled'; };
  q.closeButton = () => {
    const w = q.win();
    const before = { visible: w.isVisible(), destroyed: w.isDestroyed(), count: BrowserWindow.getAllWindows().length };
    w.close();
    const after = { visible: w.isDestroyed() ? null : w.isVisible(), destroyed: w.isDestroyed(), count: BrowserWindow.getAllWindows().length };
    ev('close-button', { before, after });
    return { before, after };
  };
  // 0.6.7: a sampler that reads every shell page (startup, setup, stopping) from the main process every few ms and records each
  // CHANGE with its time, in memory and in events.jsonl (so it survives the inspector being closed before a Quit). It only reads
  // DOM text, hidden/disabled flags and rects; it clicks nothing and focuses nothing.
  const SNAP = "(()=>{if(location.protocol!=='file:')return {file:'http-page'};const $=id=>document.getElementById(id);const rc=e=>{if(!e)return null;const b=e.getBoundingClientRect();return [Math.round(b.x*10)/10,Math.round(b.y*10)/10,Math.round(b.width*10)/10,Math.round(b.height*10)/10];};const bt=id=>{const b=$(id);return b?{text:b.textContent,hidden:b.hidden,disabled:b.disabled,busy:b.getAttribute('aria-busy'),title:b.title,rect:rc(b)}:null;};const tx=id=>{const e=$(id);return e?{text:e.textContent,hidden:e.hidden,vis:getComputedStyle(e).visibility,role:e.getAttribute('role'),rect:rc(e)}:null;};return {file:location.pathname.split('/').pop(),iw:innerWidth,ih:innerHeight,sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,ready:document.readyState,title:tx('title'),status:tx('status'),detail:tx('detail'),checked:tx('checked'),actions:$('actions')?{hidden:$('actions').hidden,rect:rc($('actions'))}:null,retry:bt('retry'),logs:bt('logs'),quit:bt('quit'),cancel:bt('cancel'),force:bt('force')};})()";
  q.samples = [];
  q.sampleStart = (every = 40) => {
    if (q.sampler) return 'already';
    const last = new Map(); let busy = false;
    q.sampler = setInterval(async () => {
      if (busy) return; busy = true;
      try {
        const windows = BrowserWindow.getAllWindows();
        for (let i = 0; i < windows.length; i++) {
          const w = windows[i]; if (w.isDestroyed()) continue;
          let snap; const t = Date.now();
          try { snap = await w.webContents.executeJavaScript(SNAP); } catch (e) { snap = { error: String(e && e.message).slice(0, 80) }; }
          const key = JSON.stringify(snap);
          if (last.get(w.id) !== key) {
            last.set(w.id, key);
            const rec = { t, win: w.id, index: i, parent: w.getParentWindow() ? w.getParentWindow().id : null, snap };
            q.samples.push(rec); ev('sample', rec);
          }
        }
      } finally { busy = false; }
    }, every);
    return 'sampling every ' + every + ' ms';
  };
  q.sampleStop = () => { clearInterval(q.sampler); q.sampler = null; return q.samples.length; };
  // Click a page button from the main process at a scheduled time, recorded (a DOM click: no OS mouse, no focus).
  q.pageClickLater = (id, ms) => { setTimeout(() => { try { ev('page-click', { id, later: ms }); q.win().webContents.executeJavaScript("(()=>{const b=document.getElementById(" + JSON.stringify(id) + ");if(b&&!b.disabled)b.click();})()").catch(() => { }); } catch (e) { ev('page-click-error', { message: String(e && e.message) }); } }, ms); return 'scheduled'; };
  q.setContentWidth = (w, h) => { const win = q.win(); win.setContentSize(w, h); const c = win.getContentSize(); return { width: c[0], height: c[1], bounds: win.getBounds() }; };
  q.setOuter = (w, h) => { const win = q.win(); win.setSize(w, h); const c = win.getContentSize(); return { width: c[0], height: c[1], bounds: win.getBounds() }; };
  q.contentSize = () => { const c = q.win().getContentSize(); return { width: c[0], height: c[1] }; };
  // The real application-menu item (File > Exit is the Ctrl+Q callback), found by label; clicked later from the main process.
  const appMenuItem = label => { const find = items => { for (const i of items) { if (i.label === label) return i; if (i.submenu) { const r = find(i.submenu.items); if (r) return r; } } return null; }; const m = Menu.getApplicationMenu(); return m ? find(m.items) : null; };
  q.menuClickLater = (label, ms) => { setTimeout(() => { try { const item = appMenuItem(label); ev('menu-click', { label, later: ms, found: !!item }); if (item) item.click(); } catch (e) { ev('menu-click-error', { message: String(e && e.message) }); } }, ms); return 'scheduled'; };
  // Probes run inside the main process (the inspector is closed before a Quit): once the quit dialog has shown its ENDING
  // text for afterMs, send it Escape, call close() on it (what its window close button does) and click File > Exit (a second
  // Ctrl+Q), then record whether anything changed. No OS key, mouse or focus is involved.
  q.armEndingProbes = (afterMs = 3000) => {
    if (q.probeTimer) return 'armed';
    let seenAt = null, done = false;
    const live = () => BrowserWindow.getAllWindows().filter(w => !w.isDestroyed());
    q.probeTimer = setInterval(async () => {
      if (done) return;
      const dlg = live().find(w => /stopping\.html/.test(w.webContents.getURL()));
      if (!dlg) return;
      let text; try { text = await dlg.webContents.executeJavaScript("document.getElementById('status').textContent"); } catch { return; }
      if (text !== 'Stopping the local service…') return;
      if (seenAt === null) seenAt = Date.now();
      if (Date.now() - seenAt < afterMs) return;
      done = true; clearInterval(q.probeTimer);
      const before = { windows: live().length, pages: live().map(w => w.webContents.getURL().split('/').pop()) };
      const read = () => dlg.isDestroyed() ? Promise.resolve({ destroyed: true }) : dlg.webContents.executeJavaScript("({status:document.getElementById('status').textContent,detail:document.getElementById('detail').textContent,actionsHidden:document.getElementById('actions').hidden})");
      const s0 = await read().catch(e => ({ error: String(e.message) }));
      let escape = null, closeCall = null, exitMenu = null;
      try { await dlg.webContents.executeJavaScript("document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}))"); escape = 'dispatched'; } catch (e) { escape = String(e.message); }
      try { dlg.close(); closeCall = 'called'; } catch (e) { closeCall = String(e.message); }
      try { const item = appMenuItem('&Exit'); if (item) { item.click(); exitMenu = 'clicked'; } else exitMenu = 'not found'; } catch (e) { exitMenu = String(e.message); }
      await new Promise(r => setTimeout(r, 700));
      const s1 = await read().catch(e => ({ error: String(e.message) }));
      ev('ending-probe', { seenForMs: Date.now() - seenAt, before, s0, escape, closeCall, exitMenu, s1, after: { windows: live().length, pages: live().map(w => w.webContents.getURL().split('/').pop()) }, dialogStillThere: !dlg.isDestroyed() });
    }, 100);
    return 'armed';
  };
  // 0.6.8: a DOM click in the quit dialog (Quit now / Cancel quit) from the main process at a scheduled time: no OS mouse, no focus.
  q.dialogClickLater = (id, ms) => { setTimeout(async () => { try {
    const dlg = BrowserWindow.getAllWindows().find(w => !w.isDestroyed() && /stopping\.html/.test(w.webContents.getURL()));
    if (!dlg) { ev('dialog-click', { id, found: false }); return; }
    const info = await dlg.webContents.executeJavaScript("(()=>{const b=document.getElementById(" + JSON.stringify(id) + ");const r=b?{found:true,disabled:b.disabled,hidden:b.hidden,status:document.getElementById('status').textContent}:{found:false};if(b&&!b.disabled&&!b.hidden)b.click();return r;})()");
    ev('dialog-click', { id, ...info });
  } catch (e) { ev('dialog-click-error', { message: String(e && e.message) }); } }, ms); return 'scheduled'; };
  // 0.6.8: harness-only offscreen windows that load a COPY of a dialog page with a stub preload, to feed it states (never shown, never focused).
  q.dom = {};
  q.domOpen = async (url, preload, w, h) => {
    const win = new BrowserWindow({ show: false, width: w, height: h, useContentSize: true, webPreferences: { offscreen: true, contextIsolation: false, nodeIntegration: false, sandbox: false, preload } });
    q.dom[win.id] = win; await win.loadURL(url); return win.id;
  };
  q.domEval = (id, code) => q.dom[id].webContents.executeJavaScript(code);
  q.domClose = id => { try { q.dom[id].destroy(); } catch (e) { } delete q.dom[id]; return true; };
  ev('observer-installed', { pid: process.pid, version: app.getVersion(), packaged: app.isPackaged, guards: q.guards.length });
  return { pid: process.pid, exe: process.execPath, version: app.getVersion(), packaged: app.isPackaged, guards: q.guards.length };
})()
