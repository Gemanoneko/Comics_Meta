// Futaba 0.6.9: replays, read only, the build-record lines of scripts/packaging/install-update-qa/create-local-promotion.mjs (lines 34 to 36, 46 to 56 of the
// 67c7b53 copy) over the actual files: build record (three command arguments: scripts/build-installer.cjs, --inputs, the capsule path; the extra fields), source
// manifest, source archive, installer, feed. Prints one JSON object; exit 1 on any failed check. Usage: node build-record-check.cjs [out.json]
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const cp = require('child_process');
const RC = 'I:/AI Projects/Worktrees/Comics Meta Organizer/rc-069';
const T = 'I:/AI Projects/Temp/cmo-rc069';
const HEAD = '67c7b53008609f7f88879abb0ab339fa4577958e', VERSION = '0.6.9';
const digest = b => crypto.createHash('sha256').update(b).digest('hex');
const owned = JSON.parse(fs.readFileSync(T + '/build-owned-v0.6.9.json', 'utf8'));
const manifestRaw = fs.readFileSync(T + '/source-manifest-67c7b53.json');
const manifest = JSON.parse(manifestRaw);
const archive = fs.readFileSync(T + '/source-67c7b53.tar');
const checks = [];
const need = (name, ok, detail) => checks.push({ name, ok: Boolean(ok), ...(detail ? { detail } : {}) });
const normal = r => r && r.ok === true && r.code === 0 && r.closed === true && r.forced === false && r.timedOut === false && r.outputComplete === true && r.native && r.native.complete === true && r.native.zero === true && ['active', 'assigned', 'listed', 'unsignaled'].every(k => r.native[k] === 0);
need('line 34: manifest.head, build record sourceHead and the repo HEAD are the full commit', manifest.head === HEAD && owned.sourceHead === HEAD && cp.execFileSync('git', ['-C', RC, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim() === HEAD, { head: HEAD });
need('line 34: manifest.archiveSha = SHA-256 of source-67c7b53.tar = build record archiveSha = build record sourceArchive.sha256', manifest.archiveSha === digest(archive) && owned.archiveSha === manifest.archiveSha && owned.sourceArchive && owned.sourceArchive.sha256 === manifest.archiveSha, { archiveSha: manifest.archiveSha });
const git = cp.spawnSync('git', ['archive', '--format=tar', HEAD], { cwd: RC, encoding: null, maxBuffer: 256 * 1024 * 1024, windowsHide: true });
need('line 36: git archive of the commit (rc-069) = the manifest archive hash', git.status === 0 && digest(git.stdout) === manifest.archiveSha);
need('line 46: package.json version and VERSION equal 0.6.9', JSON.parse(fs.readFileSync(RC + '/package.json', 'utf8')).version === VERSION && fs.readFileSync(RC + '/VERSION', 'utf8').trim() === VERSION);
need('line 47: owned build closure (ok, code 0, closed, not forced, native zero, no signal, no error, no overflow/truncation, empty stderr)', normal(owned) && owned.kind === 'result' && owned.signal === null && owned.error === null && owned.overflow === false && owned.truncated === false && owned.supervisorErr === '' && owned.err === '', { ownership: owned.ownership, elapsedMs: Math.round(owned.elapsedMs) });
need('line 48: the build command has three arguments: scripts/build-installer.cjs, --inputs, the capsule path', owned.command && owned.command.args.length === 3 && owned.command.args[1] === '--inputs' && path.resolve(owned.command.args[0]) === path.resolve(RC, 'scripts/build-installer.cjs'), { args: owned.command && owned.command.args });
need('line 48: the node that ran it equals the recorded nodeSha256 / fileSha256 (the build node)', digest(fs.readFileSync(owned.command.file)) === owned.nodeSha256 && owned.fileSha256 === owned.nodeSha256, { node: owned.command.file, sha256: owned.nodeSha256 });
const results = [];
for (const line of owned.out.split(/\r?\n/)) { try { const o = JSON.parse(line); if (o.leanBuild) results.push(o.leanBuild); } catch { } }
need('line 50: exactly one production build receipt in the output', results.length === 1);
const build = results[0] || {};
need('line 51: receipt version 0.6.9, bootstrapExecuted false, referenceEqual true, signCalls 1, and the BUILD OK line names the installer, its size and SHA-256', build.version === VERSION && build.bootstrapExecuted === false && build.referenceEqual === true && build.signCalls === 1 && owned.out.includes('BUILD OK ' + build.installer + ' ' + build.size + ' bytes sha256 ' + build.sha256), { size: build.size, sha256: build.sha256 });
const installer = RC + '/dist/Comic-Metadata-Setup-' + VERSION + '.exe';
const data = fs.readFileSync(installer);
need('line 53: the installer on disk equals the receipt (path, size, SHA-256)', path.resolve(build.installer) === path.resolve(installer) && data.length === build.size && digest(data) === build.sha256, { size: data.length, sha256: digest(data) });
const feed = fs.readFileSync(RC + '/dist/latest.yml', 'utf8'), encoded = crypto.createHash('sha512').update(data).digest('base64');
const versions = [...feed.matchAll(/^version:\s*["']?([0-9]+\.[0-9]+\.[0-9]+)["']?\s*$/gm)].map(m => m[1]), hashes = [...feed.matchAll(/^\s*sha512:\s*(\S+)\s*$/gm)].map(m => m[1]);
need('line 56: latest.yml: one version 0.6.9, both sha512 equal the installer\'s, url, path and size as the installer', versions.length === 1 && versions[0] === VERSION && hashes.length === 2 && hashes.every(x => x === encoded) && feed.includes('url: Comic-Metadata-Setup-0.6.9.exe') && feed.includes('path: Comic-Metadata-Setup-0.6.9.exe') && feed.includes('size: ' + build.size), { latestYmlSha256: digest(Buffer.from(feed)) });
need('record: the capsule manifest pin (extra field) names the capsule manifest and its SHA-256 on disk', owned.capsuleManifest && digest(fs.readFileSync(owned.capsuleManifest.path)) === owned.capsuleManifest.sha256, { capsuleManifest: owned.capsuleManifest && owned.capsuleManifest.sha256, verifiedBy: owned.capsuleManifest && owned.capsuleManifest.verifiedBy });
need('record: the source manifest pin in the record equals the manifest file on disk (SHA-256)', owned.sourceManifest && owned.sourceManifest.sha256 === digest(manifestRaw), { sha256: digest(manifestRaw) });
need('record: the build node download pins (nodeZipSha256 present, node.exe hash recorded)', /^[a-f0-9]{64}$/.test(owned.nodeZipSha256 || '') && /^[a-f0-9]{64}$/.test(owned.nodeSha256 || ''), { nodeSha256: owned.nodeSha256, nodeZipSha256: owned.nodeZipSha256 });
const out = { schema: 1, ok: checks.every(c => c.ok), checks };
if (process.argv[2]) fs.writeFileSync(process.argv[2], JSON.stringify(out, null, 2) + '\n');
for (const c of checks) console.log((c.ok ? 'ok    ' : 'FAIL  ') + c.name);
console.log(JSON.stringify({ ok: out.ok, checks: checks.length }));
process.exit(out.ok ? 0 : 1);
