#!/usr/bin/env bash
# The 0.6.9 Tray-smoke pass in one go, each scenario under the owned-process supervisor (run-scenario.sh), one after another.
# Usage: run-all.sh   (writes work/runs/<tag>.* and work/runs/all.console.txt)
set -u
H="I:/AI Projects/Temp/futaba-069/evidence/harness"
OUT="I:/AI Projects/Temp/futaba-069/work/runs"
for pair in "promotion-smoke fPromo 300000" "core fCore 500000" "setup-quit fSetupQuit 200000" "startup-quit fStartupQuit 200000" "failed-screen fFailed 400000" \
            "merge-held-comic fMhc 900000" "merge-held-backup fMhb 900000" "merge-flush-error fMfe 600000" \
            "w1-approve fW1a 400000" "app-flush-hold fAfh 300000" "w1-worker fW1w 400000" "w1-merge fW1m 400000" "w1-merge-control fW1c 400000" \
            "r3-convert fR3 400000" "q1-claims fQ1 900000" "r7-csv fR7 900000" "r1-readonly fR1 200000"; do
  set -- $pair
  echo "===== $1 ($2) $(date -u +%H:%M:%S)" >> "$OUT/all.console.txt"
  bash "$H/run-scenario.sh" "$1" "$2" "$3" > "$OUT/$2.console.txt" 2>&1
  head -3 "$OUT/$2.console.txt" | cut -c1-300 >> "$OUT/all.console.txt"
  tail -1 "$OUT/$2.console.txt" | cut -c1-300 >> "$OUT/all.console.txt"
done
echo "===== ALL DONE $(date -u +%H:%M:%S)" >> "$OUT/all.console.txt"
