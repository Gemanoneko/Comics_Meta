// Replays the checks of create-local-promotion.mjs (lines 57 to 63, and the evidence-naming part of line 64) over the
// evidence files, with negative controls. Usage: node validate-promotion.mjs <smoke.json> <smokeOwned.json> <binding.json> <asar.txt> [report.md]
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const digest = b => crypto.createHash('sha256').update(b).digest('hex');
const SOURCE = 'I:/AI Projects/Worktrees/Comics Meta Organizer/rc-069';
const MANIFEST = 'I:/AI Projects/Temp/cmo-rc069/source-manifest-67c7b53.json';
const version = '0.6.9', sourceHead = '67c7b53008609f7f88879abb0ab339fa4577958e';
const [smokeFile, ownedFile, bindingFile, asarFile, reportFile] = process.argv.slice(2);
const json = f => JSON.parse(fs.readFileSync(f, 'utf8'));
function normal(r) { return r?.ok === true && r.code === 0 && r.closed === true && r.forced === false && r.timedOut === false && r.outputComplete === true && r.native?.complete === true && r.native.zero === true && ['active', 'assigned', 'listed', 'unsignaled'].every(k => r.native[k] === 0); }
const manifestRaw = fs.readFileSync(MANIFEST), manifest = JSON.parse(manifestRaw), sourceIdentity = digest(manifestRaw);
const entries = new Map(manifest.files.map(f => [f.path, f.sha256]));
const installerName = 'Comic-Metadata-Setup-' + version + '.exe';
const artifacts = [installerName, installerName + '.blockmap', 'latest.yml'].map(name => ({ name, sha256: digest(fs.readFileSync(SOURCE + '/dist/' + name)) }));
const buildOwned = json('I:/AI Projects/Temp/cmo-rc069/build-owned-v0.6.9.json');
let build; for (const line of buildOwned.out.split(/\r?\n/)) { try { const o = JSON.parse(line); if (o.leanBuild) build = o.leanBuild; } catch { } }

function check(smoke, smokeOwner, binding, asarLog, report) {
  const failures = [];
  const need = (ok, message) => { if (!ok) failures.push(message); };
  need(normal(smokeOwner) && smoke.pass === true && smoke.startup?.packaged === true && smoke.startup.version === version && smoke.startup.engine?.owned === true && smoke.startup.engine.httpStatus === 200 && smoke.startup.violations?.length === 0 && smoke.close?.code === 0 && smoke.close.signal === null && smoke.close.remaining?.length === 0 && smoke.quitRequested === 'actual tray Quit requested', 'line 57: Packaged smoke/closure missing');
  need(smoke.spec?.sourceHead === sourceHead && smoke.spec.manifest === sourceIdentity && smoke.spec.installer === artifacts[0].sha256 && smoke.spec.feed === artifacts[2].sha256, 'line 58: Packaged smoke identity mismatch');
  need(binding.method === 'static-installer-extraction' && binding.closed === true && binding.installerSha256 === artifacts[0].sha256 && binding.exeSha256 === smoke.spec?.exe && binding.asarSha256 === smoke.spec?.asar, 'line 59: Installer to tested runtime binding missing');
  let extraction = null;
  try { extraction = json(binding.owner.path); need(digest(fs.readFileSync(binding.owner.path)) === binding.owner.sha256, 'line 59: owner pin drift'); } catch { need(false, 'line 60: owner record unreadable'); }
  const archiver = json(SOURCE + '/scripts/packaging/toolchain-lock.json').archiverSha256;
  need(extraction && normal(extraction.result) && extraction.toolSha256 === archiver && digest(fs.readFileSync(extraction.command.file)) === archiver && extraction.command.args.includes(build.installer) && extraction.command.args.includes('ComicMetadata.exe') && extraction.command.args.includes('resources\\app.asar'), 'line 61: Owned static extraction proof missing');
  need(smoke.markResources?.matches === 8 && smoke.markResources.distinctNormal === 4 && smoke.markResources.distinctSmall === 4 && ['processing', 'paused', 'resumed'].every(k => smoke[k]?.exact === true), 'line 62: Tray smoke evidence incomplete');
  for (const state of ['processing', 'paused', 'verification', 'error']) for (const [field, suffix] of [['normal', ''], ['small', '-16']]) {
    const filename = 'desktop/assets/tray-' + state + suffix + '.png', sha = entries.get(filename);
    need(sha && smoke.trayBytes?.[state]?.[field] === sha && asarLog.includes(filename + ' ' + sha), 'line 63: Packaged tray source mapping mismatch (' + filename + ')');
  }
  if (report !== undefined) {
    need(report.includes('**Tray-smoke verdict: GO**') && report.includes(sourceHead), 'line 64: report verdict or source head missing');
    for (const [label, value] of [['installer', smoke.spec?.installer], ['exe', smoke.spec?.exe], ['asar', smoke.spec?.asar], ['feed', smoke.spec?.feed], ['sourceIdentity', sourceIdentity], ['smoke evidence name', path.basename(smokeFile)], ['smoke owned name', path.basename(ownedFile)]])
      need(value && report.includes(value), 'line 64: report does not name the ' + label);
  }
  return failures;
}

const load = () => ({ smoke: json(smokeFile), owned: json(ownedFile), binding: json(bindingFile), asar: fs.readFileSync(asarFile, 'utf8'), report: reportFile ? fs.readFileSync(reportFile, 'utf8') : undefined });
const base = load();
const positive = check(base.smoke, base.owned, base.binding, base.asar, base.report);
console.log('POSITIVE (files as written):', positive.length === 0 ? 'all checks pass' : positive);
const controls = [
  ['pass false', s => { s.smoke.pass = false; }],
  ['violation recorded at startup', s => { s.smoke.startup.violations = [{ guard: 'x' }]; }],
  ['close code 1', s => { s.smoke.close.code = 1; }],
  ['quitRequested missing', s => { delete s.smoke.quitRequested; }],
  ['wrong installer hash in spec', s => { s.smoke.spec.installer = '0'.repeat(64); }],
  ['wrong manifest hash in spec', s => { s.smoke.spec.manifest = '0'.repeat(64); }],
  ['markResources.matches 7', s => { s.smoke.markResources.matches = 7; }],
  ['paused.exact false', s => { s.smoke.paused.exact = false; }],
  ['one tray hash changed', s => { s.smoke.trayBytes.error.small = '0'.repeat(64); }],
  ['binding method text changed', s => { s.binding.method = 'static-installer-extraction (pinned 7za)'; }],
  ['owned record not closed', s => { s.owned.closed = false; }],
  ['top-level field missing (resumed)', s => { delete s.smoke.resumed; }]
];
let missed = 0;
for (const [name, mutate] of controls) {
  const s = load(); mutate(s);
  const failures = check(s.smoke, s.owned, s.binding, s.asar, s.report);
  console.log('CONTROL', name, '->', failures.length ? 'rejected (' + failures[0].slice(0, 60) + ')' : 'NOT REJECTED');
  if (!failures.length) missed++;
}
console.log(JSON.stringify({ positivePass: positive.length === 0, controls: controls.length, controlsNotRejected: missed }));
process.exit(positive.length === 0 && missed === 0 ? 0 : 1);
