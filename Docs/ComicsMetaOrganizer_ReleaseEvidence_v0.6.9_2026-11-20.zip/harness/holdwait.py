"""Futaba 0.6.9 harness helper (app flush wait): a program that opens a file the app is still BUILDING, the moment the app has closed it. It retries
CreateFileW(GENERIC_READ, FILE_SHARE_READ only) every millisecond until it succeeds (it cannot while the app's writer has the file open for writing, and
it fails while the file does not exist yet), prints "held <tries> <seconds>" and holds it until stdin closes. The app's next step on that file is its
flush (GENERIC_WRITE), which then meets a sharing violation (Windows error 32) and waits.
Usage (packaged python, -B -I): holdwait.py <file> [give-up seconds, default 90]"""
import ctypes as C
import sys
import time
from ctypes import wintypes as W

K = C.WinDLL('kernel32', use_last_error=True)
K.CreateFileW.restype = W.HANDLE
K.CreateFileW.argtypes = [W.LPCWSTR, W.DWORD, W.DWORD, C.c_void_p, W.DWORD, W.DWORD, W.HANDLE]
K.CloseHandle.argtypes = [W.HANDLE]
INVALID = W.HANDLE(-1).value
path = sys.argv[1]
limit = float(sys.argv[2]) if len(sys.argv) > 2 else 90.0
print('ready', flush=True)
start = time.monotonic()
tries = 0
errors = {}
handle = None
while time.monotonic() - start < limit:
    tries += 1
    handle = K.CreateFileW(path, 0x80000000, 0x1, None, 3, 0x80, None)  # GENERIC_READ, FILE_SHARE_READ, OPEN_EXISTING
    if handle != INVALID and handle is not None:
        break
    code = C.get_last_error()
    errors[code] = errors.get(code, 0) + 1
    handle = None
    time.sleep(0.001)
if handle is None:
    print('gave up %d %s' % (tries, errors), flush=True)
    raise SystemExit(2)
print('held %d %.3f %s' % (tries, time.monotonic() - start, errors), flush=True)
sys.stdin.read()
K.CloseHandle(handle)
print('released', flush=True)
