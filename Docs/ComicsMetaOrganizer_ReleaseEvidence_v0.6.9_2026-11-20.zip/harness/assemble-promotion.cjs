// Assemble the promotion-shaped evidence from the promotion run (work/runs/fPromo.*) and the owned static extractions.
// Every value is read from a file written by this run; the script stops if the observations disagree.
const fs = require('fs');
const crypto = require('crypto');
const B = 'I:/AI Projects/Temp/futaba-069';
const RC = 'I:/AI Projects/Worktrees/Comics Meta Organizer/rc-069';
const ev = B + '/evidence/';
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const shaFile = f => sha(fs.readFileSync(f));
const j = f => JSON.parse(fs.readFileSync(f, 'utf8'));
const stop = m => { console.error('STOP: ' + m); process.exit(1); };

const smoke = j(B + '/work/runs/fPromo.promotion.json');
const run = j(B + '/work/runs/fPromo.result.json');
const twoOwned = j(B + '/work/extraction-two-owned.json');
const fullOwned = j(B + '/work/extraction-full-owned.json');
const build = (() => { const o = j('I:/AI Projects/Temp/cmo-rc069/build-owned-v0.6.9.json'); for (const line of o.out.split('\n')) { try { const x = JSON.parse(line); if (x.leanBuild) return x.leanBuild; } catch { } } stop('no build receipt'); })();
const archiver = j(RC + '/scripts/packaging/toolchain-lock.json').archiverSha256;
const installerFile = RC + '/dist/Comic-Metadata-Setup-0.6.9.exe';
const installerSha = shaFile(installerFile);
const twoExe = shaFile(B + '/work/extract-two/ComicMetadata.exe');
const twoAsar = shaFile(B + '/work/extract-two/resources/app.asar');
const fullExe = shaFile(B + '/extract/ComicMetadata.exe');
const fullAsar = shaFile(B + '/extract/resources/app.asar');
if (!smoke.pass) stop('promotion smoke did not pass');
if (installerSha !== smoke.spec.installer || installerSha !== build.sha256) stop('installer hash disagrees');
if (twoExe !== smoke.spec.exe || twoAsar !== smoke.spec.asar) stop('two-file extraction differs from the exe/asar the smoke ran');
if (fullExe !== smoke.spec.exe || fullAsar !== smoke.spec.asar) stop('full extraction differs from the exe/asar the smoke ran');
if (run.testedRuntime.exe !== smoke.spec.exe || run.testedRuntime.asar !== smoke.spec.asar) stop('running app hashes differ');
if (shaFile(RC + '/node_modules/7zip-bin/win/x64/7za.exe') !== archiver) stop('7za is not the pinned archiver');

const tree = (() => {
  const rows = [];
  (function walk(d, rel) { for (const it of fs.readdirSync(d, { withFileTypes: true })) { const n = rel ? rel + '/' + it.name : it.name; if (it.isDirectory()) walk(d + '/' + it.name, n); else rows.push(n + '\t' + shaFile(d + '/' + it.name) + '\n'); } })(B + '/extract', '');
  rows.sort();
  return { files: rows.length, digest: sha(rows.join('')) };
})();
fs.copyFileSync(B + '/work/runs/fPromo.promotion.json', ev + 'tray-evidence-v0.6.9-promotion.json');
fs.copyFileSync(B + '/work/runs/fPromo.owned.json', ev + 'tray-owned-v0.6.9-promotion.json');
fs.copyFileSync(B + '/work/runs/fPromo.asar.txt', ev + 'asar-evidence-v0.6.9-promotion.txt');
fs.writeFileSync(ev + 'extraction-owned-v0.6.9-promotion.json', JSON.stringify({ schema: 1, result: twoOwned, toolSha256: archiver, command: twoOwned.command }, null, 2) + '\n');
const ownerFile = ev + 'extraction-owned-v0.6.9-promotion.json';
const binding = { schema: 1, method: 'static-installer-extraction', closed: twoOwned.closed === true && twoOwned.forced === false && twoOwned.native.zero === true,
  installerSha256: installerSha, exeSha256: twoExe, asarSha256: twoAsar, testedExeSha256: run.testedRuntime.exe, testedAsarSha256: run.testedRuntime.asar,
  installer: build.installer, archiverSha256: archiver, owner: { path: ownerFile, sha256: shaFile(ownerFile) },
  fullExtraction: { treeFiles: tree.files, treeDigest: tree.digest, treeDigestMethod: 'sha256 over sorted lines <relative path>TAB<file sha256>LF of every file under the whole-payload extraction, computed by this script', ownedClosed: fullOwned.closed === true && fullOwned.forced === false && fullOwned.native.zero === true },
  note: 'ComicMetadata.exe and resources/app.asar extracted statically from the installer by the pinned 7za under a private Job; hashes equal the files the running app reported for itself (process.execPath and app.asar) in the promotion smoke, and the whole-payload extraction.' };
fs.writeFileSync(ev + 'package-binding-v0.6.9-promotion.json', JSON.stringify(binding, null, 2) + '\n');
console.log(JSON.stringify({ wrote: ['tray-evidence-v0.6.9-promotion.json', 'tray-owned-v0.6.9-promotion.json', 'asar-evidence-v0.6.9-promotion.txt', 'extraction-owned-v0.6.9-promotion.json', 'package-binding-v0.6.9-promotion.json'], closed: binding.closed, installer: build.installer }));
