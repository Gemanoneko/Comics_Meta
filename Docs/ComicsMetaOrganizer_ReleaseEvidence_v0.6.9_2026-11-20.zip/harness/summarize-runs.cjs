// Futaba 0.6.9: one line per scenario run (the final results in work/runs): pass, recorded checks (ok / total), and the supervisor's closure of that run.
// Usage: node summarize-runs.cjs <out.txt>
'use strict';
const fs = require('fs');
const R = 'I:/AI Projects/Temp/futaba-069/work/runs/';
const order = [['fPromo', 'promotion-smoke'], ['fCore', 'core'], ['fSetupQuit', 'setup-quit'], ['fStartupQuit', 'startup-quit'], ['fFailed', 'failed-screen'],
  ['fMhc', 'merge-held-comic'], ['fMhb', 'merge-held-backup'], ['fMfe', 'merge-flush-error'], ['fW1a', 'w1-approve'], ['fAfh', 'app-flush-hold'], ['fW1w', 'w1-worker'],
  ['fW1m', 'w1-merge'], ['fW1c', 'w1-merge-control'], ['fR3', 'r3-convert'], ['fQ1', 'q1-claims'], ['fR7', 'r7-csv'], ['fR1', 'r1-readonly']];
const lines = ['# 0.6.9 Tray-smoke runs (final results of each scenario, each under its own private kill-on-close Job)', '# tag scenario pass checks(ok/total) closed forced timedOut nativeZero code elapsedSeconds started finished'];
let ok = 0, total = 0, runs = 0;
for (const [tag, name] of order) {
  const rf = R + tag + '.result.json', of = R + tag + '.owned.json';
  if (!fs.existsSync(rf) || !fs.existsSync(of)) { lines.push(tag + ' ' + name + ' MISSING'); continue; }
  const r = JSON.parse(fs.readFileSync(rf, 'utf8')), o = JSON.parse(fs.readFileSync(of, 'utf8'));
  const good = r.steps.filter(s => s.ok !== false).length;
  ok += good; total += r.steps.length; runs++;
  lines.push([tag, name, r.pass ? 'pass' : 'FAIL', good + '/' + r.steps.length, 'closed=' + o.closed, 'forced=' + o.forced, 'timedOut=' + o.timedOut, 'nativeZero=' + (o.native && o.native.zero), 'code=' + o.code, Math.round(o.elapsedMs / 1000) + 's', r.started, r.finished].join(' '));
}
lines.push('# total: ' + runs + ' runs, ' + ok + ' of ' + total + ' recorded checks ok');
fs.writeFileSync(process.argv[2], lines.join('\n') + '\n');
console.log(lines.join('\n'));
