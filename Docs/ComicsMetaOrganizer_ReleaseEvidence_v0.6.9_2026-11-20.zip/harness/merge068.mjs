// Futaba 0.6.8 QA: the nested-ComicInfo merge tool (tools/nested_comicinfo_merge.py at the source commit, run by the packaged python against the
// PACKAGED engine) on scratch fixture libraries and private state roots only. The live state folder is always given as --live <scratch>.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { launch, makeRoot, setupLibrary, waitFor, sleep, win, PY, BASE, pidAlive, runInfoForEvidence, EXTRACT } from './lib.mjs';

const RC = 'I:/AI Projects/Worktrees/Comics Meta Organizer/rc-069';
const ENGINE = EXTRACT + '/resources/engine';
const TOOL = RC + '/tools/nested_comicinfo_merge.py';
const H = BASE + '/evidence/harness';
const sha256Stream = f => new Promise((resolve, reject) => { const h = crypto.createHash('sha256'); fs.createReadStream(f).on('data', d => h.update(d)).on('end', () => resolve(h.digest('hex'))).on('error', reject); });
const NAMES = ['Merge A 001 (2020).cbz', 'Merge B 002 (2020).cbz', 'Merge C 003 (2020).cbz', 'Merge D 004 (2020).cbz'];

export function registerMerge(E) {
  const { S, out, check, must } = E;
  const h = E.h;
  const toolEnv = info => ({ ...process.env, COMICS_META_STATE_ROOT: info.state, COMICS_META_LOCK_DIR: info.locks, LOCALAPPDATA: win(BASE + '/tmp/localappdata'), APPDATA: win(BASE + '/tmp/appdata'), TEMP: info.tmp, TMP: info.tmp, PYTHONDONTWRITEBYTECODE: '1' });
  const toolSync = (args, info, timeout = 300000) => { const t = Date.now(); const r = spawnSync(PY, ['-B', '-I', TOOL, ...args], { env: toolEnv(info), windowsHide: true, encoding: 'utf8', timeout }); return { code: r.status, stdout: r.stdout || '', stderr: r.stderr || '', ms: Date.now() - t }; };
  function toolSpawn(args, info) {
    const child = spawn(PY, ['-B', '-I', TOOL, ...args], { env: toolEnv(info), windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '', stderr = '';
    child.stdout.on('data', d => { stdout += d; }); child.stderr.on('data', d => { stderr += d; });
    const exited = new Promise(resolve => child.once('exit', (code, signal) => resolve({ code, signal, t: Date.now() })));
    return { child, out: () => stdout, err: () => stderr, exited };
  }
  const jsonl = f => { try { return fs.readFileSync(f, 'utf8').split('\n').filter(Boolean).map(l => { try { return JSON.parse(l); } catch { return { torn: l.slice(0, 40) }; } }); } catch { return []; } };
  const stateJsonl = info => jsonl(path.win32.join(info.state, 'data', 'removed-nested-copies.jsonl'));
  const bak = (lib, name) => h.backupsOf(lib, name);

  // A QA root with the scratch library, catalog, plan. No app is launched.
  async function prepare(tag, bigMb) {
    const info = await makeRoot(tag);
    const lib = path.win32.join(info.root, 'library');
    const made = h.pyRun([H + '/fixture_merge.py', info.root, lib, String(bigMb)], h.pyEnv(info), 300000);
    if (made.status !== 0) throw new Error('merge fixture failed: ' + made.stderr + made.stdout);
    const fx = JSON.parse(made.stdout.trim().split('\n').slice(-1)[0]);
    const planMd = path.win32.join(info.root, 'plan', 'plan.md');
    fs.mkdirSync(path.dirname(planMd), { recursive: true });
    const dry = toolSync(['--report', planMd, '--library', lib, '--live', info.state], info);
    const planFile = planMd.replace(/\.md$/, '.json');
    const plan = JSON.parse(fs.readFileSync(planFile, 'utf8'));
    const result = { info, lib, fx, planFile, plan, planSha: crypto.createHash('sha256').update(fs.readFileSync(planFile)).digest('hex'), dryCode: dry.code };
    check(tag + ': scratch library of 4 archives (root + one nested ComicInfo each, #2 large); scanned catalog; dry run planned 4 merges', dry.code === 0 && fx.catalogRows === 4 && plan.entries.length === 4 && plan.entries.every(e => e.action === 'merge'), { dryCode: dry.code, catalogRows: fx.catalogRows, entries: plan.entries.map(e => path.basename(e.path) + ':' + e.action), bigBytes: fx.files[NAMES[1]].size, planSha256: result.planSha });
    return result;
  }
  const applyArgs = (p, outDir, extra = []) => ['--apply', p.planFile, '--out', outDir, '--engine', win(ENGINE), '--live', p.info.state, ...extra];

  async function archiveFacts(p, name) {
    const file = path.win32.join(p.lib, name);
    const xml = h.comicInfoOf(file) || '';
    const list = spawnSync(path.win32.join(EXTRACT, 'resources/runtime/7zip/7z.exe'), ['l', '-ba', file], { windowsHide: true, encoding: 'utf8', timeout: 60000 }).stdout || '';
    const names = list.split(/\r?\n/).map(l => l.trim().split(/\s+/).slice(5).join(' ')).filter(Boolean);
    const n = NAMES.indexOf(name) + 1;
    return { sha: await sha256Stream(file), rootCopies: names.filter(x => x.toLowerCase() === 'comicinfo.xml').length, nestedCopies: names.filter(x => /\/comicinfo\.xml$/i.test(x)).length,
      merged: new RegExp('<Summary>Nested summary ' + n + '\\.</Summary>').test(xml) && new RegExp('<Writer>Nested Writer ' + n + '</Writer>').test(xml) && /<Genre>Nested Genre<\/Genre>/.test(xml),
      rootKept: new RegExp('<Series>Merge QA Series</Series>').test(xml) && new RegExp('<Number>' + n + '</Number>').test(xml), year: /<Year>/.test(xml) };
  }

  // Interrupt an apply: kind 'mid-temp' (the archive's temporary file is growing) or 'post-rename' (the comic is already the new archive,
  // its history insert held behind the harness's catalog write lock, then the tool process is ended).
  async function interrupt(p, outDir, kind, tag) {
    const big = path.win32.join(p.lib, NAMES[1]), temp = big + '.metadata-tmp', orig = p.fx.files[NAMES[1]];
    const run = toolSpawn(applyArgs(p, outDir), p.info);
    let lock = null;
    try {
      if (kind === 'mid-temp') {
        await waitFor(() => { try { return fs.statSync(temp).size >= 20 * 1024 * 1024; } catch { return false; } }, 'big archive temporary file growing', 120000, 20);
      } else {
        await waitFor(() => { for (const f of h.pendingFiles(p.info)) { try { const j = JSON.parse(fs.readFileSync(f, 'utf8')); if (/Merge B/.test(j.path) && 'after' in j) return true; } catch { } } return false; }, 'pending record of #2 with its after signature', 120000, 5);
        const { DatabaseSync } = await import('node:sqlite');
        lock = new DatabaseSync(h.catalogPath(p.info)); lock.exec('PRAGMA busy_timeout=20000'); lock.exec('BEGIN IMMEDIATE');
        await waitFor(() => { try { return fs.statSync(big).size !== orig.size; } catch { return false; } }, 'big archive replaced', 60000, 5);
        await sleep(500);
      }
      const killedAt = Date.now();
      process.kill(run.child.pid);
      const ex = await Promise.race([run.exited, sleep(15000).then(() => null)]);
      if (lock) { lock.exec('ROLLBACK'); lock.close(); lock = null; }
      await sleep(1500);
      const facts = { kind, killed: ex && { code: ex.code, signal: ex.signal }, toolPidAlive: pidAlive(run.child.pid), temporaryExists: fs.existsSync(temp), temporaryBytes: fs.existsSync(temp) ? fs.statSync(temp).size : 0,
        pending: h.pendingFiles(p.info).length, backupsOfBig: bak(p.lib, NAMES[1]).length, bigIsOriginal: (await sha256Stream(big)) === orig.sha256,
        results: jsonl(path.win32.join(outDir, 'results.jsonl')).map(r => path.basename(r.path) + ':' + r.outcome), journal: jsonl(path.win32.join(outDir, 'journal.jsonl')).map(r => r.event + ' ' + path.basename(r.path)),
        stateJsonlLines: stateJsonl(p.info).length, outJsonlLines: jsonl(path.win32.join(outDir, 'removed-nested-copies.jsonl')).length, summaryExists: fs.existsSync(path.win32.join(outDir, 'summary.json')) };
      return facts;
    } finally { try { if (lock) { lock.exec('ROLLBACK'); lock.close(); } } catch { } try { process.kill(run.child.pid); } catch { } }
  }

  async function finalChecks(p, outDir, tag, expectBWritten = true) {
    const facts = {};
    for (const n of NAMES) facts[n] = await archiveFacts(p, n);
    const allMerged = NAMES.every(n => facts[n].rootCopies === 1 && facts[n].nestedCopies === 0 && facts[n].merged && facts[n].rootKept && !facts[n].year);
    const summary = (() => { try { return JSON.parse(fs.readFileSync(path.win32.join(outDir, 'summary.json'), 'utf8')); } catch { return null; } })();
    const history = await h.sql(p.info, 'SELECT h.path, l.writer, l.source, l.origin FROM history h LEFT JOIN write_ledger l ON l.history_id=h.id ORDER BY h.id');
    const left = NAMES.map(n => bak(p.lib, n).length).reduce((a, b) => a + b, 0);
    return { facts, allMerged, summary, historyRows: history.length, historyByArchive: history.map(r => path.basename(r.path) + ' ' + r.writer + ' ' + r.source + ' ' + r.origin), backupsLeft: left, backupFolderExists: fs.existsSync(path.win32.join(p.lib, '.comic-metadata-backups')),
      stateJsonl: stateJsonl(p.info).map(r => path.basename(r.archive) + ':' + r.kind), outJsonl: jsonl(path.win32.join(outDir, 'removed-nested-copies.jsonl')).map(r => path.basename(r.archive)), droppedCsvExists: fs.existsSync(path.win32.join(outDir, 'dropped-nested-values.csv')),
      tmpLeft: NAMES.filter(n => fs.existsSync(path.win32.join(p.lib, n + '.metadata-tmp'))).length, pendingLeft: h.pendingFiles(p.info).length };
  }

  // -------------------------------------------------------------------------------------------------------------------
  {
    E.scenarios['merge-resume'] = async () => {
      const bigMb = Number(process.env.QA_MERGE_MB || 240);
      for (const kind of ['mid-temp', 'post-rename']) {
        const tag = 'mrgres-' + kind;
        const p = await prepare(tag, bigMb);
        const outDir = path.win32.join(p.info.root, 'merge-out');
        const cut = await interrupt(p, outDir, kind, tag);
        out['interrupted-' + kind] = cut;
        if (kind === 'mid-temp') check(tag + ': tool killed mid-run inside archive #2\'s write: its temporary file and pending record are left, #2 is still the original, #1 is done, #3 and #4 not started', cut.killed && cut.temporaryExists && cut.pending === 1 && cut.bigIsOriginal && cut.results.length === 1 && /Merge A 001.*:written/.test(cut.results[0]) && cut.backupsOfBig === 1 && !cut.summaryExists, cut);
        else check(tag + ': tool killed after #2\'s rename, before its history: #2 is already the new archive, pending record and backup left, its nested copy already in the state jsonl, no result for it', cut.killed && !cut.temporaryExists && cut.pending === 1 && !cut.bigIsOriginal && cut.backupsOfBig === 1 && cut.stateJsonlLines === 2 && cut.results.length === 1 && !cut.summaryExists, cut);
        const r = toolSync(applyArgs(p, outDir, ['--resume']), p.info);
        out['resume-' + kind] = { code: r.code, ms: r.ms, stdout: h.lastLines(r.stdout, 12), stderr: h.lastLines(r.stderr, 6) };
        check(tag + ': --resume exits 0 and reports every archive written', r.code === 0 && /Done: \{'written': 4\}/.test(r.stdout), { code: r.code, tail: h.lastLines(r.stdout, 8) });
        const fin = await finalChecks(p, outDir, tag);
        out['final-' + kind] = fin;
        check(tag + ': after --resume every archive holds ONE root ComicInfo, no nested copy, the merged values, the root\'s own values, no nested Year; no backup, temporary file or pending record left', fin.allMerged && fin.backupsLeft === 0 && !fin.backupFolderExists && fin.tmpLeft === 0 && fin.pendingLeft === 0, { facts: Object.fromEntries(Object.entries(fin.facts).map(([k, v]) => [k, { root: v.rootCopies, nested: v.nestedCopies, merged: v.merged, rootKept: v.rootKept, year: v.year }])), backupsLeft: fin.backupsLeft, tmpLeft: fin.tmpLeft, pendingLeft: fin.pendingLeft });
        check(tag + ': history has exactly 4 rows (one per archive, writer automatic, source nested-comicinfo-merge); the out summary says written 4', fin.historyRows === 4 && fin.historyByArchive.every(x => / automatic nested-comicinfo-merge /.test(x)) && fin.summary && fin.summary.written === 4, { history: fin.historyByArchive, summary: fin.summary });
        check(tag + ': the removed nested copies are saved once per archive in <out> (4) and in the state data/removed-nested-copies.jsonl (4, kind merge)', fin.outJsonl.length === 4 && fin.stateJsonl.length === 4 && fin.stateJsonl.every(x => /:merge$/.test(x)), { out: fin.outJsonl, state: fin.stateJsonl });
        const resB = jsonl(path.win32.join(outDir, 'results.jsonl')).find(x => /Merge B/.test(x.path));
        out['resultB-' + kind] = resB;
        check(tag + ': the interrupted archive #2 ended "written"' + (kind === 'post-rename' ? ' and marked resumed (history recorded by the app\'s recovery first)' : ' (undone, then merged as planned)'), resB && resB.outcome === 'written' && resB.backup_removed === true && (kind === 'post-rename' ? resB.resumed === true : true), resB);
      }
      out.pass = S.list.every(s => s.ok !== false);
    };
  }

  // -------------------------------------------------------------------------------------------------------------------
  E.scenarios['merge-recover'] = async () => {
    const bigMb = Number(process.env.QA_MERGE_MB || 240);
    for (const kind of ['mid-temp', 'post-rename']) {
      const tag = 'mrgrec-' + kind;
      const p = await prepare(tag, bigMb);
      const outDir = path.win32.join(p.info.root, 'merge-out');
      const cut = await interrupt(p, outDir, kind, tag);
      out['interrupted-' + kind] = cut;
      check(tag + ': tool killed mid-run (' + kind + ')', cut.killed && cut.pending === 1 && cut.backupsOfBig === 1, cut);
      const r = toolSync(applyArgs(p, outDir, ['--recover']), p.info);
      out['recover-' + kind] = { code: r.code, ms: r.ms, stdout: h.lastLines(r.stdout, 8), stderr: h.lastLines(r.stderr, 6) };
      const big = path.win32.join(p.lib, NAMES[1]);
      const after = { bigIsOriginal: (await sha256Stream(big)) === p.fx.files[NAMES[1]].sha256, pending: h.pendingFiles(p.info).length, tmp: fs.existsSync(big + '.metadata-tmp'), backups: bak(p.lib, NAMES[1]).length,
        results: jsonl(path.win32.join(outDir, 'results.jsonl')).map(x => path.basename(x.path) + ':' + x.outcome),
        cUnchanged: (await sha256Stream(path.win32.join(p.lib, NAMES[2]))) === p.fx.files[NAMES[2]].sha256, dUnchanged: (await sha256Stream(path.win32.join(p.lib, NAMES[3]))) === p.fx.files[NAMES[3]].sha256, summaryExists: fs.existsSync(path.win32.join(outDir, 'summary.json')) };
      out['afterRecover-' + kind] = after;
      if (kind === 'mid-temp') check(tag + ': --recover exits 0, undoes the half-written archive #2 (temporary file and backup gone, #2 as it was), starts nothing new: #3 and #4 untouched', r.code === 0 && after.bigIsOriginal && after.pending === 0 && !after.tmp && after.backups === 0 && after.cUnchanged && after.dUnchanged && after.results.length === 1 && /recovered \(left as it was\) Merge B/.test(r.stdout), { code: r.code, stdout: h.lastLines(r.stdout, 6), after });
      else check(tag + ': --recover exits 0 and finishes the already-rewritten archive #2 (checked, saved, backup deleted, result written/resumed), starts nothing new: #3 and #4 untouched', r.code === 0 && !after.bigIsOriginal && after.pending === 0 && after.backups === 0 && after.cUnchanged && after.dUnchanged && after.results.length === 2 && /written Merge B/.test(r.stdout), { code: r.code, stdout: h.lastLines(r.stdout, 6), after });
      const r2 = toolSync(applyArgs(p, outDir, ['--resume']), p.info);
      const fin = await finalChecks(p, outDir, tag);
      out['final-' + kind] = fin;
      check(tag + ': a later --resume carries on with the archives not done yet; all 4 merged, no backup left', r2.code === 0 && fin.allMerged && fin.backupsLeft === 0 && fin.summary && fin.summary.written === 4 && fin.historyRows === 4, { code: r2.code, tail: h.lastLines(r2.stdout, 5), summary: fin.summary, history: fin.historyRows, backupsLeft: fin.backupsLeft });
    }
    out.pass = S.list.every(s => s.ok !== false);
  };

  // -------------------------------------------------------------------------------------------------------------------
  E.scenarios['merge-torn'] = async () => {
    const bigMb = Number(process.env.QA_MERGE_MB || 240);
    const tag = 'mrgtorn';
    const p = await prepare(tag, bigMb);
    const outDir = path.win32.join(p.info.root, 'merge-out');
    const cut = await interrupt(p, outDir, 'mid-temp', tag);
    out.interrupted = cut;
    check(tag + ': tool killed mid-run inside archive #2', cut.killed && cut.pending === 1 && cut.temporaryExists, cut);
    const journalFile = path.win32.join(outDir, 'journal.jsonl');
    const before = fs.readFileSync(journalFile);
    const zeros = Buffer.alloc(48, 0);
    fs.appendFileSync(journalFile, zeros);
    const afterAppend = fs.readFileSync(journalFile);
    check('48 zero bytes appended to journal.jsonl (a torn last line: no newline)', afterAppend.length === before.length + 48 && afterAppend[afterAppend.length - 1] === 0 && before[before.length - 1] === 10, { journalBytesBefore: before.length, after: afterAppend.length });
    const tornFile = journalFile + '.torn';
    check('no .torn file yet (positive control: it appears only after --resume)', !fs.existsSync(tornFile), {});
    const r = toolSync(applyArgs(p, outDir, ['--resume']), p.info);
    out.resume = { code: r.code, stdout: h.lastLines(r.stdout, 10), stderr: h.lastLines(r.stderr, 6) };
    const torn = fs.existsSync(tornFile) ? fs.readFileSync(tornFile) : null;
    check('--resume still works with the torn journal: exits 0, says it moved the torn line, and leaves journal.jsonl.torn holding exactly those 48 zero bytes', r.code === 0 && /journal\.jsonl ended with a torn line \(48 bytes\): moved to journal\.jsonl\.torn/.test(r.stderr) && torn && torn.length === 48 && torn.every(b => b === 0), { code: r.code, stderr: h.lastLines(r.stderr, 4), tornBytes: torn && torn.length, tornAllZero: torn && torn.every(b => b === 0) });
    const journalNow = fs.readFileSync(journalFile);
    check('journal.jsonl itself no longer ends in zero bytes (every line parses, ends with a newline)', journalNow[journalNow.length - 1] === 10 && !journalNow.includes(0) && h.lastLines(journalNow.toString('utf8'), 100).every(l => { try { JSON.parse(l); return true; } catch { return false; } }), { bytes: journalNow.length });
    const fin = await finalChecks(p, outDir, tag);
    out.final = fin;
    check('after the torn-journal --resume: all 4 archives merged (summary written 4), no backup, temporary file or pending record left', fin.allMerged && fin.summary && fin.summary.written === 4 && fin.backupsLeft === 0 && fin.tmpLeft === 0 && fin.pendingLeft === 0, { summary: fin.summary, backupsLeft: fin.backupsLeft });
    // negative control: a damaged line BEFORE the end refuses (nothing is guessed)
    const p2 = await prepare(tag + '2', 24);
    const out2 = path.win32.join(p2.info.root, 'merge-out');
    const cut2 = await interrupt(p2, out2, 'mid-temp', tag + '2');
    fs.writeFileSync(path.win32.join(out2, 'journal.jsonl'), '{"event": broken\n' + fs.readFileSync(path.win32.join(out2, 'journal.jsonl'), 'utf8'));
    const r2 = toolSync(applyArgs(p2, out2, ['--resume']), p2.info);
    check('negative control: a damaged line before the end makes --resume refuse ("is damaged"), writing nothing', r2.code !== 0 && /line 1 is damaged/.test(r2.stdout + r2.stderr) && h.pendingFiles(p2.info).length === 1, { code: r2.code, message: h.lastLines(r2.stdout + r2.stderr, 3) });
    out.pass = S.list.every(s => s.ok !== false);
  };

  // -------------------------------------------------------------------------------------------------------------------
  // --help, an older engine, and the real "stopped" merge (R2)
  E.scenarios['merge-misc'] = async () => {
    const help = toolSync(['--help'], { state: win(BASE + '/tmp/none'), locks: win(BASE + '/tmp/none'), tmp: win(BASE + '/tmp') }, 60000);
    out.help = { code: help.code, bytes: help.stdout.length, head: help.stdout.split('\n').slice(0, 3) };
    const need = ['Recovery after an interrupted apply', '1. Delete nothing', '2. Run the same command again with --resume added', '3. What happens to the archive that was being written', 'Still the original', 'Already rewritten', "Anything that does not check out", '4. If the run ended on a \'stopped\' result', '5. Starting the app also finishes or undoes', '.torn', 'Save not verified', 'removed-nested-copies.jsonl', '--recover', 'A merge that finished is not reversed'];
    const missing = need.filter(x => !help.stdout.includes(x));
    check('--help carries the recovery steps (steps 1 to 5, the three cases, the torn-line note, Kept backups and the state jsonl)', help.code === 0 && missing.length === 0, { code: help.code, missing, lines: help.stdout.split('\n').length });
    // older engine refused
    const tag = 'mrgold';
    const p = await prepare(tag, 0);
    const old = path.win32.join(BASE, 'work', 'engine-0.6.7');
    fs.rmSync(old, { recursive: true, force: true }); fs.mkdirSync(old, { recursive: true });
    const names = spawnSync('git', ['-C', RC, 'ls-tree', '--name-only', '9d1ad1af7c3e3f6c0db86b052d8372c8f1c5ad1b'], { encoding: 'utf8' }).stdout.split('\n').filter(n => /^[^/]+\.py$/.test(n) || n === 'VERSION');
    const zip = path.win32.join(BASE, 'work', 'engine-0.6.7.zip');
    fs.rmSync(zip, { force: true });
    const arch = spawnSync('git', ['-C', RC, 'archive', '--format=zip', '-o', zip, '9d1ad1af7c3e3f6c0db86b052d8372c8f1c5ad1b', '--', ...names], { encoding: 'utf8' });
    const sevenz = path.win32.join(EXTRACT, 'resources/runtime/7zip/7z.exe');
    const ex = spawnSync(sevenz, ['x', '-y', '-o' + old, zip], { windowsHide: true, encoding: 'utf8', timeout: 60000 });
    const oldVersion = fs.readFileSync(path.win32.join(old, 'VERSION'), 'utf8').trim();
    out.oldEngine = { files: names.length, version: oldVersion, gitArchive: arch.status, extract: ex.status };
    const outOld = path.win32.join(p.info.root, 'merge-out-old');
    const hashesBefore = {}; for (const n of NAMES) hashesBefore[n] = await sha256Stream(path.win32.join(p.lib, n));
    const refused = toolSync(['--apply', p.planFile, '--out', outOld, '--engine', old, '--live', p.info.state], p.info);
    const hashesAfter = {}; for (const n of NAMES) hashesAfter[n] = await sha256Stream(path.win32.join(p.lib, n));
    out.refusal = { code: refused.code, text: (refused.stdout + refused.stderr).trim().split('\n').slice(-2) };
    check('an older engine (the 0.6.7 source files, VERSION ' + oldVersion + ') is refused: non-zero exit, "This app version cannot recover an interrupted write. Install 0.6.8 or later, then apply.", no --out folder, nothing touched', oldVersion === '0.6.7' && refused.code !== 0 && /cannot recover an interrupted write\. Install 0.6.8 or later/.test(refused.stdout + refused.stderr) && !fs.existsSync(outOld) && JSON.stringify(hashesBefore) === JSON.stringify(hashesAfter) && h.pendingFiles(p.info).length === 0 && NAMES.every(n => bak(p.lib, n).length === 0), { oldVersion, code: refused.code, message: out.refusal.text, outFolderCreated: fs.existsSync(outOld), archivesUnchanged: JSON.stringify(hashesBefore) === JSON.stringify(hashesAfter) });
    // positive control for the refusal: the same plan with the packaged engine goes through
    const outNew = path.win32.join(p.info.root, 'merge-out-new');
    const ok = toolSync(applyArgs(p, outNew), p.info);
    check('positive control: the same plan with the packaged 0.6.8 engine applies (written 4)', ok.code === 0 && /Done: \{'written': 4\}/.test(ok.stdout), { code: ok.code, tail: h.lastLines(ok.stdout, 3) });
    fs.rmSync(old, { recursive: true, force: true }); fs.rmSync(zip, { force: true });
    out.pass = S.list.every(s => s.ok !== false);
  };

  // A merge that STOPS on a failed check, for real: a reader holding the written archive with FILE_SHARE_READ only (nobody may write) makes the
  // tool's flush of the written archive fail, so its "stopped" path runs. Then the app starts on that state and lists the kept backup.
  E.scenarios['merge-stopped'] = async () => {
    const bigMb = Number(process.env.QA_MERGE_MB || 240);
    const tag = 'mrgstop';
    const p = await prepare(tag, bigMb);
    const outDir = path.win32.join(p.info.root, 'merge-out');
    const big = path.win32.join(p.lib, NAMES[1]);
    const holder = spawn(PY, ['-B', '-I', H + '/holdshare.py', big], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    let hout = ''; holder.stdout.on('data', d => { hout += d; });
    await waitFor(() => /ready/.test(hout), 'share holder ready', 20000, 50);
    const run = toolSpawn(applyArgs(p, outDir), p.info);
    // the tool journals "written" for #2 right after the write returns; its verification then re-reads the whole archive
    await waitFor(() => jsonl(path.win32.join(outDir, 'journal.jsonl')).some(e => e.event === 'written' && /Merge B/.test(e.path)), 'journal: written for #2', 180000, 3);
    holder.stdin.write('go\n');
    const tHold = Date.now();
    const ex = await Promise.race([run.exited, sleep(120000).then(() => null)]);
    const gotHold = /held/.test(hout);
    try { holder.stdin.end(); } catch { }
    out.apply = { exit: ex && { code: ex.code, signal: ex.signal }, holder: hout.trim(), stdoutTail: h.lastLines(run.out(), 8), stderrTail: h.lastLines(run.err(), 4) };
    const results = jsonl(path.win32.join(outDir, 'results.jsonl'));
    out.results = results.map(r => ({ archive: path.basename(r.path), outcome: r.outcome, reason: r.reason, backup_removed: r.backup_removed, kept_as: r.kept_as }));
    const resB = results.find(r => /Merge B/.test(r.path));
    check('the reader got in while the tool re-read the written archive, and the tool\'s flush failed: archive #2 result is "stopped" with its backup kept (a real failed check, nothing patched)', gotHold && resB && resB.outcome === 'stopped' && /could not be flushed to disk/.test(resB.reason || '') && resB.backup_removed === false, { holder: hout.trim(), resB });
    check('the run stopped at #2: #1 written, #3 and #4 not started (summary: written 1, stopped 1)', results.length === 2 && results[0].outcome === 'written' && ex && ex.code === 0, { results: out.results, exitCode: ex && ex.code });
    const sj = stateJsonl(p.info);
    const rec = sj.find(r => /Merge B/.test(r.archive));
    const nestedWanted = '<?xml version="1.0"?><ComicInfo><Series>Merge QA Series</Series><Number>2</Number><Summary>Nested summary 2.</Summary><Writer>Nested Writer 2</Writer><Genre>Nested Genre</Genre><Year>2019</Year></ComicInfo>';
    check('R2: the stopped archive\'s whole nested copy (byte for byte) and what the root did not take are in the scratch data/removed-nested-copies.jsonl', Boolean(rec) && Buffer.from(rec.xml_base64, 'base64').toString('utf8') === nestedWanted && rec.kind === 'merge' && Array.isArray(rec.left_out) && rec.left_out.length === 1 && rec.left_out[0][0] === 'Year' && rec.left_out[0][2] === 'nested date never copied', { line: rec && { kind: rec.kind, entry: rec.entry, left_out: rec.left_out, backup: path.basename(rec.backup || '') }, lines: sj.length });
    check('R2: the backup of #2 is on disk (one copy, equal to the original archive) and #2 is the new archive', bak(p.lib, NAMES[1]).length === 1 && (await sha256Stream(bak(p.lib, NAMES[1])[0])) === p.fx.files[NAMES[1]].sha256 && (await sha256Stream(big)) !== p.fx.files[NAMES[1]].sha256, { backups: bak(p.lib, NAMES[1]).map(f => path.basename(f)) });
    // the app on that state: the backup is listed as "Save not verified"
    E.run = await launch(tag + '-app', { existing: p.info });
    out.run = runInfoForEvidence(E.run);
    out.expectedTray = await E.run.qa('expected()');
    await E.run.qa('sampleStart(40)');
    const first = await waitFor(async () => { const st = await E.run.qa('state()', true); return ['ready', 'setup'].includes(st.service) && st.service; }, 'app start outcome', 90000, 300);
    out.firstScreen = first;
    if (first === 'setup') await setupLibrary(E.run, p.lib);
    await E.readyEngine('merge-stopped app start', 1);
    const kept = await h.backupsListing(E.run);
    out.keptApi = kept.body;
    check('R2: the app lists the stopped merge\'s backup in Kept backups with the reason "save_not_verified"', kept.http === 200 && kept.body.count === 1 && kept.body.items[0].name === NAMES[1] && kept.body.items[0].reason === 'save_not_verified', { count: kept.body && kept.body.count, reason: kept.body && kept.body.items && kept.body.items[0] && kept.body.items[0].reason });
    const panel = await h.keptPanelText(E.run);
    out.keptPanel = panel;
    check('R2: the Kept backups page (the real panel code) says "Save not verified"', panel && Array.isArray(panel.reasons) && panel.reasons.includes('Save not verified'), panel);
    check('the app\'s start found no interrupted write to recover (the stopped merge had completed its write and history)', h.recoveryLines(p.info).length === 0, { lines: h.recoveryLines(p.info) });
    out.quit = await E.quitViaTray('after the stopped merge', { staleClaimsOk: true });
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  };

  // A merge killed mid-run, then the APP starts first (not the tool): what its own recovery does, what Kept backups says, and that --resume still finishes the run.
  E.scenarios['merge-killed-app'] = async () => {
    const bigMb = Number(process.env.QA_MERGE_MB || 240);
    for (const kind of ['post-rename', 'mid-temp']) {
      const tag = 'mrgkapp-' + kind;
      const p = await prepare(tag, bigMb);
      const outDir = path.win32.join(p.info.root, 'merge-out');
      const cut = await interrupt(p, outDir, kind, tag);
      out['interrupted-' + kind] = cut;
      const rec = stateJsonl(p.info).find(r => /Merge B/.test(r.archive));
      out['stateLineForB-' + kind] = Boolean(rec);
      check(tag + ': tool killed mid-run (' + kind + '); pending record and backup left; its removed nested copy ' + (kind === 'post-rename' ? 'is already in the state data/removed-nested-copies.jsonl' : 'is not saved yet (the write had not reached its rename)'), cut.killed && cut.pending === 1 && cut.backupsOfBig === 1 && Boolean(rec) === (kind === 'post-rename'), { stateJsonlLines: cut.stateJsonlLines, lineForB: Boolean(rec), kind: rec && rec.kind });
      E.run = await launch(tag + '-app', { existing: p.info });
      out.run = runInfoForEvidence(E.run);
      out.expectedTray = await E.run.qa('expected()');
      await E.run.qa('sampleStart(40)');
      const first = await waitFor(async () => { const st = await E.run.qa('state()', true); return ['ready', 'setup'].includes(st.service) && st.service; }, 'app start outcome', 90000, 300);
      if (first === 'setup') await setupLibrary(E.run, p.lib);
      await E.readyEngine(tag + ' app start', 1);
      const lines = h.recoveryLines(p.info);
      out['recovery-' + kind] = lines;
      const want = kind === 'post-rename' ? /Merge B 002 \(2020\)\.cbz: recorded; its backup is kept\./ : /Merge B 002 \(2020\)\.cbz: undone; its backup was deleted\./;
      check(tag + ': engine.log at the app start: the interrupted merge write is ' + (kind === 'post-rename' ? 'recorded, its backup kept' : 'undone, its backup deleted'), lines.length === 1 && want.test(lines[0]), { lines });
      const kept = await h.backupsListing(E.run);
      out['kept-' + kind] = kept.body;
      if (kind === 'post-rename') {
        const panel = await h.keptPanelText(E.run);
        out['panel-' + kind] = panel;
        check(tag + ': Kept backups after the app own recovery lists the backup as delete_refused ("Saved; backup could not be deleted"), not "Save not verified"; the nested copy is in the state jsonl', kept.body.count === 1 && kept.body.items[0].reason === 'delete_refused' && panel.reasons.includes('Saved; backup could not be deleted') && stateJsonl(p.info).some(r => /Merge B/.test(r.archive)), { count: kept.body.count, reason: kept.body.items[0] && kept.body.items[0].reason, panelReasons: panel.reasons });
      } else check(tag + ': Kept backups is empty (the undone attempt backup was deleted)', kept.body.count === 0, { count: kept.body.count });
      out.quit = await E.quitViaTray(tag + ' app quit', { staleClaimsOk: true });
      const r = toolSync(applyArgs(p, outDir, ['--resume']), p.info);
      const fin = await finalChecks(p, outDir, tag);
      out['final-' + kind] = fin;
      check(tag + ': --resume after the app already recovered it finishes the run: all 4 written, B resumed (post-rename) , no backup left, one history row per archive', r.code === 0 && fin.allMerged && fin.summary && fin.summary.written === 4 && fin.backupsLeft === 0 && fin.historyRows === 4 && fin.stateJsonl.length === 4, { code: r.code, tail: h.lastLines(r.stdout, 4), summary: fin.summary, history: fin.historyByArchive, stateJsonl: fin.stateJsonl, backupsLeft: fin.backupsLeft });
    }
    out.pass = S.list.every(s => s.ok !== false);
  };

}
