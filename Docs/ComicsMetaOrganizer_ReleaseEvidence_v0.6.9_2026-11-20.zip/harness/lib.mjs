// Futaba 0.6.7 QA harness library: private QA root + policy, feed/model stubs, packaged-app launch with a private
// inspector, and helpers. Everything lives under BASE; nothing touches %LOCALAPPDATA%\ComicsMeta.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import http from 'node:http';
import net from 'node:net';
import { spawn } from 'node:child_process';

export const BASE = 'I:/AI Projects/Temp/futaba-069';
export const EXTRACT = BASE + '/extract';
export const EXE = EXTRACT + '/ComicMetadata.exe';
export const PY = EXTRACT + '/resources/runtime/python/python.exe';
export const SEVENZ = EXTRACT + '/resources/runtime/7zip/7z.exe';
export const TOOLS = BASE + '/evidence/harness';
export const sleep = ms => new Promise(r => setTimeout(r, ms));
export const win = p => path.win32.resolve(p);
export const sha256 = b => crypto.createHash('sha256').update(b).digest('hex');
export const APP_VERSION = '0.6.9';
// latest.yml values of the installer under test (dist/latest.yml)
export const ARTIFACT = { version: '0.6.9', name: 'Comic-Metadata-Setup-0.6.9.exe', size: 150095887,
  sha512: 'lQmn6yetBjQVaeowrsR+r1qEW1nwwLuoYFc18kPZXVnWqiqPKC5okEYmSHzPIC1wxhX+6LJTFOH7Sj37sEUgJw==' };
export const LATEST_YML = fs.readFileSync('I:/AI Projects/Worktrees/Comics Meta Organizer/rc-069/dist/latest.yml');

export async function freePort(taken = []) {
  for (let i = 0; i < 200; i++) {
    const port = 21000 + Math.floor(Math.random() * 8000);
    if (taken.includes(port) || [8765, 11434].includes(port)) continue;
    const ok = await new Promise(resolve => { const s = net.createServer(); s.once('error', () => resolve(false)); s.listen(port, '127.0.0.1', () => s.close(() => resolve(true))); });
    if (ok) return port;
  }
  throw new Error('no free port');
}
export function portFree(port) {
  return new Promise(resolve => { const s = net.createServer(); s.once('error', () => resolve(false)); s.listen(port, '127.0.0.1', () => s.close(() => resolve(true))); });
}
export function portRefused(port) {
  return new Promise(resolve => { const s = net.connect(port, '127.0.0.1'); s.once('connect', () => { s.destroy(); resolve(false); }); s.once('error', () => resolve(true)); setTimeout(() => { s.destroy(); resolve(true); }, 2000); });
}
export function pidAlive(pid) { try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } }
export async function waitFor(fn, what, timeoutMs = 30000, every = 200) {
  const start = Date.now(); let last;
  while (Date.now() - start < timeoutMs) {
    try { last = await fn(); if (last) return last; } catch (e) { last = undefined; }
    await sleep(every);
  }
  throw new Error('Timed out waiting for ' + what);
}

export class Inspector {
  static async connect(port, timeoutMs = 25000) {
    const start = Date.now(); let url = null;
    while (Date.now() - start < timeoutMs && !url) {
      try { const list = await (await fetch('http://127.0.0.1:' + port + '/json/list', { signal: AbortSignal.timeout(2000) })).json(); url = list[0]?.webSocketDebuggerUrl; } catch { }
      if (!url) await sleep(100);
    }
    if (!url) throw new Error('Private inspector unreachable');
    const ws = new WebSocket(url);
    await new Promise((resolve, reject) => { ws.onopen = resolve; ws.onerror = () => reject(new Error('inspector socket error')); });
    return new Inspector(ws);
  }
  constructor(ws) {
    this.ws = ws; this.id = 0; this.pending = new Map(); this.waiters = new Map(); this.closed = false;
    ws.onmessage = event => {
      const message = JSON.parse(event.data);
      if (message.id && this.pending.has(message.id)) { const { resolve, reject } = this.pending.get(message.id); this.pending.delete(message.id); message.error ? reject(new Error(message.error.message)) : resolve(message.result); }
      else if (message.method && this.waiters.has(message.method)) { const list = this.waiters.get(message.method); this.waiters.delete(message.method); for (const resolve of list) resolve(message.params); }
    };
    ws.onclose = () => { this.closed = true; for (const { reject } of this.pending.values()) reject(new Error('inspector closed')); this.pending.clear(); };
  }
  call(method, params = {}, timeoutMs = 15000) {
    if (this.closed) return Promise.reject(new Error('inspector closed'));
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(id); reject(new Error('inspector call timeout: ' + method)); }, timeoutMs);
      this.pending.set(id, { resolve: v => { clearTimeout(timer); resolve(v); }, reject: e => { clearTimeout(timer); reject(e); } });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }
  next(method) { return new Promise(resolve => { const list = this.waiters.get(method) || []; list.push(resolve); this.waiters.set(method, list); }); }
  async evaluate(expression, awaitPromise = false, timeoutMs = 15000) {
    const result = await this.call('Runtime.evaluate', { expression, returnByValue: true, awaitPromise }, timeoutMs);
    if (result.exceptionDetails) throw new Error('evaluate failed: ' + (result.exceptionDetails.exception?.description || result.exceptionDetails.text));
    return result.result.value;
  }
  close() { try { this.ws.close(); } catch { } }
}

// One private QA root (under the scratch TEMP) with state, locks, policy, stubs. `prepare` may write state first.
export async function makeRoot(name, existing) {
  if (existing) return existing;
  const tmp = win(BASE + '/tmp');
  const root = path.win32.join(tmp, 'illuminati-cmo-qa-' + name + '-' + crypto.randomBytes(4).toString('hex'));
  for (const dir of ['', 'state', 'locks', 'profile', 'cache']) fs.mkdirSync(path.win32.join(root, dir), { recursive: true });
  fs.mkdirSync(win(BASE + '/tmp/localappdata'), { recursive: true });
  fs.mkdirSync(win(BASE + '/tmp/appdata'), { recursive: true });
  return { tmp, root, state: path.win32.join(root, 'state'), locks: path.win32.join(root, 'locks') };
}

export async function makePolicy(root, name, extra = {}) {
  const enginePort = await freePort(), feedPort = await freePort([enginePort]), modelPort = await freePort([enginePort, feedPort]), inspectPort = await freePort([enginePort, feedPort, modelPort]);
  const feedToken = crypto.randomBytes(32).toString('hex'), feedPath = '/feed/' + crypto.randomBytes(16).toString('hex') + '/';
  const policy = { schema: 1, root, priorVersion: '0.6.8', nextVersion: '0.6.9', ...extra, expires: Date.now() + 2 * 3600 * 1000, enginePort,
    feedURL: 'http://127.0.0.1:' + feedPort + feedPath, feedToken, modelPort, artifact: ARTIFACT, installDirectory: path.win32.join(root, 'install') };
  const raw = Buffer.from(JSON.stringify(policy));
  const file = path.win32.join(root, 'policy.json');
  fs.writeFileSync(file, raw);
  return { policy, file, sha: sha256(raw), enginePort, feedPort, modelPort, inspectPort, feedToken, feedPath };
}

export function qaEnv(rootInfo, pol) {
  const env = { ...process.env };
  delete env.ELECTRON_RUN_AS_NODE;
  Object.assign(env, { TEMP: rootInfo.tmp, TMP: rootInfo.tmp, LOCALAPPDATA: win(BASE + '/tmp/localappdata'), APPDATA: win(BASE + '/tmp/appdata'),
    COMICS_META_QA: '1', COMICS_META_QA_ROOT: rootInfo.root, COMICS_META_QA_POLICY: pol.file, COMICS_META_QA_POLICY_SHA256: pol.sha });
  return env;
}

export function startStubs(pol) {
  const counts = { feed: [], model: [] };
  const feed = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://127.0.0.1');
    const name = u.pathname.startsWith(pol.feedPath) ? u.pathname.slice(pol.feedPath.length) : '';
    counts.feed.push({ name, method: req.method, authorized: req.headers.authorization === 'Bearer ' + pol.feedToken });
    if (req.headers.authorization !== 'Bearer ' + pol.feedToken || name !== 'latest.yml') { res.writeHead(404).end(); return; }
    res.writeHead(200, { 'Content-Type': 'text/yaml' }).end(LATEST_YML);
  });
  const model = http.createServer((req, res) => {
    counts.model.push({ url: req.url, qa: req.headers['x-comicsmeta-qa'] === pol.feedToken });
    res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify(req.url === '/api/generate' ? { done: true } : req.url === '/api/chat' ? { done: true, message: { content: '' } } : { models: [] }));
  });
  return new Promise((resolve, reject) => {
    feed.once('error', reject); model.once('error', reject);
    feed.listen(pol.feedPort, '127.0.0.1', () => model.listen(pol.modelPort, '127.0.0.1', () => resolve({ counts, close: () => { feed.closeAllConnections?.(); model.closeAllConnections?.(); feed.close(); model.close(); } })));
  });
}

export const OBSERVER = fs.readFileSync(TOOLS + '/observer.cjs', 'utf8');

// Launch the packaged app (the extracted installer payload) in private QA mode under a private inspector.
export async function launch(name, { writeState, existing, policyExtra } = {}) {
  const info = await makeRoot(name, existing);
  if (writeState) await writeState(info);
  const pol = await makePolicy(info.root, name, policyExtra || {});
  const stubs = await startStubs(pol);
  const events = path.win32.join(info.root, 'events.jsonl');
  const env = qaEnv(info, pol);
  const child = spawn(EXE, ['--inspect-brk=127.0.0.1:' + pol.inspectPort], { env, cwd: win(EXTRACT), windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  let stdout = '', stderr = '';
  child.stdout.on('data', d => { stdout = (stdout + d).slice(-60000); });
  child.stderr.on('data', d => { stderr = (stderr + d).slice(-60000); });
  const exited = new Promise(resolve => child.once('exit', (code, signal) => resolve({ code, signal, t: Date.now() })));
  const run = { name, ...info, pol, stubs, events, child, exited, exitInfo: null, stdout: () => stdout, stderr: () => stderr, inspector: null, ports: { engine: pol.enginePort, feed: pol.feedPort, model: pol.modelPort, inspect: pol.inspectPort } };
  exited.then(v => { run.exitInfo = v; });
  const inspector = await Inspector.connect(pol.inspectPort);
  run.inspector = inspector;
  await inspector.call('Debugger.enable');
  const pausedEvent = inspector.next('Debugger.paused');
  await inspector.call('Runtime.runIfWaitingForDebugger');
  const paused = await pausedEvent;
  const frame = paused.callFrames?.[0]?.callFrameId;
  if (!frame) throw new Error('App did not pause before main');
  const who = await inspector.call('Debugger.evaluateOnCallFrame', { callFrameId: frame, returnByValue: true,
    expression: '({pid:process.pid,exe:process.execPath,res:process.resourcesPath,qa:process.env.COMICS_META_QA,temp:process.env.TEMP,local:process.env.LOCALAPPDATA,hasRequire:typeof require})' });
  const id = who.result.value;
  if (who.exceptionDetails || id.pid !== child.pid || path.win32.resolve(id.exe).toLowerCase() !== win(EXE).toLowerCase() || id.qa !== '1' || id.hasRequire !== 'function')
    throw new Error('Wrong inspector target: ' + JSON.stringify(id));
  const source = OBSERVER.replace('__CFG__', JSON.stringify({ events }));
  const injected = await inspector.call('Debugger.evaluateOnCallFrame', { callFrameId: frame, expression: source, returnByValue: true });
  if (injected.exceptionDetails) throw new Error('observer failed: ' + (injected.exceptionDetails.exception?.description || injected.exceptionDetails.text));
  run.identity = { ...id, ...injected.result.value };
  await inspector.call('Debugger.resume');
  run.t0 = Date.now();
  // helpers
  run.qa = (expr, awaitPromise = false, timeoutMs = 15000) => run.inspector.evaluate('globalThis.__qa.' + expr, awaitPromise, timeoutMs);
  run.engines = () => run.qa('engines.map(e=>({pid:e.pid,exit:e.exit,startedAt:e.startedAt}))');
  run.token = async () => (await run.qa('engines.map(e=>e.token)')).slice(-1)[0];
  run.shellStatus = async () => {
    const token = await run.token();
    const r = await fetch('http://127.0.0.1:' + pol.enginePort + '/api/shell/status', { headers: { 'X-ComicsMeta-Shell': token }, signal: AbortSignal.timeout(3000) });
    return { http: r.status, body: await r.json() };
  };
  run.apiState = async () => { const r = await fetch('http://127.0.0.1:' + pol.enginePort + '/api/state', { signal: AbortSignal.timeout(3000) }); return { http: r.status, body: await r.json() }; };
  run.readEvents = () => { try { return fs.readFileSync(events, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l)); } catch { return []; } };
  run.alive = () => run.exitInfo === null;
  run.detach = () => { run.inspector.close(); };
  run.claims = () => { try { return fs.readdirSync(path.win32.join(info.locks, 'claims')); } catch (e) { return e.code === 'ENOENT' ? [] : ['<unreadable>']; } };
  run.cleanup = () => { stubs.close(); };
  return run;
}

export function runInfoForEvidence(run) {
  return { ports: run.ports, identity: { pid: run.identity.pid, version: run.identity.version, packaged: run.identity.packaged, guards: run.identity.guards } };
}

// Dashboard setup through the real preload IPC, the way setup.js does it.
export async function setupLibrary(run, library) {
  await waitFor(async () => { const p = await run.qa('page()', true); return /setup\.html$/.test(p.url) && p.ready === 'complete'; }, 'setup page', 60000);
  const saved = await run.inspector.evaluate('globalThis.__qa.rend(' + JSON.stringify('window.comicDesktop.saveSetup(' + JSON.stringify(library) + ',{})') + ')', true, 60000);
  if (!saved || saved.configured !== true) throw new Error('Setup save failed: ' + JSON.stringify(saved));
  await run.inspector.evaluate("(globalThis.__qa.rend(\"window.comicDesktop.action('setupOpenDashboard')\").catch(()=>{}),'requested')", false, 15000);
  await waitFor(async () => { const s = await run.qa('state()', true); return s.service === 'ready'; }, 'service ready after setup', 90000, 300);
  return saved;
}

export function steps() {
  const list = [];
  const record = (name, data) => { const rec = { name, t: new Date().toISOString(), ...data }; list.push(rec); console.log(JSON.stringify(rec).slice(0, 400)); return rec; };
  return { list, record };
}
