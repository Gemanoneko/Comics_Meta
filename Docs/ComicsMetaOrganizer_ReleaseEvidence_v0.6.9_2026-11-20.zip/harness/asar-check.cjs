'use strict';
const crypto = require('crypto');
const cp = require('child_process');
const fs = require('fs');
const rc = process.argv[2];
const file = process.argv[3];
const outFile = process.argv[4];
const asar = require(rc + '/node_modules/@electron/asar');
const COMMIT = '67c7b53008609f7f88879abb0ab339fa4577958e';
let diff = 0, n = 0, missing = 0;
const out = [];
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const norm = (p, b) => /\.(cjs|js|html|css|py|json)$/.test(p)
  ? sha(Buffer.from(b.toString('latin1').split('\r').join(''), 'latin1')) : sha(b);
for (const f of asar.listPackage(file)) {
  const p = f.split('\\').join('/').replace(/^\//, '');
  if (!p.startsWith('desktop/')) continue;
  let buf;
  try { buf = asar.extractFile(file, p); } catch { continue; }
  n++;
  if (/\.png$/.test(p)) out.push(p + ' ' + sha(buf));
  let src;
  try { src = cp.execFileSync('git', ['-C', rc, 'show', COMMIT + ':' + p], { maxBuffer: 50e6 }); } catch { missing++; console.log('NOSRC', p); continue; }
  if (norm(p, buf) !== norm(p, src)) { diff++; console.log('DIFF', p); }
}
console.log('asar desktop files compared', n, 'diff', diff, 'nosource', missing);
fs.writeFileSync(outFile, '# Tray PNGs read from the packaged app.asar (sha256 of file bytes). Source: ' + COMMIT + '\n# app.asar sha256 ' + sha(fs.readFileSync(file)) + '\n' + out.join('\n') + '\n');
