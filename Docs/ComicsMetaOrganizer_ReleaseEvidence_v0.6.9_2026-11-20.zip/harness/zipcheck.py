"""Futaba 0.6.9 harness helper (R3, W1): read one archive and print one JSON line: is it a zip, does testzip pass, the member names and the
SHA-256 of every member. Read only. Usage (packaged python, -B -I): zipcheck.py <archive>"""
import hashlib
import json
import sys
import zipfile

path = sys.argv[1]
result = {'is_zip': zipfile.is_zipfile(path)}
if result['is_zip']:
    with zipfile.ZipFile(path) as archive:
        result['testzip'] = archive.testzip()
        result['members'] = {name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()}
print(json.dumps(result))
