// Compare the packaged engine files with the candidate source manifest, byte for byte (sha256), as the 0.6.5 pass did.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const manifestFile = process.argv[2];
const engine = process.argv[3];
const outFile = process.argv[4];
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const raw = fs.readFileSync(manifestFile);
const manifest = JSON.parse(raw);
const entries = new Map(manifest.files.map(f => [f.path, f.sha256]));
const files = [];
(function walk(dir, rel) {
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    const name = rel ? rel + '/' + item.name : item.name;
    if (item.isDirectory()) walk(path.join(dir, item.name), name); else files.push(name);
  }
})(engine, '');
let equal = 0; const differing = []; const noSource = [];
for (const name of files.sort()) {
  const source = name === 'installer_launch.py' ? 'desktop/installer_launch.py' : name;
  if (!entries.has(source)) { noSource.push(name); continue; }
  if (sha(fs.readFileSync(path.join(engine, name))) === entries.get(source)) equal++; else differing.push(name);
}
const result = { manifestSha256: sha(raw), manifestHead: manifest.head, manifestVersion: manifest.version, manifestFiles: manifest.files.length, packagedEngineFiles: files.length, equal, differing, noSource };
fs.writeFileSync(outFile, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ manifestSha256: result.manifestSha256, head: result.manifestHead, version: result.manifestVersion, packaged: files.length, equal, differing: differing.length, noSource }));
