// Copy the final scenario results into evidence/ under versioned names and print the SHA-256 table (markdown) of every evidence file.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const B = 'I:/AI Projects/Temp/futaba-069';
const R = B + '/work/runs/', E = B + '/evidence/';
const names = { fPromo: 'promotion-smoke', fCore: 'core-nested-q2', fSetupQuit: 'setup-quit', fStartupQuit: 'startup-quit', fFailed: 'failed-screen',
  fMhc: 'merge-held-comic', fMhb: 'merge-held-backup', fMfe: 'merge-flush-error', fW1a: 'w1-approve', fAfh: 'app-flush-hold', fW1w: 'w1-worker', fW1m: 'w1-merge', fW1c: 'w1-merge-control', fR3: 'r3-convert',
  fQ1: 'q1-claims', fR7: 'r7-csv', fR1: 'r1-readonly' };
for (const [tag, name] of Object.entries(names)) {
  for (const [suffix, kind] of [['.result.json', 'scenario'], ['.owned.json', 'scenario-owned']]) {
    const src = R + tag + suffix;
    if (fs.existsSync(src)) fs.copyFileSync(src, E + kind + '-' + name + '-v0.6.9.json');
  }
}
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const rows = [];
(function walk(d, rel) { for (const it of fs.readdirSync(d, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) { const p = path.join(d, it.name), r = rel ? rel + '/' + it.name : it.name; if (it.isDirectory()) walk(p, r); else rows.push([r, fs.statSync(p).size, sha(p)]); } })(E, '');
for (const [r, size, h] of rows) console.log('| `' + r + '` | ' + size + ' | `' + h + '` |');
