Futaba tray-QA harness for Comic Metadata, 0.6.9 revision: the 0.6.8 harness repointed to rc-069 / futaba-069 / cmo-rc069 / source-manifest-67c7b53 (BASE, ARTIFACT, LATEST_YML,
policy priorVersion 0.6.8 / nextVersion 0.6.9, the manifest, build record, head and installer names in lib.mjs, scenarios.mjs, validate-promotion.mjs, asar-check.cjs,
assemble-promotion.cjs, collect-evidence.cjs, run-scenario.sh, run-all.sh, extract-*.json), plus the 0.6.9 delta scenarios in delta069.mjs. It emits the same
promotion-schema evidence that scripts/packaging/install-update-qa/create-local-promotion.mjs validates (files *-v0.6.9-promotion.*; field sets compared with the 0.6.8 files).

Everything runs under the studio's owned-process supervisor (owned-run.mjs / run-scenario.sh): a private kill-on-close Job per scenario, a private QA root under a scratch
TEMP (BASE/tmp, on I:), private engine, feed, model and inspector ports. No install, no focus, no mouse; QA mode refuses 8765 and 11434. The merge tool always runs with
--live <scratch state> and --engine <the packaged engine> (or, for a negative control, a named older engine/tool taken from git). TEMP, LOCALAPPDATA and APPDATA are
redirected into BASE/tmp. Python is the bundled one, always -B -I.

Layout: BASE/extract (whole payload), BASE/work (scratch: extraction-two, runs/, tool-068/, engine-4874894/), BASE/tmp (TEMP of every launched process and the private QA
roots), BASE/evidence (kept; harness/ is this folder).

Order for a release candidate
 1. Extract the installer twice with the pinned 7za under owned-run.mjs: extract-full-cfg.json, extract-two-cfg.json (exe + asar, the binding proof).
 2. node engine-vs-manifest.cjs <manifest> <extract>/resources/engine <out.json> ; node asar-check.cjs <rc worktree> <extract>/resources/app.asar <out.txt>
 3. Write work/tray-png-source-hashes.txt (the 8 desktop/assets/tray-*.png lines of the source manifest: "<path> <sha256>").
 4. bash run-all.sh   (every scenario below, one after another; console in work/runs/all.console.txt; results in work/runs/<tag>.result.json / .owned.json)
 5. node assemble-promotion.cjs    (the five -promotion files from the fPromo run; stops if the exe/asar/installer hashes disagree)
 6. node validate-promotion.mjs <smoke> <owned> <binding> <asar> [report.md]   (replays lines 57 to 64 of create-local-promotion.mjs + 12 negative controls)
    node build-record-check.cjs   (replays lines 34 and 47 to 51 over the build record: three command arguments, source head, archive hash, receipt)
 7. node collect-evidence.cjs      (copies the final results into evidence/ under versioned names, prints the SHA-256 table)

Scenarios run for 0.6.9 (run one with: bash run-scenario.sh <scenario> <tag> [timeoutMs])
  promotion-smoke   the smoke evidence in the promotion schema (tray PNG hashes read by the running app, Pause/Resume callbacks, tray Quit)       [item 8]
  core              launch, tray, close button, ordinary pass over a library with nested-ComicInfo fixtures, Pause/Resume, Quit                    [item 8]
  setup-quit, startup-quit, failed-screen   Quit from the setup, startup and failed screens                                                       [item 8]
  merge-held-comic  the merge tool, #2's WRITTEN archive held by holdshare.py (FILE_SHARE_READ only): (a) released after 7 s -> written, backup deleted;
                    (b) held throughout -> written_unverified in console, results.jsonl, summary.json and the Done: line, backup kept as "Save not
                    verified" (checked in the app's Kept backups), the later archives processed, --resume does not refuse                          [item 1]
  merge-held-backup the merge tool, #2's BACKUP held the same way: (a) released after 7 s -> backup deleted; (b) held throughout -> written, "could not be
                    deleted" in the console, Kept backups "Saved; backup could not be deleted", the run carries on                                 [item 2]
  merge-flush-error the written archive is made read-only between the write and the flush (access denied, not a sharing violation): the run stops, the
                    backup is kept ("Save not verified"), --resume refuses                                                                         [item 3]
  w1-approve        W1 through the app's Approve (/api/apply): holdrw.py has the comic open read-write; it adds a page and closes while the app waits to
                    rename: the comic keeps the change, the backup is kept; positive control (closed unchanged: the Approve succeeds); item 9 (held
                    past the app's 10 s wait: refused, comic unchanged, backup kept)                                                               [items 4, 9]
  app-flush-hold    the app's own 10 s flush wait: holdwait.py opens the app's temporary archive the moment the app closes it (FILE_SHARE_READ only):
                    baseline (nobody holding); (a) released after 4 s: the Approve waits and succeeds; (b) held past 10 s: refused, comic unchanged,
                    backup kept; what is left of the held temporary archive, and whether a new Approve then works                                   [item 9, CHANGELOG "app: up to 10 s"]
  w1-worker         W1 through the worker's automatic write (a 10 ms timeline of comic / temporary archive / pending record / backups)               [item 4]
  w1-merge          W1 through the merge tool                                                                                                        [item 4]
  w1-merge-control  negative control: the same run with the engine of commit 4874894 (rename wait without the re-check): the change is lost
  r3-convert        a CB7 and a 7z named .cbz converted by the app's own pass; CBZ readable (pages byte-equal), original gone, no staging folder       [item 5]
  q1-claims         genuine claim pair of a crashed engine, read-only: record present (0.6.8 section 5), positive control (held), the 0.6.8 edge probe
                    (read-only locks, no .json records) now an assertion (start reaches the dashboard), edge 2 (no leftover record either), control D
                    (a really held read-only lock without its record still refuses with LIBRARY_BUSY; starts once released)                         [item 6]
  r7-csv            a torn tail inside a quoted multi-line Summary of dropped-nested-values.csv, --resume; negative control with the 0.6.8 tool       [item 7]
  r1-readonly       (regression of storage.replace_durably's error classification) a read-only comic through Approve answers at once, not after a wait
Helpers: fixture.py, fixture_approve.py, fixture_merge.py (0.6.8), fixture_merge69.py (plain / r7 mode), fixture_r3.py, pstree.py, holdclaim.py, holdshare.py
(FILE_SHARE_READ only), holdrw.py (read-write open, change, release), holdwait.py (opens a file the moment its writer has closed it), nested_probe.py,
csvdump.py and zipcheck.py (read-only readers), summarize-runs.cjs (one line per scenario run), build-record-check.cjs.
Not run in 0.6.9 (code unchanged since 0.6.8 or 0.6.7; the files are carried, repointed only): quit-frozen, quit-frozen-12, c7-dom, c7-healthy, c7-quitnow,
q2-quit-cut, q2-after-rename, merge-resume, merge-recover, merge-torn, merge-misc (--help, older engine), merge-stopped (superseded by merge-held-comic),
merge-killed-app, q3-late-exit, prev-session, repro-064, quit-in-retry, next-start-after-frozen. Their expected strings still say 0.6.8 where they say so.

observer.cjs (injected on the first call frame of the packaged main process through the private inspector): 28 guards (window show/focus, app/web-contents
focus, notifications, dialogs, shell, every child_process API), real tray menu callbacks, tray bitmaps, a 40 ms sampler of every shell page, DOM clicks in the
main window and in the quit dialog, harness-only offscreen windows for DOM feeds.
Backslashes: write JSON/JS that contains them with a file-writing tool, not a shell heredoc. A record's creation-time integers exceed 2^53: edit such JSON as text.
README-harness-068-original.txt is the 0.6.8 README, kept for the scenarios that were not run.
