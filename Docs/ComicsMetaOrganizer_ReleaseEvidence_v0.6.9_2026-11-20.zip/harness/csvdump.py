"""Futaba 0.6.9 harness helper (r7): read a CSV exactly as any reader would (csv module, utf-8-sig, newline='') and print the rows as one
JSON line. Read only. Usage (packaged python, -B -I): csvdump.py <file.csv>"""
import csv
import json
import sys

with open(sys.argv[1], 'r', encoding='utf-8-sig', newline='') as handle:
    print(json.dumps(list(csv.reader(handle))))
