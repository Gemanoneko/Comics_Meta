"""Futaba 0.6.7 probe: read the QA library's archives and the QA catalog AFTER the app has quit (nothing is running).
Usage (packaged python, -B -I): nested_probe.py <library> <state root> <out.json>
Read only: archives are opened for reading, the catalog is opened with mode=ro."""
import hashlib
import json
import sqlite3
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

library, state, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
result = {'archives': {}, 'catalog': {}, 'counts': {}}
for path in sorted(library.rglob('*.cbz')):
    if '.comic-metadata' in str(path):
        continue
    raw = path.read_bytes()
    entry = {'sha256': hashlib.sha256(raw).hexdigest(), 'size': len(raw)}
    try:
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            roots = [n for n in names if n.lower() == 'comicinfo.xml']
            nested = [n for n in names if n.lower().endswith('/comicinfo.xml')]
            entry.update({'entries': names, 'root': roots, 'nested': nested, 'fields': None})
            if roots:
                xml = ET.fromstring(archive.read(roots[0]))
                entry['fields'] = [[child.tag, child.text or ''] for child in xml]
    except Exception as error:
        entry['error'] = str(error)
    result['archives'][path.name] = entry
database = state / 'data' / 'catalog.sqlite'
uri = 'file:' + str(database).replace('\\', '/') + '?mode=ro'
try:
    con = sqlite3.connect(uri, uri=True, timeout=10)
    con.row_factory = sqlite3.Row
    for row in con.execute('SELECT path,status,error,series,number,year,metadata FROM comics'):
        name = Path(row['path']).name
        try:
            metadata = json.loads(row['metadata'] or '{}')
        except Exception:
            metadata = {'unreadable': True}
        result['catalog'][name] = {'status': row['status'], 'error': row['error'], 'series': row['series'], 'number': row['number'], 'year': row['year'], 'metadata': metadata}
    result['counts'] = {r[0]: r[1] for r in con.execute('SELECT status,COUNT(*) FROM comics GROUP BY status')}
    con.close()
except Exception as error:
    result['catalogError'] = str(error)
out.write_text(json.dumps(result, indent=1), encoding='utf-8')
print(json.dumps({'archives': len(result['archives']), 'catalog': len(result['catalog']), 'counts': result['counts'], 'catalogError': result.get('catalogError')}))
