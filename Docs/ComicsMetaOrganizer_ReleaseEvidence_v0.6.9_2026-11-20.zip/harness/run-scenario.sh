#!/usr/bin/env bash
# Usage: run-scenario.sh <scenario> <tag> [timeoutMs]
# Runs tools/scenarios.mjs <scenario> inside the studio's owned-process supervisor (private kill-on-close Job).
set -u
B="I:/AI Projects/Temp/futaba-069"
NODE="C:/Program Files/nodejs/node.exe"
SC="$1"; TAG="$2"; TMO="${3:-420000}"
OUT="$B/work/runs/$TAG"
mkdir -p "$B/work/runs"
CFG="$B/work/runs/$TAG.cfg.json"
cat > "$CFG" <<EOF
{"file":"$NODE","args":["$B/evidence/harness/scenarios.mjs","$SC","$OUT.result.json"],"cwd":"$B/work","timeoutMs":$TMO,"out":"$OUT.owned.json"}
EOF
rm -f "$OUT.owned.json" "$OUT.result.json"
"$NODE" "$B/evidence/harness/owned-run.mjs" "$CFG"
echo "--- owned run done: $TAG ---"
"$NODE" -e "
const fs=require('fs');const o=JSON.parse(fs.readFileSync('$OUT.owned.json','utf8'));
console.log(JSON.stringify({code:o.code,closed:o.closed,forced:o.forced,timedOut:o.timedOut,nativeZero:o.native&&o.native.zero,retained:o.native&&o.native.retained,elapsedMs:Math.round(o.elapsedMs)}));
console.log((o.out||'').split('\n').slice(-40).join('\n'));
if(o.err)console.log('STDERR:',o.err.slice(-800));
"
