"""Futaba 0.6.9 QA fixture for R3 (CBR/CB7 to CBZ conversion): a scratch library with
  - 'Conversion Seven 001 (2020).cb7'      a 7-Zip archive of three small real PNG pages (a CB7)
  - 'Conversion SameName 002 (2020).cbz'   a 7-Zip archive named .cbz (the "same name" path: the original is set aside, the CBZ takes its place)
  - 'Conversion Control 003 (2020).cbz'    an ordinary zip comic (must be left alone)
All sources are disabled in the config (conversion happens before any lookup). Packaged python, -B -I; 7z.exe from QA_7Z.
Usage: fixture_r3.py <qa root> <library>"""
import hashlib
import json
import os
import struct
import subprocess
import sys
import zipfile
import zlib
from pathlib import Path

root, library = Path(sys.argv[1]), Path(sys.argv[2])
if not root.name.startswith('illuminati-cmo-qa-'):
    raise SystemExit('Refusing a root that is not a private QA root')
sevenzip = os.environ['QA_7Z']
library.mkdir(parents=True, exist_ok=True)


def chunk(kind, data):
    return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)


def png(r, g, b):
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 2, 2, 8, 2, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress((b'\x00' + bytes([r, g, b]) * 2) * 2)) + chunk(b'IEND', b''))


def pages(folder, seed):
    folder.mkdir(parents=True, exist_ok=True)
    out = {}
    for index in range(3):
        name = 'page%03d.png' % (index + 1)
        data = png((seed * 40 + index * 70) % 256, (seed * 90 + index * 30) % 256, (index * 120 + seed) % 256)
        (folder / name).write_bytes(data)
        out[name] = hashlib.sha256(data).hexdigest()
    return out


def seven(archive, folder):
    done = subprocess.run([sevenzip, 'a', '-t7z', str(archive), str(folder / '*')], capture_output=True, creationflags=0x08000000)
    if done.returncode != 0:
        raise SystemExit('7z failed: ' + done.stdout.decode('utf-8', 'replace')[-300:])


scratch = root / 'r3-pages'
facts = {}
a = pages(scratch / 'a', 1)
seven(library / 'Conversion Seven 001 (2020).cb7', scratch / 'a')
facts['Conversion Seven 001 (2020).cb7'] = {'pages': a}
b = pages(scratch / 'b', 2)
seven(library / 'Conversion SameName 002 (2020).cbz', scratch / 'b')
facts['Conversion SameName 002 (2020).cbz'] = {'pages': b}
with zipfile.ZipFile(library / 'Conversion Control 003 (2020).cbz', 'x') as archive:
    archive.writestr('page001.png', png(9, 9, 9))
for name in facts:
    path = library / name
    facts[name]['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    facts[name]['size'] = path.stat().st_size
    facts[name]['is_zip'] = zipfile.is_zipfile(path)
control = library / 'Conversion Control 003 (2020).cbz'
facts['Conversion Control 003 (2020).cbz'] = {'sha256': hashlib.sha256(control.read_bytes()).hexdigest(), 'size': control.stat().st_size, 'is_zip': zipfile.is_zipfile(control)}
print(json.dumps({'prepared': True, 'library': str(library), 'files': facts}))
