"""Futaba 0.6.6 QA fixture (adapted from the repo's install-update-qa/state-fixture.py): a private state root with a
synthetic GCD offline index, a small library of tiny cbz comics, and one cb7 for the bundled-7-Zip conversion.
Run with the packaged python. Touches only the folders named on its command line (under the QA scratch root)."""
import hashlib
import json
import os
import sqlite3
import struct
import subprocess
import sys
import zipfile
import zlib
from pathlib import Path

root = Path(sys.argv[1])
library = Path(sys.argv[2])
count = int(sys.argv[3])
with_cb7 = 'cb7' in sys.argv[4:]
# 0.6.7: 'nested' adds two more matched fixtures whose only ComicInfo is in a subfolder, and three unmatched read-only controls.
nested = 'nested' in sys.argv[4:]
total = count + (3 if nested else 0)
sevenzip = os.environ['QA_7Z']
state = root / 'state'
if Path(os.environ.get('COMICS_META_STATE_ROOT', '')) != state:
    raise SystemExit('COMICS_META_STATE_ROOT must equal ' + str(state))
if root.name.startswith('illuminati-cmo-qa-') is False:
    raise SystemExit('Refusing a root that is not a private QA root')
import app
import gcd_offline

def chunk(kind, data):
    return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)

PNG = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
       + chunk(b'IDAT', zlib.compress(b'\x00\xff\x00\x00')) + chunk(b'IEND', b''))

library.mkdir(parents=True, exist_ok=True)
state.mkdir(parents=True, exist_ok=True)
config = {'sources': {'disabled': ['ComicVine', 'Metron', 'Google Lens', 'Google Books', 'GCD', 'Dark Horse',
                                    'Open Library local index', 'General free web', 'Wikipedia/wiki',
                                    'Saved lead re-checks', 'GetComics', 'PREVIEWSworld', 'Publisher web'],
                      'enabled': ['GCD offline']},
          'in_book': {'cover': False, 'publisher_agreement': False, 'credits_pages': False},
          'browser_search': {'enabled': False, 'lens': False}}
(state / 'config.json').write_text(json.dumps(config), encoding='utf-8')
source = root / '2026-10-16.db'
with sqlite3.connect(source) as con:
    for table, columns in gcd_offline.SCHEMA.items():
        con.execute('CREATE TABLE ' + table + ' (' + ', '.join(
            c + (' INTEGER' if c == 'id' or c.endswith('_id') or c in ('deleted', 'year_began', 'year_ended', 'issue_count', 'is_singleton') else ' TEXT')
            for c in columns.split()) + ')')
    con.execute("INSERT INTO gcd_publisher VALUES(1,'QA Synthetic Publisher')")
    con.execute("INSERT INTO stddata_language VALUES(1,'en')")
    con.execute("INSERT INTO stddata_country VALUES(1,'us')")
    con.execute("INSERT INTO gcd_series_publication_type VALUES(1,'comic book')")
    con.execute("INSERT INTO gcd_series VALUES(1,'Futaba QA Fixture','Futaba QA Fixture',2020,2020,1,1,1,%d,1,'comic book',0,0)" % max(total, 1))
    for number in range(1, total + 1):
        con.execute("INSERT INTO gcd_issue(id,series_id,number,key_date,on_sale_date,title,barcode,valid_isbn,deleted) VALUES(?,1,?,'2020-01-01','2020-01-01',?,'','',0)",
                    (number, str(number), 'Synthetic issue ' + str(number)))
gcd_offline.start(str(source))
gcd_offline._thread.join(200)
if gcd_offline._thread.is_alive() or not gcd_offline.current():
    raise SystemExit('Synthetic GCD index build failed')
for number in range(1, count + 1):
    with zipfile.ZipFile(library / ('Futaba QA Fixture %03d (2020).cbz' % number), 'x') as archive:
        archive.writestr('cover.png', PNG)
NESTED_TEXT = {
    # matched (the synthetic GCD index has these issues): the pass will write them
    'Futaba QA Fixture %03d (2020).cbz' % (count + 1): ['Scans/ComicInfo.xml', '<?xml version="1.0"?><ComicInfo><Series>Futaba QA Fixture</Series><Number>%d</Number><Summary>Nested summary kept by QA %d.</Summary><Writer>Nested Writer QA</Writer><Genre>Nested Genre QA</Genre></ComicInfo>' % (count + 1, count + 1)],
    'Futaba QA Fixture %03d (2020).cbz' % (count + 2): ['Scans/ComicInfo.xml', '<?xml version="1.0"?><ComicInfo><Series>Futaba QA Fixture</Series><Number>None</Number><Summary>Nested summary kept by QA %d.</Summary></ComicInfo>' % (count + 2)],
    # unmatched controls (read side only)
    # 0.6.8 (q2): a nested-only copy as a store-date scrape writes it: store Year/Month/Day, PageCount, a letter-case twin and a year-like Volume
    'Futaba QA Fixture %03d (2020).cbz' % (count + 3): ['Scans/ComicInfo.xml', '<?xml version="1.0"?><ComicInfo><Series>Futaba QA Fixture</Series><Number>%d</Number><Summary>Store-dated nested summary QA %d.</Summary><Volume>2019</Volume><Year>2019</Year><Month>12</Month><Day>31</Day><PageCount>22</PageCount><writer>qa twin</writer><Writer>Store Dated Writer</Writer></ComicInfo>' % (count + 3, count + 3)],
    'QA Nested Delta 001 (2021).cbz': ['Scans/ComicInfo.xml', '<?xml version="1.0"?><ComicInfo><Series>QA Nested Delta</Series><Number>1</Number><Summary>Delta nested summary.</Summary><Volume>2019</Volume><Year>2019</Year><Month>12</Month><Day>31</Day><PageCount>22</PageCount><writer>delta twin</writer><Writer>Delta Writer</Writer></ComicInfo>'],
    'QA Nested Alpha 001 (2021).cbz': ['Scans/ComicInfo.xml', '<?xml version="1.0"?><ComicInfo><Series>QA Nested Alpha</Series><Number>1</Number><Summary>Alpha nested summary.</Summary></ComicInfo>'],
    'QA Nested Gamma 001 (2021).cbz': ['Scans/ComicInfo.xml', '<?xml version="1.0"?><ComicInfo><Series>QA Nested Gamma</Series><Number>None</Number><Summary>Gamma nested summary.</Summary></ComicInfo>'],
}
if nested:
    for name, (entry, text) in NESTED_TEXT.items():
        with zipfile.ZipFile(library / name, 'x') as archive:
            archive.writestr('cover.png', PNG)
            archive.writestr(entry, text)
    with zipfile.ZipFile(library / 'QA Nested Beta 001 (2021).cbz', 'x') as archive:  # two nested copies: ignored by the app
        archive.writestr('cover.png', PNG)
        archive.writestr('Scans/ComicInfo.xml', '<?xml version="1.0"?><ComicInfo><Series>QA Nested Beta</Series><Number>1</Number><Summary>Beta nested one.</Summary></ComicInfo>')
        archive.writestr('Extra/ComicInfo.xml', '<?xml version="1.0"?><ComicInfo><Series>QA Nested Beta</Series><Number>1</Number><Summary>Beta nested two.</Summary></ComicInfo>')
hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(library.glob('*.cbz'))}
out = {'prepared': True, 'library': str(library), 'fixtures': count, 'cb7': None, 'hashes': hashes, 'nested': sorted(list(NESTED_TEXT) + ['QA Nested Beta 001 (2021).cbz']) if nested else None}
if with_cb7:
    cover = root / 'fixture-cover.png'
    cover.write_bytes(PNG)
    target = library / 'Bundled Conversion 001.cb7'
    done = subprocess.run([sevenzip, 'a', '-t7z', str(target), str(cover)], capture_output=True, creationflags=0x08000000)
    if done.returncode != 0:
        raise SystemExit('7z failed to make the cb7 fixture')
    out['cb7'] = str(target)
print(json.dumps(out))
