// Run one command under the studio's owned-process supervisor (private
// kill-on-close Windows Job, bounded deadline, native-zero closure proof) and
// write the raw result plus command identity to a fresh JSON record.
// Usage: <pinned node> owned-run.mjs <config.json>
// config: {file, args[], cwd, timeoutMs, out, env?: {k:v}, pathPrefix?: dir, extra?: {...}}
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';

const STUDIO = 'I:/AI Projects/Studio Illuminati';
const KOFFI = STUDIO + '/WIP/Books Arranger/build-cache/qa-ownership/node_modules/koffi';
const {runOwned} = await import(pathToFileURL(STUDIO + '/.claude/skills/qa-handoff/scripts/bounded-check.mjs').href);

const config = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
if (!path.isAbsolute(config.out) || fs.existsSync(config.out)) throw new Error('Fresh absolute record path required');
const env = {...process.env, ...(config.env || {})};
if (config.pathPrefix) {
  const key = Object.keys(env).find(k => k.toUpperCase() === 'PATH') || 'PATH';
  env[key] = config.pathPrefix + ';' + (env[key] || '');
}
const result = await runOwned(config.file, config.args, {cwd: config.cwd, env, timeoutMs: config.timeoutMs, koffiRoot: KOFFI});
const record = {...result, command: {file: config.file, args: config.args}, cwd: config.cwd, koffiRoot: KOFFI, ...(config.extra || {})};
fs.writeFileSync(config.out, JSON.stringify(record, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify({record: config.out, code: result.code, ok: result.ok, closed: result.closed, forced: result.forced,
  timedOut: result.timedOut, nativeZero: result.native?.zero ?? null, elapsedMs: Math.round(result.elapsedMs),
  errBytes: Buffer.byteLength(result.err || ''), supervisorErrBytes: Buffer.byteLength(result.supervisorErr || '')}));
