// Futaba 0.6.9 QA scenarios (the delta of the 0.6.9 CHANGELOG): the merge tool's held comic / held backup / other flush error, W1 (a program changes
// the comic while the writer waits to rename), R3 (CB7 and a 7z named .cbz converted), r7 (a torn CSV tail inside a quoted multi-line value).
// Registered into scenarios.mjs by registerDelta(E) after new068.mjs's register(E) (which provides E.h). Scratch fixtures and private QA roots only;
// the merge tool is always given --live <scratch state> and --engine <the PACKAGED engine>.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { launch, makeRoot, setupLibrary, waitFor, sleep, win, PY, SEVENZ, BASE, pidAlive, runInfoForEvidence, EXTRACT } from './lib.mjs';

const RC = 'I:/AI Projects/Worktrees/Comics Meta Organizer/rc-069';
const ENGINE = EXTRACT + '/resources/engine';
const TOOL = RC + '/tools/nested_comicinfo_merge.py';
const H = BASE + '/evidence/harness';
const PREV_COMMIT = 'da503b3d45798bfb7142c377fe2db5704c509153'; // the 0.6.8 build: its merge tool is the negative control of r7
const NAMES = ['Merge A 001 (2020).cbz', 'Merge B 002 (2020).cbz', 'Merge C 003 (2020).cbz', 'Merge D 004 (2020).cbz'];
const sha256Stream = f => new Promise((resolve, reject) => { const hs = crypto.createHash('sha256'); fs.createReadStream(f).on('data', d => hs.update(d)).on('end', () => resolve(hs.digest('hex'))).on('error', reject); });

export function registerDelta(E) {
  const { S, out, check } = E;
  const h = E.h;
  const toolEnv = info => ({ ...process.env, COMICS_META_STATE_ROOT: info.state, COMICS_META_LOCK_DIR: info.locks, LOCALAPPDATA: win(BASE + '/tmp/localappdata'), APPDATA: win(BASE + '/tmp/appdata'), TEMP: info.tmp, TMP: info.tmp, PYTHONDONTWRITEBYTECODE: '1' });
  const toolSync = (args, info, timeout = 300000, tool = TOOL) => { const t = Date.now(); const r = spawnSync(PY, ['-B', '-I', tool, ...args], { env: toolEnv(info), windowsHide: true, encoding: 'utf8', timeout }); return { code: r.status, stdout: r.stdout || '', stderr: r.stderr || '', ms: Date.now() - t }; };
  function toolSpawn(args, info, tool = TOOL) {
    const child = spawn(PY, ['-B', '-I', tool, ...args], { env: toolEnv(info), windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '', stderr = '';
    child.stdout.on('data', d => { stdout += d; }); child.stderr.on('data', d => { stderr += d; });
    const exited = new Promise(resolve => child.once('exit', (code, signal) => resolve({ code, signal, t: Date.now() })));
    return { child, out: () => stdout, err: () => stderr, exited };
  }
  const jsonl = f => { try { return fs.readFileSync(f, 'utf8').split('\n').filter(Boolean).map(l => { try { return JSON.parse(l); } catch { return { torn: l.slice(0, 40) }; } }); } catch { return []; } };
  const stateJsonl = info => jsonl(path.win32.join(info.state, 'data', 'removed-nested-copies.jsonl'));
  const bak = (lib, name) => h.backupsOf(lib, name);
  const pyJson = (script, args, timeout = 120000) => { const r = spawnSync(PY, ['-B', '-I', H + '/' + script, ...args], { env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' }, windowsHide: true, encoding: 'utf8', timeout }); try { return JSON.parse(r.stdout.trim().split('\n').slice(-1)[0]); } catch { return { error: 'unreadable', status: r.status, stderr: (r.stderr || '').slice(-300) }; } };
  const entriesOf = file => { const r = spawnSync(SEVENZ, ['l', '-ba', file], { windowsHide: true, encoding: 'utf8', timeout: 60000 }).stdout || ''; return r.split(/\r?\n/).map(l => l.trim().split(/\s+/).slice(5).join(' ')).filter(Boolean); };
  const lastLines = (t, n) => h.lastLines(t, n);
  const sizeOf = f => { try { return fs.statSync(f).size; } catch { return null; } };

  // A started helper process driven through stdin lines; output collected.
  function startHolder(script, file) {
    const child = spawn(PY, ['-B', '-I', H + '/' + script, file], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    let o = '';
    child.stdout.on('data', d => { o += d; });
    const exited = new Promise(resolve => child.once('exit', code => resolve(code)));
    return {
      child, text: () => o, send: line => { try { child.stdin.write(line + '\n'); } catch { } },
      ready: () => waitFor(() => /ready/.test(o), 'holder ready', 20000, 30),
      held: () => waitFor(() => /held/.test(o) || /open failed/.test(o), 'holder opened the file', 15000, 10).then(() => /held/.test(o)),
      alive: () => child.exitCode === null,
      end: async () => { try { child.stdin.end(); } catch { } await Promise.race([exited, sleep(10000)]); try { child.kill(); } catch { } },
    };
  }

  // A QA root with the scratch library, catalog, plan. No app is launched. mode 'plain' | 'r7'; tool = the merge tool file used for the dry run.
  async function prepare(tag, bigMb, mode = 'plain', tool = TOOL) {
    const info = await makeRoot(tag);
    const lib = path.win32.join(info.root, 'library');
    const made = h.pyRun([H + '/fixture_merge69.py', info.root, lib, String(bigMb), mode], h.pyEnv(info), 300000);
    if (made.status !== 0) throw new Error('merge fixture failed: ' + made.stderr + made.stdout);
    const fx = JSON.parse(made.stdout.trim().split('\n').slice(-1)[0]);
    const planMd = path.win32.join(info.root, 'plan', 'plan.md');
    fs.mkdirSync(path.dirname(planMd), { recursive: true });
    const dry = toolSync(['--report', planMd, '--library', lib, '--live', info.state], info, 300000, tool);
    const planFile = planMd.replace(/\.md$/, '.json');
    const plan = JSON.parse(fs.readFileSync(planFile, 'utf8'));
    const result = { info, lib, fx, planFile, plan, tool, planSha: crypto.createHash('sha256').update(fs.readFileSync(planFile)).digest('hex'), dryCode: dry.code };
    check(tag + ': scratch library of 4 archives (root + one nested ComicInfo each, #2 ' + (bigMb ? 'large' : 'small') + ', mode ' + mode + '); scanned catalog; dry run planned 4 merges', dry.code === 0 && fx.catalogRows === 4 && plan.entries.length === 4 && plan.entries.every(e => e.action === 'merge'), { dryCode: dry.code, catalogRows: fx.catalogRows, entries: plan.entries.map(e => path.basename(e.path) + ':' + e.action), bigBytes: fx.files[NAMES[1]].size, planSha256: result.planSha });
    return result;
  }
  const applyArgs = (p, outDir, extra = [], engine = ENGINE) => ['--apply', p.planFile, '--out', outDir, '--engine', win(engine), '--live', p.info.state, ...extra];
  const journalOf = outDir => jsonl(path.win32.join(outDir, 'journal.jsonl'));
  const resultsOf = outDir => jsonl(path.win32.join(outDir, 'results.jsonl'));

  async function archiveFacts(p, name, mode = 'plain') {
    const file = path.win32.join(p.lib, name);
    const xml = h.comicInfoOf(file) || '';
    const names = entriesOf(file);
    const n = NAMES.indexOf(name) + 1;
    const merged = mode === 'plain'
      ? new RegExp('<Summary>Nested summary ' + n + '\\.</Summary>').test(xml) && new RegExp('<Writer>Nested Writer ' + n + '</Writer>').test(xml) && /<Genre>Nested Genre<\/Genre>/.test(xml)
      : new RegExp('<Summary>Root summary ' + n + '\\.</Summary>').test(xml) && new RegExp('<Writer>Nested Writer ' + n + '</Writer>').test(xml) && /<Genre>Nested Genre<\/Genre>/.test(xml);
    return { sha: await sha256Stream(file), rootCopies: names.filter(x => x.toLowerCase() === 'comicinfo.xml').length, nestedCopies: names.filter(x => /\/comicinfo\.xml$/i.test(x)).length, merged,
      rootKept: new RegExp('<Series>Merge QA Series</Series>').test(xml) && new RegExp('<Number>' + n + '</Number>').test(xml), year: /<Year>/.test(xml) };
  }
  async function finalChecks(p, outDir, mode = 'plain') {
    const facts = {};
    for (const n of NAMES) facts[n] = await archiveFacts(p, n, mode);
    const allMerged = NAMES.every(n => facts[n].rootCopies === 1 && facts[n].nestedCopies === 0 && facts[n].merged && facts[n].rootKept && !facts[n].year);
    const summary = (() => { try { return JSON.parse(fs.readFileSync(path.win32.join(outDir, 'summary.json'), 'utf8')); } catch { return null; } })();
    const history = await h.sql(p.info, 'SELECT h.path, l.writer, l.source, l.origin FROM history h LEFT JOIN write_ledger l ON l.history_id=h.id ORDER BY h.id');
    const left = NAMES.map(n => bak(p.lib, n).length).reduce((a, b) => a + b, 0);
    return { facts, allMerged, summary, historyRows: history.length, backupsLeft: left, tmpLeft: NAMES.filter(n => fs.existsSync(path.win32.join(p.lib, n + '.metadata-tmp'))).length, pendingLeft: h.pendingFiles(p.info).length };
  }

  // Interrupt an apply while #2's temporary file is growing (the tool is ended).
  async function interruptMid(p, outDir, tool = TOOL) {
    const big = path.win32.join(p.lib, NAMES[1]), temp = big + '.metadata-tmp', orig = p.fx.files[NAMES[1]];
    const run = toolSpawn(applyArgs(p, outDir), p.info, tool);
    try {
      await waitFor(() => { try { return fs.statSync(temp).size >= 20 * 1024 * 1024; } catch { return false; } }, 'big archive temporary file growing', 120000, 20);
      process.kill(run.child.pid);
      const ex = await Promise.race([run.exited, sleep(15000).then(() => null)]);
      await sleep(1500);
      return { killed: ex && { code: ex.code, signal: ex.signal }, toolPidAlive: pidAlive(run.child.pid), temporaryExists: fs.existsSync(temp), pending: h.pendingFiles(p.info).length, backupsOfBig: bak(p.lib, NAMES[1]).length,
        bigIsOriginal: (await sha256Stream(big)) === orig.sha256, results: resultsOf(outDir).map(r => path.basename(r.path) + ':' + r.outcome), csvExists: fs.existsSync(path.win32.join(outDir, 'dropped-nested-values.csv')) };
    } finally { try { process.kill(run.child.pid); } catch { } }
  }

  // The app on the tool's state: Kept backups listing and the real panel text; then the tray Quit.
  async function keptViaApp(p, tag) {
    E.run = await launch(tag + '-app', { existing: p.info });
    const rec = { run: runInfoForEvidence(E.run) };
    await E.run.qa('sampleStart(40)');
    const first = await waitFor(async () => { const st = await E.run.qa('state()', true); return ['ready', 'setup'].includes(st.service) && st.service; }, 'app start outcome', 90000, 300);
    rec.firstScreen = first;
    if (first === 'setup') await setupLibrary(E.run, p.lib);
    await E.readyEngine(tag + ' app start', 1);
    const kept = await h.backupsListing(E.run);
    rec.keptHttp = kept.http; rec.kept = kept.body;
    rec.panel = await h.keptPanelText(E.run);
    rec.recoveryLines = h.recoveryLines(p.info);
    rec.quit = await E.quitViaTray(tag + ' app', { staleClaimsOk: true });
    return rec;
  }

  // -------------------------------------------------------------------------------------------------------------------
  // Items 1 and 2: the merge tool with a comic (or its backup) held by another program (holdshare.py: FILE_SHARE_READ only)
  // -------------------------------------------------------------------------------------------------------------------
  async function mergeHold({ tag, target, mode, releaseAfterMs = 6000 }) {
    const bigMb = Number(process.env.QA_MERGE_MB || 120);
    const p = await prepare(tag, bigMb);
    const outDir = path.win32.join(p.info.root, 'merge-out');
    const big = path.win32.join(p.lib, NAMES[1]);
    const rec = { tag, target, mode };
    let holder = null;
    if (target === 'comic') { holder = startHolder('holdshare.py', big); await holder.ready(); }
    const run = toolSpawn(applyArgs(p, outDir), p.info);
    try {
      if (target === 'backup') {
        const backupPath = await waitFor(() => { for (const f of h.pendingFiles(p.info)) { try { const j = JSON.parse(fs.readFileSync(f, 'utf8')); if (/Merge B/.test(j.path) && j.backup) return j.backup; } catch { } } return false; }, 'pending record of #2 naming its backup', 180000, 3);
        rec.pendingBackup = path.basename(backupPath);
        holder = startHolder('holdshare.py', win(backupPath)); await holder.ready();
      }
      const written = await waitFor(() => journalOf(outDir).find(e => e.event === 'written' && /Merge B/.test(e.path)), 'journal: written for #2', 180000, 3);
      rec.journalBackup = path.basename(written.backup || '');
      holder.send('go');
      const tHold = Date.now();
      rec.holderLanded = await holder.held();
      rec.landedMs = Date.now() - tHold;
      if (target === 'backup') rec.holdTargetIsJournalBackup = rec.pendingBackup === rec.journalBackup;
      if (mode === 'release') {
        await sleep(releaseAfterMs);
        rec.toolWaitingAtRelease = run.child.exitCode === null && !resultsOf(outDir).some(r => /Merge B/.test(r.path));
        await holder.end();
        rec.heldMs = Date.now() - tHold;
      } else {
        const resB = await waitFor(() => resultsOf(outDir).find(r => /Merge B/.test(r.path)), 'a result line for #2', 150000, 100);
        rec.resultAfterMs = Date.now() - tHold;
        rec.holderStillHoldingAtResult = holder.alive() && !/released/.test(holder.text());
        rec.resultOutcome = resB.outcome;
        await holder.end();
        rec.heldMs = Date.now() - tHold;
      }
      const ex = await Promise.race([run.exited, sleep(180000).then(() => null)]);
      rec.exit = ex && { code: ex.code, signal: ex.signal };
      rec.stdout = lastLines(run.out(), 12);
      rec.stderr = lastLines(run.err(), 6);
      rec.fullStdout = run.out();
    } finally { try { if (holder) await holder.end(); } catch { } try { process.kill(run.child.pid); } catch { } }
    rec.results = resultsOf(outDir);
    rec.summary = (() => { try { return JSON.parse(fs.readFileSync(path.win32.join(outDir, 'summary.json'), 'utf8')); } catch { return null; } })();
    return { p, outDir, rec };
  }

  E.scenarios['merge-held-comic'] = async () => {
    // (a) released within 30 s
    {
      const { p, outDir, rec } = await mergeHold({ tag: 'mhca', target: 'comic', mode: 'release', releaseAfterMs: 7000 });
      out.heldComicReleased = { ...rec, fullStdout: undefined, results: rec.results.map(r => ({ archive: path.basename(r.path), outcome: r.outcome, backup_removed: r.backup_removed, kept_as: r.kept_as, reason: r.reason })) };
      check('1a: the reader held the WRITTEN archive #2 (FILE_SHARE_READ only) and the tool was still waiting (running, no result for #2) 7 s later', rec.holderLanded && rec.toolWaitingAtRelease, { landedMs: rec.landedMs, holder: 'held', toolWaitingAtRelease: rec.toolWaitingAtRelease });
      const resB = rec.results.find(r => /Merge B/.test(r.path));
      check('1a: released within 30 s: #2 result "written" with its backup deleted, the run finished (exit 0, Done: {\'written\': 4})', resB && resB.outcome === 'written' && resB.backup_removed === true && rec.exit && rec.exit.code === 0 && /Done: \{'written': 4\}/.test(rec.fullStdout) && rec.results.length === 4 && rec.results.every(r => r.outcome === 'written'), { resB: resB && { outcome: resB.outcome, backup_removed: resB.backup_removed }, exit: rec.exit, stdoutTail: rec.stdout.slice(-3), summary: rec.summary });
      const fin = await finalChecks(p, outDir);
      out.heldComicReleasedFinal = fin;
      check('1a: every archive merged (one root ComicInfo, no nested copy), no backup, temporary file or pending record left, 4 history rows, summary written 4', fin.allMerged && fin.backupsLeft === 0 && fin.tmpLeft === 0 && fin.pendingLeft === 0 && fin.historyRows === 4 && fin.summary && fin.summary.written === 4 && Object.keys(fin.summary).length === 1, { summary: fin.summary, backupsLeft: fin.backupsLeft, historyRows: fin.historyRows });
    }
    // (b) held throughout
    {
      const { p, outDir, rec } = await mergeHold({ tag: 'mhcb', target: 'comic', mode: 'throughout' });
      out.heldComicThroughout = { ...rec, fullStdout: undefined, results: rec.results.map(r => ({ archive: path.basename(r.path), outcome: r.outcome, backup_removed: r.backup_removed, kept_as: r.kept_as, reason: r.reason })) };
      const resB = rec.results.find(r => /Merge B/.test(r.path));
      check('1b: held throughout: the reader got in and was still holding when the tool gave up; the tool waited about 30 s (28 to 45 s) before it reported #2', rec.holderLanded && rec.holderStillHoldingAtResult && rec.resultAfterMs >= 28000 && rec.resultAfterMs <= 45000, { landedMs: rec.landedMs, resultAfterMs: rec.resultAfterMs, holderStillHoldingAtResult: rec.holderStillHoldingAtResult });
      check('1b: result "written_unverified" in results.jsonl (kept_as save_not_verified, backup not removed), with the reason naming the flush and the 30 s hold', resB && resB.outcome === 'written_unverified' && resB.kept_as === 'save_not_verified' && resB.backup_removed !== true && /could not be flushed to disk \(another program held it open for 30 s\)/.test(resB.reason || ''), { resB });
      const lineB = rec.fullStdout.split(/\r?\n/).find(l => /Merge B 002/.test(l));
      check('1b: the console line says written_unverified for #2, and the Done: line counts it ({\'written\': 3, \'written_unverified\': 1}), exit 0', /^written_unverified Merge B 002 \(2020\)\.cbz: backup kept:/.test(lineB || '') && /Done: \{'written': 3, 'written_unverified': 1\}/.test(rec.fullStdout) && rec.exit && rec.exit.code === 0, { lineB: (lineB || '').slice(0, 200), done: (rec.fullStdout.split(/\r?\n/).find(l => /^Done:/.test(l)) || ''), exit: rec.exit });
      check('1b: summary.json counts it as written_unverified, not skipped ({written: 3, written_unverified: 1}, no skipped key)', rec.summary && rec.summary.written === 3 && rec.summary.written_unverified === 1 && !('skipped' in rec.summary) && Object.keys(rec.summary).length === 2, { summary: rec.summary });
      check('1b: the run carried on: #1, #3 and #4 written, four result lines in order', rec.results.length === 4 && rec.results.map(r => r.outcome).join() === 'written,written_unverified,written,written', { outcomes: rec.results.map(r => r.outcome) });
      const orig = p.fx.files[NAMES[1]];
      const bs = bak(p.lib, NAMES[1]);
      check('1b: #2 is the new (merged) archive and its backup is kept, equal to the original archive', bs.length === 1 && (await sha256Stream(bs[0])) === orig.sha256 && (await sha256Stream(path.win32.join(p.lib, NAMES[1]))) !== orig.sha256, { backups: bs.map(f => path.basename(f)) });
      const before = {}; for (const n of NAMES) before[n] = await sha256Stream(path.win32.join(p.lib, n));
      const resumed = toolSync(applyArgs(p, outDir, ['--resume']), p.info);
      out.heldComicResume = { code: resumed.code, stdout: lastLines(resumed.stdout, 6), stderr: lastLines(resumed.stderr, 6) };
      const after = {}; for (const n of NAMES) after[n] = await sha256Stream(path.win32.join(p.lib, n));
      const resumedResults = resultsOf(outDir);
      check('1b: --resume does not refuse (exit 0, no "last run stopped" message), changes no archive and adds no result line', resumed.code === 0 && !/last run stopped/i.test(resumed.stdout + resumed.stderr) && NAMES.every(n => before[n] === after[n]) && resumedResults.length === 4 && /Done: \{'written': 3, 'written_unverified': 1\}/.test(resumed.stdout), out.heldComicResume);
      const fin = await finalChecks(p, outDir);
      out.heldComicThroughoutFinal = fin;
      check('1b: all four archives are merged on disk; only #2\'s backup is left (1 backup); 4 history rows', fin.allMerged && fin.backupsLeft === 1 && fin.historyRows === 4 && fin.tmpLeft === 0 && fin.pendingLeft === 0, { backupsLeft: fin.backupsLeft, historyRows: fin.historyRows });
      const app = await keptViaApp(p, 'mhcb');
      out.heldComicKept = app;
      check('1b: the app lists that backup in Kept backups with reason save_not_verified, and the real panel code says "Save not verified"', app.keptHttp === 200 && app.kept.count === 1 && app.kept.items[0].name === NAMES[1] && app.kept.items[0].reason === 'save_not_verified' && app.panel && app.panel.reasons.includes('Save not verified'), { count: app.kept && app.kept.count, reason: app.kept && app.kept.items && app.kept.items[0] && app.kept.items[0].reason, panel: app.panel && app.panel.reasons });
      check('1b: the app\'s start had nothing to recover (the tool had finished the write and its history)', app.recoveryLines.length === 0, { lines: app.recoveryLines });
    }
    out.pass = S.list.every(s => s.ok !== false);
  };

  E.scenarios['merge-held-backup'] = async () => {
    // (a) released within 30 s
    {
      const { p, outDir, rec } = await mergeHold({ tag: 'mhba', target: 'backup', mode: 'release', releaseAfterMs: 7000 });
      out.heldBackupReleased = { ...rec, fullStdout: undefined, results: rec.results.map(r => ({ archive: path.basename(r.path), outcome: r.outcome, backup_removed: r.backup_removed, kept_as: r.kept_as, reason: r.reason })) };
      check('2a: the reader held the BACKUP of #2 (FILE_SHARE_READ only; the target is the backup the journal names) and the tool was still waiting 7 s later', rec.holderLanded && rec.holdTargetIsJournalBackup && rec.toolWaitingAtRelease, { landedMs: rec.landedMs, backup: rec.journalBackup, toolWaitingAtRelease: rec.toolWaitingAtRelease });
      const resB = rec.results.find(r => /Merge B/.test(r.path));
      check('2a: released within 30 s: #2 "written", its backup deleted, the run finished (Done: {\'written\': 4}, exit 0)', resB && resB.outcome === 'written' && resB.backup_removed === true && !resB.kept_as && rec.exit && rec.exit.code === 0 && /Done: \{'written': 4\}/.test(rec.fullStdout) && rec.results.length === 4, { resB: resB && { outcome: resB.outcome, backup_removed: resB.backup_removed, kept_as: resB.kept_as }, exit: rec.exit, summary: rec.summary });
      const fin = await finalChecks(p, outDir);
      out.heldBackupReleasedFinal = fin;
      check('2a: every archive merged, no backup left (the held one is gone), 4 history rows', fin.allMerged && fin.backupsLeft === 0 && fin.historyRows === 4 && fin.tmpLeft === 0 && fin.pendingLeft === 0, { backupsLeft: fin.backupsLeft, historyRows: fin.historyRows });
    }
    // (b) held throughout
    {
      const { p, outDir, rec } = await mergeHold({ tag: 'mhbb', target: 'backup', mode: 'throughout' });
      out.heldBackupThroughout = { ...rec, fullStdout: undefined, results: rec.results.map(r => ({ archive: path.basename(r.path), outcome: r.outcome, backup_removed: r.backup_removed, kept_as: r.kept_as, reason: r.reason })) };
      const resB = rec.results.find(r => /Merge B/.test(r.path));
      check('2b: held throughout: the reader held the backup and was still holding when the tool gave up; the tool waited about 30 s (28 to 45 s)', rec.holderLanded && rec.holdTargetIsJournalBackup && rec.holderStillHoldingAtResult && rec.resultAfterMs >= 28000 && rec.resultAfterMs <= 45000, { landedMs: rec.landedMs, resultAfterMs: rec.resultAfterMs });
      check('2b: result "written" (the archive is written and checked; kept_as delete_refused; backup not removed)', resB && resB.outcome === 'written' && resB.kept_as === 'delete_refused' && resB.backup_removed !== true, { resB });
      const lineB = rec.fullStdout.split(/\r?\n/).find(l => /Merge B 002/.test(l));
      check('2b: the console says "could not be deleted" for #2 (another program held it open for 30 s)', /^written Merge B 002 \(2020\)\.cbz: backup kept: it could not be deleted \(another program held it open for 30 s\)/.test(lineB || ''), { lineB: (lineB || '').slice(0, 220) });
      check('2b: the run carried on: four results all "written", Done: {\'written\': 4}, summary {written: 4}, exit 0', rec.results.length === 4 && rec.results.every(r => r.outcome === 'written') && /Done: \{'written': 4\}/.test(rec.fullStdout) && rec.summary && rec.summary.written === 4 && Object.keys(rec.summary).length === 1 && rec.exit && rec.exit.code === 0, { outcomes: rec.results.map(r => r.outcome), summary: rec.summary, exit: rec.exit });
      const orig = p.fx.files[NAMES[1]];
      const bs = bak(p.lib, NAMES[1]);
      check('2b: the backup is kept and equal to the original; #2 itself is the merged archive', bs.length === 1 && (await sha256Stream(bs[0])) === orig.sha256 && (await sha256Stream(path.win32.join(p.lib, NAMES[1]))) !== orig.sha256, { backups: bs.map(f => path.basename(f)) });
      const fin = await finalChecks(p, outDir);
      out.heldBackupThroughoutFinal = fin;
      check('2b: all four archives merged; one backup left (#2\'s); 4 history rows; no temporary file or pending record', fin.allMerged && fin.backupsLeft === 1 && fin.historyRows === 4 && fin.tmpLeft === 0 && fin.pendingLeft === 0, { backupsLeft: fin.backupsLeft, historyRows: fin.historyRows });
      const app = await keptViaApp(p, 'mhbb');
      out.heldBackupKept = app;
      check('2b: Kept backups lists it with reason delete_refused and the real panel shows "Saved; backup could not be deleted"', app.keptHttp === 200 && app.kept.count === 1 && app.kept.items[0].name === NAMES[1] && app.kept.items[0].reason === 'delete_refused' && app.panel && app.panel.reasons.includes('Saved; backup could not be deleted'), { count: app.kept && app.kept.count, reason: app.kept && app.kept.items && app.kept.items[0] && app.kept.items[0].reason, panel: app.panel && app.panel.reasons });
      check('2b: the app\'s start had nothing to recover', app.recoveryLines.length === 0, { lines: app.recoveryLines });
    }
    out.pass = S.list.every(s => s.ok !== false);
  };

  // -------------------------------------------------------------------------------------------------------------------
  // Item 3: a flush that fails for a reason other than a held file (the written archive is made read-only between the write and the flush:
  // CreateFileW(GENERIC_WRITE) then fails with error 5, not 32) still stops the run with the backup kept.
  // -------------------------------------------------------------------------------------------------------------------
  E.scenarios['merge-flush-error'] = async () => {
    const bigMb = Number(process.env.QA_MERGE_MB || 120);
    const p = await prepare('mfe', bigMb);
    const outDir = path.win32.join(p.info.root, 'merge-out');
    const big = path.win32.join(p.lib, NAMES[1]);
    const run = toolSpawn(applyArgs(p, outDir), p.info);
    const rec = {};
    let landed = false;
    try {
      await waitFor(() => journalOf(outDir).find(e => e.event === 'written' && /Merge B/.test(e.path)), 'journal: written for #2', 180000, 2);
      fs.chmodSync(big, 0o444);
      landed = true;
      const ex = await Promise.race([run.exited, sleep(120000).then(() => null)]);
      rec.exit = ex && { code: ex.code, signal: ex.signal };
      rec.stdout = lastLines(run.out(), 8); rec.stderr = lastLines(run.err(), 4); rec.fullStdout = run.out();
    } finally { try { fs.chmodSync(big, 0o666); } catch { } try { process.kill(run.child.pid); } catch { } }
    const results = resultsOf(outDir);
    out.flushError = { ...rec, fullStdout: undefined, results: results.map(r => ({ archive: path.basename(r.path), outcome: r.outcome, backup_removed: r.backup_removed, kept_as: r.kept_as, reason: r.reason })) };
    const resB = results.find(r => /Merge B/.test(r.path));
    check('3: the written archive #2 was made read-only before the flush (a non-sharing error: access denied, not a sharing violation) and the tool\'s flush failed', landed && resB && /WinError 5|Access is denied/i.test(resB.reason || ''), { reason: resB && resB.reason });
    check('3: result "stopped" for #2 with the backup kept (reason: backup kept: the written archive could not be flushed to disk), NOT written_unverified', resB && resB.outcome === 'stopped' && /^backup kept: the written archive could not be flushed to disk: /.test(resB.reason || '') && resB.backup_removed !== true, { resB });
    check('3: the run stopped at #2: two result lines (#1 written, #2 stopped); #3 and #4 not started and byte-identical to the fixture; summary {written: 1, stopped: 1}; Done line', results.length === 2 && results[0].outcome === 'written' && /Done: \{'written': 1, 'stopped': 1\}/.test(rec.fullStdout) && rec.exit && rec.exit.code === 0, { outcomes: results.map(r => r.outcome), exit: rec.exit });
    const c = await sha256Stream(path.win32.join(p.lib, NAMES[2])), d = await sha256Stream(path.win32.join(p.lib, NAMES[3]));
    check('3: #3 and #4 untouched (equal to the fixture)', c === p.fx.files[NAMES[2]].sha256 && d === p.fx.files[NAMES[3]].sha256, {});
    const orig = p.fx.files[NAMES[1]];
    const bs = bak(p.lib, NAMES[1]);
    check('3: the backup of #2 is kept and equal to the original archive', bs.length === 1 && (await sha256Stream(bs[0])) === orig.sha256, { backups: bs.map(f => path.basename(f)) });
    const resumed = toolSync(applyArgs(p, outDir, ['--resume']), p.info);
    out.flushErrorResume = { code: resumed.code, text: lastLines(resumed.stdout + resumed.stderr, 4) };
    check('3: --resume refuses after a stopped run ("The last run stopped at ..."), writing nothing (the documented step 4 still holds)', resumed.code !== 0 && /The last run stopped at .*Merge B 002/.test(resumed.stdout + resumed.stderr) && (await sha256Stream(path.win32.join(p.lib, NAMES[2]))) === p.fx.files[NAMES[2]].sha256, out.flushErrorResume);
    const app = await keptViaApp(p, 'mfe');
    out.flushErrorKept = app;
    check('3: Kept backups lists the backup as save_not_verified and the panel says "Save not verified"', app.keptHttp === 200 && app.kept.count === 1 && app.kept.items[0].reason === 'save_not_verified' && app.panel && app.panel.reasons.includes('Save not verified'), { count: app.kept && app.kept.count, reason: app.kept && app.kept.items && app.kept.items[0] && app.kept.items[0].reason, panel: app.panel && app.panel.reasons });
    out.pass = S.list.every(s => s.ok !== false);
  };

  // -------------------------------------------------------------------------------------------------------------------
  // Item 4 W1: another program has the comic open read-write, changes it, and closes it while a writer waits to rename.
  // -------------------------------------------------------------------------------------------------------------------
  const pendingWith = (info, rx, key) => { for (const f of h.pendingFiles(info)) { try { const j = JSON.parse(fs.readFileSync(f, 'utf8')); if (rx.test(j.path) && (!key || key in j)) return j; } catch { } } return null; };
  const approveState = (bigMb, bigCount, extras) => async info => {
    const lib = E.emptyLibrary(info);
    const done = h.pyRun([H + '/fixture_approve.py', info.root, lib, String(bigMb), String(bigCount), ...extras], h.pyEnv(info), 300000);
    if (done.status !== 0) throw new Error('approve fixture failed: ' + done.stderr + done.stdout);
    out.fixture = JSON.parse(done.stdout.trim().split('\n').slice(-1)[0]);
  };

  E.scenarios['w1-approve'] = async () => {
    await E.startup('w1a', approveState(12, 2, ['plain']));
    const info = { tmp: E.run.tmp, root: E.run.root, state: E.run.state, locks: E.run.locks };
    const lib = h.comicFolder(info);
    await E.run.qa('sampleStart(40)');
    await setupLibrary(E.run, lib);
    await E.readyEngine('w1a first start', 1);
    out.cases = {};
    // behaviour: 'change' (the other program changes the comic while the app waits), 'release' (positive control: it closes it unchanged), 'throughout' (item 9: held past the app's 10 s wait)
    async function approveWith(name, issue, behaviour) {
      const comic = path.win32.join(lib, name), temp = comic + '.metadata-tmp';
      const orig = out.fixture.files[name];
      const row = await h.comicId(E.run, name);
      const holder = startHolder('holdrw.py', comic);
      await holder.ready(); holder.send('hold');
      const heldOk = await holder.held();
      const t0 = Date.now();
      let answer = 'pending';
      const approve = h.post(E.run, '/api/apply', { comic: row.id, issue }, 90000).then(r => { answer = { http: r.http, ms: Date.now() - t0, body: r.body }; return answer; }, e => { answer = 'connection ended: ' + (e && e.name); return answer; });
      const rec = { name, behaviour, heldOk };
      try {
        const after = await waitFor(() => pendingWith(info, new RegExp(name.replace(/[()]/g, '\\$&')), 'after'), 'pending record with its after signature', 60000, 10);
        rec.afterAtMs = Date.now() - t0;
        if (behaviour !== 'throughout') {
          await sleep(2500);
          rec.waitingAt2500 = { answerPending: answer === 'pending', temporaryExists: fs.existsSync(temp), comicSizeUnchanged: fs.statSync(comic).size === orig.size };
          if (behaviour === 'change') {
            holder.send('change');
            await waitFor(() => /changed/.test(holder.text()), 'holder changed the comic', 15000, 20);
            rec.change = JSON.parse(holder.text().split('\n').find(l => l.startsWith('{"changed"')));
          }
          holder.send('release');
          await waitFor(() => /released/.test(holder.text()), 'holder released', 15000, 20);
          rec.releasedAtMs = Date.now() - t0;
        }
        await Promise.race([approve, sleep(60000)]);
        if (behaviour === 'throughout') { rec.holderStillHoldingAtAnswer = holder.alive() && !/released/.test(holder.text()); }
      } finally { await holder.end(); }
      rec.answer = answer === 'pending' ? 'no answer' : typeof answer === 'string' ? answer : { http: answer.http, ms: answer.ms, verified: answer.body && answer.body.verified, error: answer.body && answer.body.error, backup_removed: answer.body && answer.body.backup_removed_after_verification, backup: answer.body && answer.body.backup && path.basename(answer.body.backup) };
      const bs = bak(lib, name);
      const zc = pyJson('zipcheck.py', [comic]);
      rec.disk = { size: fs.statSync(comic).size, sha: await sha256Stream(comic), isZip: zc.is_zip, testzip: zc.testzip, members: zc.members && Object.keys(zc.members), hasComicInfo: zc.members ? 'ComicInfo.xml' in zc.members : null, temporaryExists: fs.existsSync(temp), pending: h.pendingFiles(info).length,
        backups: bs.map(f => path.basename(f)), backupSha: bs[0] ? await sha256Stream(bs[0]) : null, backupHasComicInfo: bs[0] ? Boolean(h.comicInfoOf(bs[0])) : null };
      rec.history = (await h.sql(info, 'SELECT id FROM history WHERE path LIKE ?', '%' + name)).length;
      const kept = await h.backupsListing(E.run);
      rec.kept = kept.body && kept.body.items ? kept.body.items.filter(i => i.name === name).map(i => i.reason) : null;
      out.cases[behaviour] = rec;
      return rec;
    }
    const orig1 = out.fixture.files['Plain Approve 004 (2020).cbz'];
    // 1. change
    const A = await approveWith('Plain Approve 004 (2020).cbz', 9004, 'change');
    check('W1 (Approve): the app was waiting to rename when the other program changed the comic (the Approve unanswered after 2.5 s, its temporary archive on disk, the comic still its original size)', A.heldOk && A.waitingAt2500.answerPending && A.waitingAt2500.temporaryExists && A.waitingAt2500.comicSizeUnchanged, { afterAtMs: A.afterAtMs, waiting: A.waitingAt2500 });
    check('W1 (Approve): the other program changed the comic (a page added: new size) while holding it, then closed it', A.change && A.change.changed && A.change.size > A.change.before, A.change || {});
    check('W1 (Approve): the comic KEEPS the other program\'s change (still a readable zip, the added page present, new size, no ComicInfo from the Approve), no .metadata-tmp left', A.disk.isZip && A.disk.testzip === null && A.disk.members.includes('added-by-another-program.txt') && A.disk.size === A.change.size && A.disk.hasComicInfo === false && !A.disk.temporaryExists, { disk: A.disk });
    check('W1 (Approve): the Approve is refused (HTTP 400, verified false, the standard "The change was not verified..." text with the retained backup named), refused within 1.5 s of the other program\'s change (not after the 10 s wait), never a written success', A.answer && A.answer.http === 400 && A.answer.verified === false && /not verified/i.test(A.answer.error || '') && Boolean(A.answer.backup) && A.releasedAtMs !== undefined && A.answer.ms - A.releasedAtMs < 1500, { answer: A.answer, releasedAtMs: A.releasedAtMs });
    check('W1 (Approve): the BACKUP is kept (one copy, equal to the comic before the change); History has no row', A.disk.backups.length === 1 && A.disk.backupSha === orig1.sha256 && A.history === 0, { backups: A.disk.backups, backupEqualsOriginal: A.disk.backupSha === orig1.sha256, history: A.history, keptListing: A.kept });
    // 2. positive control: held, closed unchanged
    const B = await approveWith('Big Approve 001 (2020).cbz', 9001, 'release');
    check('W1 positive control: another program holds the comic for ~2.5 s and closes it unchanged: the Approve waited it out and succeeded (200, verified, ComicInfo written, backup removed, one History row)', B.waitingAt2500.answerPending && B.answer && B.answer.http === 200 && B.answer.verified === true && B.answer.backup_removed === true && B.disk.hasComicInfo === true && B.disk.backups.length === 0 && B.history === 1 && B.disk.testzip === null, { waiting: B.waitingAt2500, answer: B.answer, disk: { hasComicInfo: B.disk.hasComicInfo, backups: B.disk.backups }, history: B.history });
    // 3. item 9: held past the app's 10 s wait
    const C = await approveWith('Big Approve 002 (2020).cbz', 9002, 'throughout');
    const orig2 = out.fixture.files['Big Approve 002 (2020).cbz'];
    check('Item 9 (the app\'s final-rename hold): held throughout, the Approve waits about 10 s (9 to 20 s) and is then refused (HTTP 4xx/5xx, not a success) while the other program still holds the comic', C.heldOk && C.holderStillHoldingAtAnswer && C.answer && C.answer.http >= 400 && C.answer.ms >= 9000 && C.answer.ms <= 20000 && C.answer.verified !== true, { answer: C.answer, holderStillHoldingAtAnswer: C.holderStillHoldingAtAnswer });
    check('Item 9: the comic is byte-identical to the fixture (unchanged), no .metadata-tmp, the backup kept (equal to the original), no History row', C.disk.sha === orig2.sha256 && !C.disk.temporaryExists && C.disk.backups.length === 1 && C.disk.backupSha === orig2.sha256 && C.history === 0, { disk: { sha: C.disk.sha === orig2.sha256, temporaryExists: C.disk.temporaryExists, backups: C.disk.backups }, history: C.history, keptListing: C.kept });
    out.quit = await E.quitViaTray('w1 approve end', { staleClaimsOk: true });
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  };

  E.scenarios['w1-worker'] = async () => {
    await E.startup('w1w', E.fixtureState(1, false, false));
    const info = { tmp: E.run.tmp, root: E.run.root, state: E.run.state, locks: E.run.locks };
    const lib = path.win32.join(info.root, 'library');
    const NAME = 'Futaba QA Fixture 001 (2020).cbz';
    const comic = path.win32.join(lib, NAME), temp = comic + '.metadata-tmp';
    const origSha = out.fixture.hashes[NAME];
    const holder = startHolder('holdrw.py', comic);
    await holder.ready(); holder.send('hold');
    check('W1 (worker): another program has the matched fixture comic open read-write before the worker starts', await holder.held(), {});
    await E.run.qa('sampleStart(40)');
    const rec = {};
    try {
      await setupLibrary(E.run, lib);
      await waitFor(() => pendingWith(info, /Futaba QA Fixture 001/, 'after'), 'the worker\'s pending record with its after signature', 120000, 20);
      await sleep(2500);
      rec.waiting = { temporaryExists: fs.existsSync(temp), comicShaUnchanged: (await sha256Stream(comic)) === origSha, pending: h.pendingFiles(info).length };
      holder.send('change');
      await waitFor(() => /changed/.test(holder.text()), 'holder changed the comic', 15000, 20);
      rec.change = JSON.parse(holder.text().split('\n').find(l => l.startsWith('{"changed"')));
      holder.send('release');
      await waitFor(() => /released/.test(holder.text()), 'holder released', 15000, 20);
      // a 10 ms timeline for 8 s: the comic's size, its temporary archive, the pending record, the backups (only changes are kept)
      const tRel = Date.now(); let last = ''; rec.timeline = [];
      while (Date.now() - tRel < 8000) {
        const st = { size: sizeOf(comic), temp: fs.existsSync(temp), pending: h.pendingFiles(info).length, backups: bak(lib, NAME).length };
        const key = JSON.stringify(st);
        if (key !== last) { rec.timeline.push({ ms: Date.now() - tRel, ...st }); last = key; }
        await sleep(10);
      }
    } finally { await holder.end(); }
    out.workerTimeline = rec.timeline;
    check('W1 (worker): the worker was waiting to rename (temporary archive on disk, pending record, comic still the original) when the other program changed the comic and closed it', rec.waiting && rec.waiting.temporaryExists && rec.waiting.comicShaUnchanged && rec.change && rec.change.size > rec.change.before, { waiting: rec.waiting, change: rec.change });
    // the refusal: the first moment the temporary archive is gone after the release; the comic must be exactly the other program's version then
    const refusal = rec.timeline.find(s => !s.temp);
    out.workerRefusal = refusal || null;
    check('W1 (worker): the worker\'s rename was REFUSED: its temporary archive and pending record went away while the comic was still exactly the other program\'s version (size ' + (rec.change && rec.change.size) + ' bytes), not replaced by the worker\'s archive', Boolean(refusal) && refusal.size === rec.change.size && refusal.pending === 0 && refusal.backups === 1, { refusal, timeline: rec.timeline.slice(0, 8) });
    const zc = pyJson('zipcheck.py', [comic]);
    const bs = bak(lib, NAME);
    const log = h.engineLog(info).split(/\r?\n/).filter(l => /changed while|Original retained|ArchiveChanged|Comic changed/i.test(l)).slice(-8);
    const settled = { isZip: zc.is_zip, testzip: zc.testzip, members: zc.members && Object.keys(zc.members), hasAdded: zc.members ? 'added-by-another-program.txt' in zc.members : null, hasComicInfo: zc.members ? 'ComicInfo.xml' in zc.members : null, size: sizeOf(comic), temporaryExists: fs.existsSync(temp), pending: h.pendingFiles(info).length, backups: bs.map(f => path.basename(f)), backupEqualsOriginal: bs[0] ? (await sha256Stream(bs[0])) === origSha : null, log };
    out.workerSettled = settled;
    check('W1 (worker): the worker\'s BACKUP is kept (one copy, equal to the comic as it was before the change)', settled.backups.length === 1 && settled.backupEqualsOriginal === true, { backups: settled.backups, backupEqualsOriginal: settled.backupEqualsOriginal });
    check('W1 (worker): 8 s on, the other program\'s change is still in the comic (the added page present) and the file is a readable zip; any later write by the worker (it retries) was built from the changed comic', settled.isZip && settled.testzip === null && settled.hasAdded === true && !settled.temporaryExists, settled);
    const kept = await h.backupsListing(E.run);
    out.workerKept = kept.body && kept.body.items && kept.body.items.map(i => i.name + ':' + i.reason);
    out.workerKeptPanel = await h.keptPanelText(E.run);
    check('W1 (worker) observation: what Kept backups shows for the refused write\'s retained backup (listing reason and the real panel text)', true, { listing: out.workerKept, panel: out.workerKeptPanel && out.workerKeptPanel.reasons });
    out.workerHistory = (await h.sql(info, 'SELECT id FROM history')).length;
    out.workerCatalog = (await h.sql(info, 'SELECT status, size FROM comics WHERE path LIKE ?', '%' + NAME))[0];
    out.quit = await E.quitViaTray('w1 worker end', { staleClaimsOk: true });
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  };

  // One run of the merge tool over a small library where another program holds #2 open read-write, changes it, and closes it while the writer
  // waits to rename. engineDir: the engine the tool writes through (the packaged one, or the control's).
  async function w1MergeRun(tag, engineDir) {
    const p = await prepare(tag, 0);
    const outDir = path.win32.join(p.info.root, 'merge-out');
    const big = path.win32.join(p.lib, NAMES[1]);
    const holder = startHolder('holdrw.py', big);
    await holder.ready(); holder.send('hold');
    check(tag + ': another program has archive #2 open read-write before the tool starts', await holder.held(), {});
    const run = toolSpawn(applyArgs(p, outDir, [], engineDir), p.info);
    const rec = {};
    try {
      await waitFor(() => pendingWith(p.info, /Merge B/, 'after'), 'pending record of #2 with its after signature', 120000, 5);
      await sleep(2500);
      rec.waiting = { toolRunning: run.child.exitCode === null, temporaryExists: fs.existsSync(big + '.metadata-tmp'), noResultForB: !resultsOf(outDir).some(r => /Merge B/.test(r.path)), sizeUnchanged: fs.statSync(big).size === p.fx.files[NAMES[1]].size };
      holder.send('change');
      await waitFor(() => /changed/.test(holder.text()), 'holder changed the archive', 15000, 20);
      rec.change = JSON.parse(holder.text().split('\n').find(l => l.startsWith('{"changed"')));
      holder.send('release');
      await waitFor(() => /released/.test(holder.text()), 'holder released', 15000, 20);
      const ex = await Promise.race([run.exited, sleep(150000).then(() => null)]);
      rec.exit = ex && { code: ex.code, signal: ex.signal };
      rec.stdout = lastLines(run.out(), 10); rec.stderr = lastLines(run.err(), 6); rec.fullStdout = run.out();
    } finally { await holder.end(); try { process.kill(run.child.pid); } catch { } }
    const results = resultsOf(outDir);
    const resB = results.find(r => /Merge B/.test(r.path));
    const zc = pyJson('zipcheck.py', [big]);
    const bs = bak(p.lib, NAMES[1]);
    const orig = p.fx.files[NAMES[1]];
    const facts = { isZip: zc.is_zip, testzip: zc.testzip, members: zc.members && Object.keys(zc.members), size: fs.statSync(big).size, temporaryExists: fs.existsSync(big + '.metadata-tmp'), backups: bs.map(f => path.basename(f)), backupEqualsOriginal: bs[0] ? (await sha256Stream(bs[0])) === orig.sha256 : null, resB: resB && { outcome: resB.outcome, reason: resB.reason, backup_removed: resB.backup_removed, kept_as: resB.kept_as } };
    return { p, outDir, rec, results, resB, facts, summary: { ...rec, fullStdout: undefined, results: results.map(r => ({ archive: path.basename(r.path), outcome: r.outcome, backup_removed: r.backup_removed, kept_as: r.kept_as, reason: r.reason })) } };
  }

  E.scenarios['w1-merge'] = async () => {
    const R = await w1MergeRun('w1m', ENGINE);
    const { rec, results, resB, facts } = R;
    out.w1merge = R.summary; out.w1mergeDisk = facts;
    check('W1 (merge tool): the tool was waiting to rename #2 (running, temporary archive on disk, no result for #2, archive still its original size) when the other program changed it and closed it', rec.waiting && rec.waiting.toolRunning && rec.waiting.temporaryExists && rec.waiting.noResultForB && rec.waiting.sizeUnchanged && rec.change && rec.change.size > rec.change.before, rec);
    check('W1 (merge tool): the archive KEEPS the other program\'s change (readable zip, the added page present, the changed size, nested copy not merged away), no .metadata-tmp', facts.isZip && facts.testzip === null && facts.members.includes('added-by-another-program.txt') && facts.size === rec.change.size && facts.members.includes('Scans/ComicInfo.xml') && !facts.temporaryExists, facts);
    check('W1 (merge tool): the BACKUP is kept (one copy, equal to the archive before the change) and the tool did NOT report #2 as written with the backup removed', facts.backups.length === 1 && facts.backupEqualsOriginal === true && resB && !(resB.outcome === 'written' && resB.backup_removed === true) && resB.outcome !== 'written', facts);
    check('W1 (merge tool): the tool did not crash (exit 0) and reported honestly: #2 "skipped" ("Comic changed while preparing metadata. Original retained."), the others written, Done: {\'written\': 3, \'skipped\': 1}', rec.exit && rec.exit.code === 0 && resB && resB.outcome === 'skipped' && /Comic changed while preparing metadata\. Original retained\./.test(resB.reason || '') && /Done: \{'written': 3, 'skipped': 1\}/.test(rec.fullStdout), { exit: rec.exit, stdout: rec.stdout.slice(-4), outcomes: results.map(r => path.basename(r.path) + ':' + r.outcome) });
    const app = await keptViaApp(R.p, 'w1m');
    out.w1mergeKept = app;
    check('W1 (merge tool) observation: what Kept backups shows for the skipped archive\'s retained backup (listing reason and the real panel text); the app\'s start had nothing to recover', app.keptHttp === 200 && app.recoveryLines.length === 0, { listing: app.kept && app.kept.items && app.kept.items.map(i => i.name + ':' + i.reason), panel: app.panel && app.panel.reasons, recoveryLines: app.recoveryLines });
    out.pass = S.list.every(s => s.ok !== false);
  };

  // Negative control for W1: the same run with the engine of commit 4874894 (the rename wait WITHOUT the re-check, the state Senua found: tool 'written',
  // backup deleted, the other program's change lost). The test must see that bug in that engine, or it proves nothing about 67c7b53.
  E.scenarios['w1-merge-control'] = async () => {
    const dir = path.win32.join(BASE, 'work', 'engine-4874894');
    fs.mkdirSync(dir, { recursive: true });
    const names = spawnSync('git', ['-C', RC, 'ls-tree', '--name-only', '4874894fe36381ea095b5df35d83310537c74cbf'], { encoding: 'utf8' }).stdout.split('\n').filter(n => /^[^/]+\.py$/.test(n) || n === 'VERSION');
    const zip = path.win32.join(BASE, 'work', 'engine-4874894.zip');
    const arch = spawnSync('git', ['-C', RC, 'archive', '--format=zip', '-o', zip, '4874894fe36381ea095b5df35d83310537c74cbf', '--', ...names], { encoding: 'utf8' });
    const ext = spawnSync(SEVENZ, ['x', '-y', '-o' + dir, zip], { windowsHide: true, encoding: 'utf8', timeout: 60000 });
    const sig = spawnSync(PY, ['-B', '-I', '-c', 'import sys;print(open(sys.argv[1]).read().strip())', path.win32.join(dir, 'VERSION')], { encoding: 'utf8' }).stdout.trim();
    check('control engine: the source files of commit 4874894 (rename wait without the re-check) extracted from git (' + names.length + ' files, VERSION ' + sig + ')', arch.status === 0 && ext.status === 0 && names.length > 40 && fs.existsSync(path.win32.join(dir, 'storage.py')), { files: names.length, version: sig });
    const storage = fs.readFileSync(path.win32.join(dir, 'storage.py'), 'utf8');
    check('control engine: its storage.replace_durably has the rename wait but NO check parameter (the W1 state)', /def replace_durably\(source, destination\):/.test(storage) && /RENAME_HELD_WAIT/.test(storage), {});
    const R = await w1MergeRun('w1c', dir);
    const { rec, resB, facts } = R;
    out.w1control = R.summary; out.w1controlDisk = facts;
    check('W1 negative control: the old engine waited for the other program as well (tool still running, temporary archive on disk, 2.5 s in)', rec.waiting && rec.waiting.toolRunning && rec.waiting.temporaryExists && rec.change && rec.change.size > rec.change.before, rec);
    check('W1 negative control: with the old engine the other program\'s change is LOST (the page it added is gone from the archive) and the tool reports #2 "written" with its backup deleted - the bug the test is built to catch', facts.members && !facts.members.includes('added-by-another-program.txt') && resB && resB.outcome === 'written' && resB.backup_removed === true && facts.backups.length === 0, facts);
    out.pass = S.list.every(s => s.ok !== false);
  };

  // -------------------------------------------------------------------------------------------------------------------
  // Item 5 R3: a CB7 and a 7z named .cbz are converted by the app's own pass; the CBZ must be readable, the original gone, no staging folder left.
  // -------------------------------------------------------------------------------------------------------------------
  // The app's own flush wait (storage._open_handle, 10 s): another program opens the app's temporary archive the moment the app has closed it (holdwait.py
  // retries every ms until it can, FILE_SHARE_READ only), so the app's flush of it meets a sharing violation. (a) released after 4 s: the Approve waits and
  // succeeds; (b) held past 10 s: refused, comic unchanged, backup kept. Baseline: the same Approve with nobody holding.
  E.scenarios['app-flush-hold'] = async () => {
    await E.startup('aflush', approveState(12, 2, ['plain']));
    const info = { tmp: E.run.tmp, root: E.run.root, state: E.run.state, locks: E.run.locks };
    const lib = h.comicFolder(info);
    await E.run.qa('sampleStart(40)');
    await setupLibrary(E.run, lib);
    await E.readyEngine('aflush first start', 1);
    out.cases = {};
    async function approveWith(name, issue, behaviour) {
      const comic = path.win32.join(lib, name), temp = comic + '.metadata-tmp';
      const orig = out.fixture.files[name];
      const row = await h.comicId(E.run, name);
      let holder = null;
      if (!/^baseline/.test(behaviour)) { holder = startHolder('holdwait.py', temp); await holder.ready(); }
      const t0 = Date.now();
      let answer = 'pending';
      const approve = h.post(E.run, '/api/apply', { comic: row.id, issue }, 90000).then(r => { answer = { http: r.http, ms: Date.now() - t0, body: r.body }; return answer; }, e => { answer = 'connection ended: ' + (e && e.name); return answer; });
      const rec = { name, behaviour };
      try {
        if (holder) {
          await waitFor(() => /held|gave up/.test(holder.text()), 'the holder opened the temporary archive', 60000, 5);
          rec.holder = holder.text().split('\n').filter(l => /held|gave up/.test(l))[0];
          rec.heldAfterMs = Date.now() - t0;
          rec.landed = /^held/.test(rec.holder || '');
          if (behaviour === 'release') {
            await sleep(4000);
            rec.stillWaitingAt4s = answer === 'pending';
            await holder.end();
            rec.releasedAfterMs = Date.now() - t0;
          }
        }
        await Promise.race([approve, sleep(60000)]);
        if (behaviour === 'throughout') rec.holderStillHoldingAtAnswer = holder.alive() && !/released/.test(holder.text());
      } finally { if (holder) await holder.end(); }
      rec.answer = answer === 'pending' ? 'no answer' : typeof answer === 'string' ? answer : { http: answer.http, ms: answer.ms, verified: answer.body && answer.body.verified, error: answer.body && answer.body.error, backup_removed: answer.body && answer.body.backup_removed_after_verification, backup: answer.body && answer.body.backup && path.basename(answer.body.backup) };
      await sleep(500);
      const bs = bak(lib, name);
      const zc = pyJson('zipcheck.py', [comic]);
      rec.disk = { sha: await sha256Stream(comic), shaEqualsFixture: (await sha256Stream(comic)) === orig.sha256, isZip: zc.is_zip, testzip: zc.testzip, hasComicInfo: zc.members ? 'ComicInfo.xml' in zc.members : null, temporaryExists: fs.existsSync(temp), pending: h.pendingFiles(info).length,
        backups: bs.map(f => path.basename(f)), backupEqualsFixture: bs[0] ? (await sha256Stream(bs[0])) === orig.sha256 : null };
      rec.history = (await h.sql(info, 'SELECT id FROM history WHERE path LIKE ?', '%' + name)).length;
      const kept = await h.backupsListing(E.run);
      rec.kept = kept.body && kept.body.items ? kept.body.items.filter(i => i.name === name).map(i => i.reason) : null;
      out.cases[behaviour] = rec;
      return rec;
    }
    const B = await approveWith('Plain Approve 004 (2020).cbz', 9004, 'baseline');
    check('app flush wait, baseline: with nobody holding, the Approve answers at once (200, verified, ComicInfo written, backup removed) in under 3 s', B.answer && B.answer.http === 200 && B.answer.verified === true && B.answer.backup_removed === true && B.answer.ms < 3000 && B.disk.hasComicInfo === true && B.disk.backups.length === 0, { answer: B.answer, disk: B.disk });
    const R = await approveWith('Big Approve 001 (2020).cbz', 9001, 'release');
    check('app flush wait (a): another program opened the app\'s temporary archive (FILE_SHARE_READ only) the moment it was closed, and the Approve was still waiting 4 s later', R.landed && R.stillWaitingAt4s, { holder: R.holder, heldAfterMs: R.heldAfterMs });
    check('app flush wait (a): released after 4 s, the Approve succeeded (200, verified, ComicInfo written, backup removed, one History row, no temporary archive left), having waited (answer after 4 s)', R.answer && R.answer.http === 200 && R.answer.verified === true && R.answer.backup_removed === true && R.answer.ms >= 4000 && R.answer.ms < 10000 && R.disk.hasComicInfo === true && R.disk.testzip === null && R.disk.backups.length === 0 && R.history === 1 && !R.disk.temporaryExists, { answer: R.answer, disk: R.disk, history: R.history });
    const T = await approveWith('Big Approve 002 (2020).cbz', 9002, 'throughout');
    check('app flush wait (b): held throughout: the holder got in and was still holding when the app gave up; the app waited about 10 s (9 to 20 s) and refused (HTTP 400, verified false), never a success', T.landed && T.holderStillHoldingAtAnswer && T.answer && T.answer.http === 400 && T.answer.verified === false && T.answer.ms >= 9000 && T.answer.ms <= 20000, { holder: T.holder, answer: T.answer, holderStillHoldingAtAnswer: T.holderStillHoldingAtAnswer });
    check('app flush wait (b): the comic is byte-identical to the fixture, the backup is kept (equal to it), no History row, Kept backups lists it', T.disk.shaEqualsFixture && T.disk.backups.length === 1 && T.disk.backupEqualsFixture === true && T.history === 0, { disk: T.disk, history: T.history, kept: T.kept });
    out.observation = { temporaryLeftAfterRefusedHold: T.disk.temporaryExists, pendingAfterRefusedHold: T.disk.pending };
    check('app flush wait (b) observation: what is left of the held temporary archive and the pending record after the refusal (recorded, not asserted)', true, out.observation);
    // the leftover (if any): does it get in the way? A new Approve of the same comic with nobody holding anything.
    const T2 = await approveWith('Big Approve 002 (2020).cbz', 9002, 'baseline-again');
    out.afterRefusedHold = { leftoverTemporaryBeforeRetry: out.observation.temporaryLeftAfterRefusedHold, retry: T2.answer, retryDisk: { hasComicInfo: T2.disk.hasComicInfo, temporaryExists: T2.disk.temporaryExists, backups: T2.disk.backups, testzip: T2.disk.testzip }, retryHistory: T2.history };
    check('app flush wait (b) follow-up (observation + safety): a new Approve of that comic with nobody holding anything is answered at once (HTTP 400 "A temporary file already exists; inspect it before proceeding." while the leftover is there); the comic stays byte-identical to the fixture, nothing is written, no History row, the one backup kept', Boolean(T2.answer) && T2.answer.http !== undefined && T2.answer.verified !== true && T2.disk.backups.length >= 1 && T2.history === 0, out.afterRefusedHold);
    const tempFile = path.win32.join(lib, 'Big Approve 002 (2020).cbz.metadata-tmp');
    // does a restart clear the leftover? (the next start recovers only what a pending-write record names)
    out.quit = await E.quitViaTray('app flush hold, before restart', { staleClaimsOk: true });
    await h.relaunch('aflush2', info);
    await E.readyEngine('aflush second start', 1);
    out.restart = { temporaryExistsAfterRestart: fs.existsSync(tempFile), recoveryLines: h.recoveryLines(info), pending: h.pendingFiles(info).length };
    const row3 = await h.comicId(E.run, 'Big Approve 002 (2020).cbz');
    const again = await h.post(E.run, '/api/apply', { comic: row3.id, issue: 9002 }, 60000);
    out.restart.approveAfterRestart = { http: again.http, verified: again.body && again.body.verified, error: again.body && again.body.error };
    out.restart.temporaryExistsAfterApprove = fs.existsSync(tempFile);
    check('app flush wait (b) observation: after an app restart, is the leftover temporary archive still there, and can the comic be approved? (recorded, not asserted)', true, out.restart);
    out.quit2 = await E.quitViaTray('app flush hold end', { staleClaimsOk: true });
    out.pass = out.quit2.exit && out.quit2.exit.code === 0 && S.list.every(s => s.ok !== false);
  };

  E.scenarios['r3-convert'] = async () => {
    await E.startup('r3', async info => {
      const lib = E.emptyLibrary(info);
      const done = h.pyRun([H + '/fixture_r3.py', info.root, lib], { ...process.env, QA_7Z: win(SEVENZ), PYTHONDONTWRITEBYTECODE: '1' }, 120000);
      if (done.status !== 0) throw new Error('r3 fixture failed: ' + done.stderr + done.stdout);
      out.fixture = JSON.parse(done.stdout.trim().split('\n').slice(-1)[0]);
    });
    const info = { tmp: E.run.tmp, root: E.run.root, state: E.run.state, locks: E.run.locks };
    const lib = path.win32.join(info.root, 'library');
    const CB7 = 'Conversion Seven 001 (2020).cb7', CB7_TO = 'Conversion Seven 001 (2020).cbz', SAME = 'Conversion SameName 002 (2020).cbz', CTRL = 'Conversion Control 003 (2020).cbz';
    check('R3 fixture: a CB7 (7-Zip archive named .cb7) and a 7-Zip archive named .cbz (not a zip), plus an ordinary zip control; the originals are real 7z files', out.fixture.files[CB7].is_zip === false && out.fixture.files[SAME].is_zip === false && out.fixture.files[CTRL].is_zip === true, { is_zip: Object.fromEntries(Object.entries(out.fixture.files).map(([k, v]) => [k, v.is_zip])) });
    await E.run.qa('sampleStart(40)');
    await setupLibrary(E.run, lib);
    const t0 = Date.now();
    const converted = await waitFor(() => { const zc = fs.existsSync(path.win32.join(lib, SAME)) ? pyJson('zipcheck.py', [path.win32.join(lib, SAME)]) : { is_zip: false }; return !fs.existsSync(path.win32.join(lib, CB7)) && fs.existsSync(path.win32.join(lib, CB7_TO)) && zc.is_zip ? { ms: Date.now() - t0 } : false; }, 'both archives converted', 180000, 500);
    out.convertedAfterMs = converted.ms;
    await E.readyEngine('r3 after conversion', 1);
    await sleep(4000);
    const list = fs.readdirSync(lib);
    out.libraryAfter = list;
    for (const [orig, target] of [[CB7, CB7_TO], [SAME, SAME]]) {
      const file = path.win32.join(lib, target);
      const zc = pyJson('zipcheck.py', [file]);
      const want = out.fixture.files[orig].pages;
      const equal = zc.members && Object.keys(want).length === Object.keys(zc.members).length && Object.entries(want).every(([n, hv]) => zc.members[n] === hv);
      out['cbz-' + target] = { is_zip: zc.is_zip, testzip: zc.testzip, members: zc.members && Object.keys(zc.members), pagesEqualSource: equal };
      check('R3: ' + orig + ' -> ' + target + ': the CBZ is a readable zip (testzip passes) and its three pages are byte-identical to the source pages', zc.is_zip && zc.testzip === null && equal, out['cbz-' + target]);
    }
    check('R3: the CB7 original is gone (no .cb7), and no retained original (.conversion-original) or temporary file is left', !list.includes(CB7) && !list.some(n => /\.conversion-original$/.test(n)) && !list.some(n => /\.metadata-tmp$/.test(n)), { list });
    check('R3: the 7z named .cbz was replaced by the CBZ (its bytes are no longer the 7z original: different SHA-256) and no .7z-signature file is left in the library', (await sha256Stream(path.win32.join(lib, SAME))) !== out.fixture.files[SAME].sha256, {});
    check('R3: no staging folder (.comic-metadata-convert-*) is left in the library, and no leftover folder at all', !list.some(n => /^\.comic-metadata-convert-/.test(n)), { list });
    check('R3: the ordinary zip control is untouched (same SHA-256)', (await sha256Stream(path.win32.join(lib, CTRL))) === out.fixture.files[CTRL].sha256, {});
    const stag = await h.sql(info, "SELECT name FROM sqlite_master WHERE name='conversion_staging'");
    const staging = stag.length ? await h.sql(info, 'SELECT COUNT(*) n FROM conversion_staging') : [{ n: 0 }];
    const conv = await h.sql(info, 'SELECT path, result FROM conversions');
    out.conversions = conv.map(c => ({ path: path.basename(c.path), result: (() => { try { const r = JSON.parse(c.result); return { files_verified: r.files_verified, original_removed: r.original_removed, error: r.error }; } catch { return c.result; } })() }));
    check('R3: the app\'s record agrees: no staging row left, both conversions recorded with original_removed true and no error', staging[0].n === 0 && out.conversions.length === 2 && out.conversions.every(c => c.result && c.result.original_removed === true && !c.result.error), { stagingRows: staging[0].n, conversions: out.conversions });
    out.quit = await E.quitViaTray('r3 end', { staleClaimsOk: true });
    const listEnd = fs.readdirSync(lib);
    out.libraryAtEnd = listEnd;
    check('R3: after the app quit, the library is exactly the two CBZs and the control (nothing else)', listEnd.slice().sort().join('|') === [CB7_TO, SAME, CTRL].sort().join('|'), { listEnd });
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  };

  // -------------------------------------------------------------------------------------------------------------------
  // Item 7 r7: a torn tail INSIDE a quoted multi-line Summary of dropped-nested-values.csv, then --resume.
  // With the 0.6.8 tool as the negative control (it cut at the last line break, which was the one inside the quotes).
  // -------------------------------------------------------------------------------------------------------------------
  async function r7Case(tag, tool, label) {
    const bigMb = Number(process.env.QA_MERGE_MB || 120);
    const p = await prepare(tag, bigMb, 'r7', tool);
    const outDir = path.win32.join(p.info.root, 'merge-out');
    const cut = await interruptMid(p, outDir, tool);
    out[label + 'Interrupted'] = cut;
    const csvFile = path.win32.join(outDir, 'dropped-nested-values.csv');
    const before = fs.readFileSync(csvFile);
    const rowsBefore = pyJson('csvdump.py', [csvFile]);
    check(tag + ' (' + label + '): the tool was ended while #2 was being written; the CSV already holds #1\'s complete rows (header + Summary + Year), the Summary value spanning three lines', cut.killed && cut.pending === 1 && Array.isArray(rowsBefore) && rowsBefore.length === 3 && rowsBefore[1][2] === 'Summary' && rowsBefore[1][3].split('\n').length === 3 && before[before.length - 1] === 10, { cut: { killed: cut.killed, pending: cut.pending, results: cut.results }, rows: Array.isArray(rowsBefore) ? rowsBefore.length : rowsBefore, summaryLines: Array.isArray(rowsBefore) && rowsBefore[1] ? rowsBefore[1][3].split('\n').length : null });
    const tail = Buffer.from('"' + p.plan.entries[1].path + '","Scans/ComicInfo.xml",Summary,"Nested line one 2, with a comma.\nLine two says ""quoted wo', 'utf8');
    fs.appendFileSync(csvFile, tail);
    const tornFile = csvFile + '.torn';
    check(tag + ' (' + label + '): a torn tail appended: the row for #2 cut off INSIDE its quoted Summary, after one inner line break (' + tail.length + ' bytes, no closing quote, no final newline); no .torn file yet', fs.readFileSync(csvFile).length === before.length + tail.length && !fs.existsSync(tornFile) && tail.includes(10) && tail[tail.length - 1] !== 10, { tailBytes: tail.length });
    const resumed = toolSync(applyArgs(p, outDir, ['--resume']), p.info, 300000, tool);
    const torn = fs.existsSync(tornFile) ? fs.readFileSync(tornFile) : null;
    const rows = pyJson('csvdump.py', [csvFile]);
    const csvNow = fs.readFileSync(csvFile);
    const expected = [];
    for (let n = 1; n <= 4; n++) {
      const a = p.plan.entries[n - 1].path;
      expected.push([a, 'Scans/ComicInfo.xml', 'Summary', 'Nested line one ' + n + ', with a comma.\nLine two says "quoted words" and, more commas.\nLine three ' + n + ' ends here.', 'Root summary ' + n + '.', 'root wins']);
      expected.push([a, 'Scans/ComicInfo.xml', 'Year', '2019', '', 'nested date never copied']);
    }
    const good = Array.isArray(rows) && rows.length === 9 && rows[0].join('|') === 'archive|nested entry|field|nested value|root value kept|why'
      && expected.every(e => rows.slice(1).some(r => r.length === 6 && r.every((v, i) => v === e[i]))) && rows.slice(1).every(r => r.length === 6);
    return { p, outDir, cut, tail, torn, resumed, rows, good, csvNow, results: resultsOf(outDir) };
  }

  E.scenarios['r7-csv'] = async () => {
    const R = await r7Case('r7n', TOOL, 'new');
    out.newTool = { resume: { code: R.resumed.code, stdout: lastLines(R.resumed.stdout, 5), stderr: lastLines(R.resumed.stderr, 5) }, tornBytes: R.torn && R.torn.length, rows: Array.isArray(R.rows) ? R.rows.length : R.rows, results: R.results.map(r => path.basename(r.path) + ':' + r.outcome) };
    check('r7: --resume (0.6.9 tool) exits 0, says the CSV ended with a torn line (' + R.tail.length + ' bytes) moved to dropped-nested-values.csv.torn, and the run finishes (written 4)', R.resumed.code === 0 && new RegExp('dropped-nested-values\\.csv ended with a torn line \\(' + R.tail.length + ' bytes\\): moved to dropped-nested-values\\.csv\\.torn').test(R.resumed.stderr) && /Done: \{'written': 4\}/.test(R.resumed.stdout), out.newTool.resume);
    check('r7: the torn row went to dropped-nested-values.csv.torn: the .torn file holds exactly the torn bytes (byte for byte)', R.torn && Buffer.compare(R.torn, R.tail) === 0, { tornBytes: R.torn && R.torn.length, tailBytes: R.tail.length });
    check('r7: EVERY row reads back: the CSV read as any reader would (csv module) has the header + 8 rows (Summary and Year for all four archives), 6 columns each, each Summary value (three lines, a comma, quotes) and root value exactly as in the archives; the torn row is not in it', R.good, { rows: Array.isArray(R.rows) ? R.rows.length : R.rows, sample: Array.isArray(R.rows) && R.rows[1] ? R.rows[1] : null, last: Array.isArray(R.rows) ? R.rows.slice(-1)[0] : null });
    check('r7: all four archives merged and written (results: 4 written), no backup left', R.results.length === 4 && R.results.every(r => r.outcome === 'written') && NAMES.every(n => bak(R.p.lib, n).length === 0), { outcomes: R.results.map(r => r.outcome) });
    // negative control: the 0.6.8 tool on the same kind of file must fail the same test (otherwise the test proves nothing)
    const prevDir = path.win32.join(BASE, 'work', 'tool-068');
    fs.mkdirSync(prevDir, { recursive: true });
    const prevFile = path.win32.join(prevDir, 'nested_comicinfo_merge.py');
    const shown = spawnSync('git', ['-C', RC, 'show', PREV_COMMIT + ':tools/nested_comicinfo_merge.py'], { maxBuffer: 20e6 });
    fs.writeFileSync(prevFile, shown.stdout);
    out.prevToolSha256 = crypto.createHash('sha256').update(shown.stdout).digest('hex');
    const C = await r7Case('r7o', prevFile, 'old');
    out.oldTool = { resume: { code: C.resumed.code, stdout: lastLines(C.resumed.stdout, 5), stderr: lastLines(C.resumed.stderr, 5) }, tornBytes: C.torn && C.torn.length, rows: Array.isArray(C.rows) ? C.rows.length : C.rows, good: C.good, results: C.results.map(r => path.basename(r.path) + ':' + r.outcome) };
    check('r7 negative control (the 0.6.8 tool, git ' + PREV_COMMIT.slice(0, 7) + ', same engine): on the same torn file its --resume does NOT give a CSV that reads back (a row swallowed into the open quote) - the test discriminates', C.good === false, out.oldTool);
    out.pass = S.list.every(s => s.ok !== false);
  };
}
