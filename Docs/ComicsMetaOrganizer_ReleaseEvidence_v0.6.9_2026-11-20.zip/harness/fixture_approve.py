"""Futaba 0.6.8 QA fixture for the Approve / recovery scenarios (packaged python, -B -I). Touches only the QA root named on the
command line. Builds a library of large and small cbz comics (no ComicInfo at all, so Approve writes one), makes one read-only,
and seeds the QA state's provider cache so the engine's own /api/apply works offline (the engine in private QA mode answers
from its cache only; nothing is stubbed in the app).
Usage: fixture_approve.py <qa root> <library> <big_mb> <big_count> [readonly] [plain]
"""
import hashlib
import json
import os
import stat
import sys
import time
import zipfile
from pathlib import Path

root, library = Path(sys.argv[1]), Path(sys.argv[2])
big_mb, big_count = int(sys.argv[3]), int(sys.argv[4])
extras = sys.argv[5:]
state = root / 'state'
if Path(os.environ.get('COMICS_META_STATE_ROOT', '')) != state or not root.name.startswith('illuminati-cmo-qa-'):
    raise SystemExit('Refusing: COMICS_META_STATE_ROOT must equal the QA root state folder')
import app

library.mkdir(parents=True, exist_ok=True)
CHUNK = 12 * 1024 * 1024


def big(path, megabytes):
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=1) as archive:
        for index in range(max(1, megabytes // 12)):
            archive.writestr('page%03d.bin' % index, os.urandom(CHUNK))


def small(path):
    with zipfile.ZipFile(path, 'x') as archive:
        archive.writestr('page001.bin', os.urandom(4096))


names = []
for number in range(1, big_count + 1):
    name = 'Big Approve %03d (2020).cbz' % number
    big(library / name, big_mb)
    names.append(name)
if 'readonly' in extras:
    name = 'ReadOnly Approve 003 (2020).cbz'
    small(library / name)
    os.chmod(library / name, stat.S_IREAD)
    names.append(name)
if 'plain' in extras:
    name = 'Plain Approve 004 (2020).cbz'
    small(library / name)
    names.append(name)

with app.db() as con:
    for index in range(1, 9):
        issue = {'id': 9000 + index, 'name': 'QA Approve Issue %d' % index, 'issue_number': str(index),
                 'volume': {'id': 7001, 'name': 'QA Approve Series'}, 'cover_date': '2020-03-01',
                 'site_detail_url': 'https://comicvine.gamespot.com/qa-approve/4000-%d/' % (9000 + index),
                 'description': '<p>QA approve summary %d.</p>' % index,
                 'person_credits': [{'name': 'QA Writer', 'role': 'writer'}]}
        con.execute('INSERT OR REPLACE INTO cache VALUES(?,?,?)',
                    ('issue/4000-%d?format=json' % (9000 + index), json.dumps(issue), time.time()))
    con.execute('INSERT OR REPLACE INTO cache VALUES(?,?,?)',
                ('volume/4050-7001?field_list=publisher&format=json', json.dumps({'publisher': {'name': 'QA Approve Publisher'}}), time.time()))

hashes = {}
for name in names:
    data = (library / name).read_bytes()
    hashes[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data)}
print(json.dumps({'prepared': True, 'library': str(library), 'files': hashes}))
