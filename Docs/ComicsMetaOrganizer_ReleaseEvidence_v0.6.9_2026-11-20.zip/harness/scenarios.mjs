// Futaba 0.6.7 QA scenarios. Usage: node scenarios.mjs <scenario> <out.json>
// Run under the studio's owned-process supervisor (a private kill-on-close Job); every process started here is its child.
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import { spawn, spawnSync } from 'node:child_process';
import { launch, makeRoot, setupLibrary, waitFor, sleep, win, steps, PY, SEVENZ, BASE, pidAlive, portFree, portRefused, runInfoForEvidence, EXTRACT, LATEST_YML } from './lib.mjs';
import crypto from 'node:crypto';
import { register } from './new068.mjs';
import { registerDelta } from './delta069.mjs';
import { c7Checks } from './c7_068.mjs';

const [scenario, outFile] = process.argv.slice(2);
const S = steps();
const out = { schema: 1, scenario, started: new Date().toISOString(), pass: false, steps: S.list };
let run = null;
const CONFIG = { sources: { disabled: ['ComicVine', 'Metron', 'Google Lens', 'Google Books', 'GCD', 'Dark Horse', 'Open Library local index', 'General free web', 'Wikipedia/wiki', 'Saved lead re-checks', 'GetComics', 'PREVIEWSworld', 'Publisher web'], enabled: [] },
  in_book: { cover: false, publisher_agreement: false, credits_pages: false }, browser_search: { enabled: false, lens: false } };
const emptyLibrary = info => { const lib = path.win32.join(info.root, 'library'); fs.mkdirSync(lib, { recursive: true }); fs.writeFileSync(path.win32.join(info.state, 'config.json'), JSON.stringify(CONFIG)); return lib; };
const must = (ok, what, extra) => { if (!ok) { S.record('FAIL ' + what, { ok: false, ...(extra || {}) }); throw new Error('Check failed: ' + what); } };
const check = (name, ok, data) => S.record(name, { ok: Boolean(ok), ...(data || {}) });

async function startup(label, writeState, opts = {}) {
  run = await launch(label, { writeState, existing: opts.existing, policyExtra: opts.policyExtra });
  out.run = runInfoForEvidence(run);
  const expected = await run.qa('expected()');
  out.expectedTray = expected;
  check('observer bound to the exact app', run.identity.version === '0.6.9' && run.identity.packaged === true, { identity: out.run.identity, temp: run.identity.temp, local: run.identity.local });
  return run;
}

async function windowsClean(tag) {
  const windows = await run.qa('windows()');
  const violations = await run.qa('violations');
  check(tag + ': windows invisible, unfocused, offscreen; guards clear', windows.length >= 1 && windows.every(w => w.visible === false && w.focused === false && w.offscreen === true) && violations.length === 0, { windows: windows.map(w => ({ url: (w.url || '').split('/').slice(-1)[0] || w.url, visible: w.visible, focused: w.focused, offscreen: w.offscreen })), violations });
  return windows;
}

async function engineOwned(tag) {
  const s = await run.shellStatus();
  const engines = await run.engines();
  check(tag + ': private authenticated engine status owned', s.http === 200 && s.body.owned === true && s.body.version === '0.6.9', { http: s.http, owned: s.body.owned, version: s.body.version, brokerPid: engines.slice(-1)[0]?.pid, setup: s.body.setup });
  return s;
}

// Tray Quit exactly as in the 0.6.4/0.6.5 passes: the real enabled menu callback, inspector closed first.
async function quitViaTray(tag, { delay = 300, timeout = 90000, staleClaimsOk = false } = {}) {
  const engines = await run.engines();
  const claimsBefore = run.claims();
  const pids = new Set(engines.map(e => e.pid));
  for (const name of claimsBefore) { const m = /-(\d+)-[0-9a-f]{12}\./.exec(name); if (m) pids.add(Number(m[1])); }
  await run.qa("clickLater('&Quit'," + delay + ')');
  run.detach();
  const exit = await Promise.race([run.exited, sleep(timeout).then(() => null)]);
  const events = run.readEvents();
  const click = events.filter(e => e.kind === 'tray-click' && e.label === '&Quit').pop();
  const result = { exit: exit && { code: exit.code, signal: exit.signal }, quitToExitMs: exit && click ? exit.t - click.t : null, timedOut: exit === null };
  if (exit === null) { S.record(tag + ': app did not exit', { ok: false, ...result }); return result; }
  await sleep(3000);
  result.enginePortRefused = await portRefused(run.ports.engine);
  result.claimsAfter = run.claims();
  result.claimPidsAlive = result.claimsAfter.map(n => /-(\d+)-[0-9a-f]{12}\./.exec(n)).filter(Boolean).map(m => Number(m[1])).filter(pidAlive);
  result.recordedPidsAliveAt3s = [...pids].filter(pidAlive);
  await sleep(9000);
  result.recordedPidsAliveAt12s = [...pids].filter(pidAlive);
  result.pidsChecked = pids.size;
  check(tag + ': tray Quit exits 0, nothing left', exit.code === 0 && result.enginePortRefused && (staleClaimsOk ? result.claimPidsAlive.length === 0 : result.claimsAfter.length === 0) && result.recordedPidsAliveAt12s.length === 0, result);
  return result;
}

function trayStateOf(rec, expected) {
  for (const [name, e] of Object.entries(expected)) if (e.bm1 === rec.bm1 && e.bm05 === rec.bm05) return name;
  return 'unknown';
}

async function killBroker(index = -1) {
  const engines = await run.engines();
  const target = engines.slice(index)[0];
  const t = Date.now();
  process.kill(target.pid); // TerminateProcess: the broker's own exit code is 1, as an outside kill gives
  const rec = await waitFor(async () => { const e = (await run.engines()).find(x => x.pid === target.pid); return e && e.exit && e; }, 'broker exit recorded', 15000, 100);
  return { pid: target.pid, exitCode: rec.exit.code, signal: rec.exit.signal, afterMs: Date.now() - t };
}

async function readyEngine(tag, minEngines) {
  return waitFor(async () => {
    const engines = await run.engines();
    if (engines.length < minEngines || engines.slice(-1)[0].exit) return false;
    const s = await run.qa('state()', true);
    if (s.service !== 'ready') return false;
    const st = await run.shellStatus().catch(() => null);
    return st && st.http === 200 && st.body.owned === true ? { pid: engines.slice(-1)[0].pid, state: s.service } : false;
  }, tag + ': engine ready', 60000, 300);
}

const fixtureState = (count, cb7, nested) => async info => {
  const lib = path.win32.join(info.root, 'library');
  const done = spawnSync(PY, ['-B', BASE + '/evidence/harness/fixture.py', info.root, lib, String(count), ...(cb7 ? ['cb7'] : []), ...(nested ? ['nested'] : [])], { env: { ...process.env, COMICS_META_STATE_ROOT: info.state, QA_7Z: win(SEVENZ) }, windowsHide: true, encoding: 'utf8', timeout: 180000 });
  if (done.status !== 0) throw new Error('fixture failed: ' + done.stderr + done.stdout);
  out.fixture = JSON.parse(done.stdout.trim().split('\n').slice(-1)[0]);
};

const GUARDS_INTENDED = 28; // observer.cjs: 8 window + app.focus + webContents.focus + Notification + 7 dialog + 3 shell + spawn(other) + 6 child_process


// ---------------------------------------------------------------------------------------------------------------------
// 0.6.7 helpers
// ---------------------------------------------------------------------------------------------------------------------
const RC = 'I:/AI Projects/Worktrees/Comics Meta Organizer/rc-069';
const HOLD = RC + '/tests/debug_hold.py';
const PAUSING = 'Pausing \u2014 finishing the current operation. Progress is saved.';
const ENDING = 'Stopping the local service\u2026';

// A helper under the packaged python (-B -I). It is a child of this scenario, so the supervisor's Job closes it.
function spawnPy(args) {
  const child = spawn(PY, ['-B', '-I', ...args], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
  let stdout = '', stderr = '';
  child.stdout.on('data', d => { stdout += d; }); child.stderr.on('data', d => { stderr += d; });
  const exited = new Promise(resolve => child.once('exit', (code, signal) => resolve({ code, signal, t: Date.now() })));
  return { child, out: () => stdout, err: () => stderr, exited };
}

// tests/debug_hold.py attached to `pid`; optionally writes the leftover record naming it. release() closes its stdin.
async function hold(pid, { mode = 'exit', seconds = 3000, locks = null, age = null } = {}) {
  const args = [HOLD, '--pid', String(pid), '--mode', mode, '--seconds', String(seconds)];
  if (locks) args.push('--write-record', locks);
  if (age !== null) args.push('--age', String(age));
  const h = spawnPy(args);
  try { await waitFor(() => /held \d+/.test(h.out()) && (!locks || /record /.test(h.out())), 'debug_hold attached', 20000, 100); }
  catch (e) { throw new Error(e.message + ' stdout=' + h.out().slice(-300) + ' stderr=' + h.err().slice(-500)); }
  h.record = ((/record (.+)/.exec(h.out()) || [])[1] || '').trim() || null;
  h.release = async () => { try { h.child.stdin.end(); } catch { } return Promise.race([h.exited, sleep(20000).then(() => null)]); };
  h.args = args.slice(1);
  return h;
}

// One Quit, measured from the recorded click to the recorded process exit. `how`: tray | menu | button (the page's Quit).
async function quitFlow(tag, how, { delay = 300, timeout = 30000 } = {}) {
  const pids = new Set((await run.engines()).map(e => e.pid));
  for (const name of run.claims()) { const m = /-(\d+)-[0-9a-f]{12}\./.exec(name); if (m) pids.add(Number(m[1])); }
  if (how === 'tray') await run.qa("clickLater('&Quit'," + delay + ')');
  else if (how === 'menu') await run.qa("menuClickLater('&Exit'," + delay + ')');
  else await run.qa("pageClickLater('quit'," + delay + ')');
  run.detach();
  const exit = await Promise.race([run.exited, sleep(timeout).then(() => null)]);
  const events = run.readEvents();
  const click = events.filter(e => ['tray-click', 'page-click', 'menu-click'].includes(e.kind)).pop();
  const res = { tag, how, clickFound: !click ? false : click.found !== false, exit: exit && { code: exit.code, signal: exit.signal }, clickToExitMs: exit && click ? exit.t - click.t : null, timedOut: exit === null };
  if (exit) { await sleep(1500); res.enginePortRefused = await portRefused(run.ports.engine); res.pidsAliveAfter = [...pids].filter(pidAlive); res.locksAfter = fs.readdirSync(run.locks); }
  res.violations = events.filter(e => e.kind === 'violation').length;
  run.cleanup();
  return res;
}

// ---- the frozen-broker quit (item 1) ----
async function frozenQuit({ origin, waitSeconds, holdSeconds: holdOverride }) {
  const wait = waitSeconds || 30;
  await startup('frz' + wait, async info => { emptyLibrary(info); }, { policyExtra: waitSeconds ? { closureWaitSeconds: waitSeconds } : {} });
  check('QA policy closureWaitSeconds as intended', waitSeconds ? run.pol.policy.closureWaitSeconds === waitSeconds : run.pol.policy.closureWaitSeconds === undefined, { closureWaitSeconds: run.pol.policy.closureWaitSeconds === undefined ? '(not set: the app default)' : run.pol.policy.closureWaitSeconds });
  await run.qa('sampleStart(40)');
  await setupLibrary(run, path.win32.join(run.root, 'library'));
  await readyEngine('before the freeze', 1);
  const broker = (await run.engines()).slice(-1)[0].pid;
  const token = await run.token();
  const ask = () => fetch('http://127.0.0.1:' + run.ports.engine + '/api/shell/status', { headers: { 'X-ComicsMeta-Shell': token }, signal: AbortSignal.timeout(1200) }).then(r => r.status);
  const before = await ask();
  // The hold must outlast the shell's own wait (closing stage <= wait, then ending <= wait + 1) or the thaw would end it for the shell.
  const holdSeconds = holdOverride || (2 * wait + 40);
  const h = await hold(broker, { mode: 'freeze', seconds: holdSeconds });
  const tHold = Date.now();
  const after = await ask().then(s => s, e => 'no answer (' + (e && e.name) + ')');
  // The status endpoint is served by the broker's CHILD server process, so it keeps answering while the broker is frozen: it is not a freeze probe.
  const tree = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "(Get-CimInstance Win32_Process -Filter 'ParentProcessId=" + broker + "' | Select-Object -ExpandProperty ProcessId) -join ','"], { encoding: 'utf8', windowsHide: true, timeout: 20000 });
  out.brokerChildren = (tree.stdout || '').trim();
  check('broker held with tests/debug_hold.py --mode freeze (debugger attached, hold of ' + holdSeconds + ' s); the status endpoint still answers because the engine server is a child process of the broker', before === 200 && after === 200, { brokerPid: broker, brokerChildPids: out.brokerChildren, statusBefore: before, statusAfter: after, holdArgs: h.args });
  const pids = new Set([broker]);
  for (const name of run.claims()) { const m = /-(\d+)-[0-9a-f]{12}\./.exec(name); if (m) pids.add(Number(m[1])); }
  await run.qa('armEndingProbes(3000)');
  if (origin === 'tray') await run.qa("clickLater('&Quit',300)"); else await run.qa("menuClickLater('&Exit',300)");
  run.detach();
  const exit = await Promise.race([run.exited, sleep((2 * wait + 90) * 1000).then(() => null)]);
  const ev = run.readEvents();
  const click = ev.filter(e => ['tray-click', 'menu-click'].includes(e.kind)).pop();
  const rel = t => (t === undefined || t === null || !click) ? null : t - click.t;
  const dlg = ev.filter(e => e.kind === 'sample' && e.snap && e.snap.file === 'stopping.html');
  const loaded = ev.find(e => e.kind === 'load' && /stopping\.html/.test(e.url || '') && click && e.t >= click.t);
  const first = dlg[0];
  const ending = dlg.find(s => s.snap.status && s.snap.status.text === ENDING);
  const late = dlg.find(s => s.snap.detail && /recovery backup/.test(s.snap.detail.text || ''));
  const mainExit = ev.find(e => e.kind === 'main-exit');
  const timeline = { origin, clickAt: click && click.t, dialogLoadedMs: rel(loaded && loaded.t), firstSampleMs: rel(first && first.t), endingSeenMs: rel(ending && ending.t), lateSentenceMs: rel(late && late.t),
    lateAfterEndingMs: late && ending ? late.t - ending.t : null, mainExitMs: rel(mainExit && mainExit.t), processExitMs: exit && click ? exit.t - click.t : null, exitAfterEndingMs: exit && ending ? exit.t - ending.t : null };
  out.frozenTimeline = timeline;
  if (exit && click) c7Checks(E, { dlg, click, exit, wait, tag: (waitSeconds ? 'policy ' + wait + ', ' : 'default wait, ') + origin + ' Quit' });
  out.dialogTexts = dlg.filter((s, i, a) => i === 0 || JSON.stringify([s.snap.status && s.snap.status.text, s.snap.detail && s.snap.detail.text, s.snap.actions && s.snap.actions.hidden]) !== JSON.stringify([a[i - 1].snap.status && a[i - 1].snap.status.text, a[i - 1].snap.detail && a[i - 1].snap.detail.text, a[i - 1].snap.actions && a[i - 1].snap.actions.hidden]))
    .map(s => ({ atMs: rel(s.t), title: s.snap.title && s.snap.title.text, status: s.snap.status && s.snap.status.text, detail: s.snap.detail && s.snap.detail.text, actionsHidden: s.snap.actions && s.snap.actions.hidden, actionsRect: s.snap.actions && s.snap.actions.rect, cancel: s.snap.cancel && { hidden: s.snap.cancel.hidden, disabled: s.snap.cancel.disabled }, force: s.snap.force && { hidden: s.snap.force.hidden, disabled: s.snap.force.disabled } }));
  check(holdOverride ? 'LITERAL-BRIEF RUN (hold ' + holdSeconds + ' s): observation only, the process exit, exit code 0 and whether the thaw ended it' : 'the process ended while the broker was STILL frozen (not helped by the thaw), exit code 0', (holdOverride ? true : (exit !== null && exit.code === 0 && exit.signal === null && exit.t < tHold + holdSeconds * 1000 - 2000)), { endedBeforeThaw: exit !== null && exit.t < tHold + holdSeconds * 1000 - 2000, exitCode: exit && exit.code, exit: exit && { code: exit.code, signal: exit.signal }, exitMsAfterFreeze: exit && exit.t - tHold, holdMs: holdSeconds * 1000 });
  check('the app exited, exit code 0 (informational when the hold is the literal brief 40 s)', exit !== null && exit.code === 0 && exit.signal === null, { exit: exit && { code: exit.code, signal: exit.signal }, processExitMs: timeline.processExitMs });
  check('the quit dialog appeared at about 1.5 s after the click, in the pausing state', timeline.dialogLoadedMs !== null && timeline.dialogLoadedMs >= 1300 && timeline.dialogLoadedMs <= 2500 && first && first.snap.status.text === PAUSING, { dialogLoadedMs: timeline.dialogLoadedMs, firstSampleMs: timeline.firstSampleMs, firstText: first && first.snap.status.text });
  check('ending state text is exact and carries the number from the policy / default', Boolean(ending) && ending.snap.detail.text === 'This can take up to ' + wait + ' seconds.' && ending.snap.title.text === 'Quitting Comic Metadata', { endingSeenMs: timeline.endingSeenMs, status: ending && ending.snap.status.text, detail: ending && ending.snap.detail.text, title: ending && ending.snap.title.text, expectedNumber: wait });
  check('ending state: action row hidden (no buttons, no gap), Cancel quit and Quit now not offered', Boolean(ending) && ending.snap.actions.hidden === true && ending.snap.actions.rect.every(v => v === 0), { actions: ending && ending.snap.actions, cancel: ending && ending.snap.cancel, force: ending && ending.snap.force });
  check('the 10-second sentence appears about 10 s into the ending state, not before' + (holdOverride ? ' (literal-brief run: the thaw at ' + holdSeconds + ' s can end the wait first, so this is observation only)' : ''), holdOverride || Boolean(late) && late.t - ending.t >= 9500 && late.t - ending.t <= 11500 && late.snap.detail.text === 'This can take up to ' + wait + ' seconds. An interrupted write keeps its recovery backup.', { lateAfterEndingMs: timeline.lateAfterEndingMs, text: late && late.snap.detail.text });
  check('the process ended by the closure wait + 1 s after the ending state began (frozen broker never answered)', exit !== null && ending && exit.t - ending.t <= (wait + 1) * 1000 + 3000, { exitAfterEndingMs: timeline.exitAfterEndingMs, limitMs: (wait + 1) * 1000 + 3000, clickToExitMs: timeline.processExitMs });
  const probe = ev.find(e => e.kind === 'ending-probe');
  out.endingProbe = probe || null;
  check('ending state: Escape, the dialog\'s close(), and a second File > Exit change nothing; the app is still waiting', Boolean(probe) && probe.dialogStillThere === true && probe.escape === 'dispatched' && probe.closeCall === 'called' && probe.exitMenu === 'clicked' && probe.s1.status === ENDING && probe.s1.actionsHidden === true && probe.before.windows === probe.after.windows, probe ? { seenForMs: probe.seenForMs, escape: probe.escape, closeCall: probe.closeCall, exitMenu: probe.exitMenu, status: probe.s1.status, windows: [probe.before.windows, probe.after.windows] } : { note: 'probe did not run' });
  const afterClick = ev.filter(e => click && e.t >= click.t);
  const tips = afterClick.filter(e => e.kind === 'tray-tip').map(e => ({ atMs: rel(e.t), tip: e.tip }));
  const menus = afterClick.filter(e => e.kind === 'tray-menu').map(e => ({ atMs: rel(e.t), items: e.items.map(i => i.label + (i.enabled ? '' : ' (disabled)')) }));
  out.trayDuringQuit = { tips, menus };
  check('tray tooltip and menu read Quitting\u2026 with tray Quit disabled', tips.some(t => /Quitting/.test(t.tip)) && menus.some(m => m.items.some(i => /Quitting/.test(i))), out.trayDuringQuit);
  check('no guard violation through the quit', ev.filter(e => e.kind === 'violation').length === 0, { violations: ev.filter(e => e.kind === 'violation').length });
  // what is left on disk and alive
  await sleep(1500);
  const leftover = fs.readdirSync(run.locks).filter(n => /^leftover-.*\.json$/.test(n));
  out.leftoverRecords = leftover.map(n => { try { const r = JSON.parse(fs.readFileSync(path.win32.join(run.locks, n), 'utf8')); return { file: n.slice(0, 20) + '\u2026', schema: r.schema, source: r.source || '(broker)', members: r.members === null ? null : (r.members || []).length, ageSeconds: Math.round(Date.now() / 1000 - r.written) }; } catch (e) { return { file: n, unreadable: String(e.message) }; } });
  check('a leftover record is left in the QA locks folder (the broker never answered)' + (holdOverride ? ' (literal-brief run: observation only, the thawed broker may have closed cleanly)' : ''), holdOverride || leftover.length >= 1, { records: out.leftoverRecords });
  out.pidsAtExitPlus1500 = [...pids].map(p => ({ pid: p, alive: pidAlive(p) }));
  const released = await h.release();
  await sleep(10000);
  out.pidsAfterHoldReleased = [...pids].map(p => ({ pid: p, alive: pidAlive(p) }));
  out.enginePortRefused = await portRefused(run.ports.engine);
  check('after the hold ended: the frozen broker and the engine parts are gone, port refused', out.pidsAfterHoldReleased.every(p => !p.alive) && out.enginePortRefused, { pids: out.pidsAfterHoldReleased, portRefused: out.enginePortRefused, holdExit: released && { code: released.code } });
  out.pass = S.list.every(s => s.ok !== false);
}

// ---- the previous-session screens (item 2) ----
const STR = { head: 'The previous session is still closing.', p1: 'Part of the local service has not ended yet. Try again in a moment.', p3: 'Part of the local service has not ended yet. Try again, or restart your PC to clear it.',
  checking: 'Checking the previous session\u2026', tipTry: 'Check the previous session again. The app starts once it has ended.', tipLogs: 'Open the local app\'s log folder.', tipQuit: 'Close Comic Metadata.' };
function klass(snap) {
  if (!snap || snap.file !== 'startup.html' || !snap.status) return null;
  const text = snap.status.text;
  if (text === STR.checking) return 'P2';
  if (text === STR.head) { const d = snap.detail && snap.detail.text; return d === STR.p1 ? 'P1' : d === STR.p3 ? 'P3' : 'P?'; }
  return 'other:' + text;
}
const mainSamples = async (from, to = Date.now() + 1e9) => JSON.parse(await run.inspector.evaluate('JSON.stringify(globalThis.__qa.samples.filter(s=>s.index===0&&s.t>=' + from + '&&s.t<=' + to + '))'));
async function latestStartup() { const raw = await run.inspector.evaluate("JSON.stringify(globalThis.__qa.samples.filter(s=>s.index===0&&s.snap&&s.snap.file==='startup.html').slice(-1))"); return JSON.parse(raw)[0]; }
async function waitClass(classes, since, timeoutMs = 40000) {
  const want = [].concat(classes), start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const hit = (await mainSamples(since)).find(s => want.includes(klass(s.snap)));
    if (hit) return hit;
    await sleep(30);
  }
  throw new Error('Timed out waiting for ' + want.join('/') + ' (last: ' + JSON.stringify(klass((await latestStartup() || {}).snap)) + ')');
}
function setAge(info, ageSeconds) {
  const files = fs.readdirSync(info.locks).filter(n => /^leftover-.*\.json$/.test(n));
  if (files.length !== 1) throw new Error('expected one leftover record, found ' + files.length);
  const file = path.win32.join(info.locks, files[0]);
  // Edit the text, not the parsed JSON: the member's creation time is a FILETIME above 2^53, which a JS number round trip would corrupt.
  const raw = fs.readFileSync(file, 'utf8');
  const next = raw.replace(/"written": *[-0-9.eE+]+/, '"written": ' + (Date.now() / 1000 - ageSeconds));
  if (next === raw) throw new Error('written field not found in the record');
  fs.writeFileSync(file, next);
  return files[0];
}
async function openPrev(tag, info, policyExtra) {
  run = await launch(tag, { existing: info, policyExtra });
  out.run = runInfoForEvidence(run);
  out.expectedTray = await run.qa('expected()');
  check(tag + ': observer bound to the exact app', run.identity.version === '0.6.9' && run.identity.packaged === true, { pid: run.identity.pid, guards: run.identity.guards });
  await run.qa('sampleStart(25)');
  return run;
}
const retryAndWait = async (from, then) => { const tc = Date.now(); await run.qa('clickRetry()', true); const p2 = await waitClass('P2', tc); const res = await waitClass(then, p2.t); return { tc, p2, res }; };

async function cycle(label, expr, withAge60) {
  const size = await run.qa(expr);
  await sleep(600);
  const P1 = await latestStartup();
  const a = await retryAndWait(0, 'P1');
  setAge(out.infoA, 180);
  const b = await retryAndWait(0, 'P3');
  let c60 = null;
  if (withAge60) { setAge(out.infoA, 60); c60 = await retryAndWait(0, 'P1'); }
  setAge(out.infoA, 0);
  const d = await retryAndWait(0, 'P1');
  const rects = s => JSON.stringify(['retry', 'logs', 'quit'].map(k => s[k].rect));
  const sset = { P1: P1.snap, P2_after_P1: a.p2.snap, P1_result: a.res.snap, P2_after_P3_set: b.p2.snap, P3: b.res.snap, P2_after_P3: d.p2.snap, P1_end: d.res.snap };
  const base = rects(P1.snap);
  const stack = s => { const r = ['status', 'detail', 'checked', 'actions'].map(k => s[k] && s[k].rect).filter(x => x && x[3] > 0); return r.every((x, i) => i === 0 || r[i - 1][1] + r[i - 1][3] <= x[1] + 0.5); };
  const m = { label, size, iw: P1.snap.iw, ih: P1.snap.ih,
    buttonsDoNotMove: Object.values(sset).every(s => rects(s) === base), buttonRects: { P1: JSON.parse(rects(P1.snap)), P3: JSON.parse(rects(b.res.snap)), P2: JSON.parse(rects(a.p2.snap)) },
    minButtonHeight: Math.min(...Object.values(sset).flatMap(s => ['retry', 'logs', 'quit'].map(k => s[k].rect[3]))),
    noSidewaysScroll: Object.values(sset).every(s => s.sw <= s.cw), scrollW: Object.values(sset).map(s => [s.sw, s.cw]).slice(0, 3), stackedWithoutOverlap: Object.values(sset).every(stack),
    detailHeight: { P1: P1.snap.detail.rect[3], P3: b.res.snap.detail.rect[3] }, detailWidth: { P1: P1.snap.detail.rect[2], P3: b.res.snap.detail.rect[2] },
    p3DetailWraps: b.res.snap.detail.rect[3] > P1.snap.detail.rect[3] + 1, retryY: { P1: P1.snap.retry.rect[1], P3: b.res.snap.retry.rect[1] },
    p3Text: b.res.snap.detail.text, p3Class: klass(b.res.snap), age60Class: c60 && klass(c60.res.snap) };
  return m;
}

// ---- nested ComicInfo (item 4): read after the app has quit ----
async function nestedVerdict() {
  const probeOut = path.win32.join(run.root, 'nested-probe.json');
  const done = spawnSync(PY, ['-B', '-I', BASE + '/evidence/harness/nested_probe.py', out.fixture.library, run.state, probeOut], { windowsHide: true, encoding: 'utf8', timeout: 120000 });
  check('nested probe ran read-only after the app quit', done.status === 0, { stdout: (done.stdout || '').trim().slice(-300), stderr: (done.stderr || '').slice(-300) });
  const p = JSON.parse(fs.readFileSync(probeOut, 'utf8'));
  out.nestedProbe = p;
  const H = out.fixture.hashes;
  const N13 = 'Futaba QA Fixture 013 (2020).cbz', N14 = 'Futaba QA Fixture 014 (2020).cbz', A = 'QA Nested Alpha 001 (2021).cbz', B = 'QA Nested Beta 001 (2021).cbz', G = 'QA Nested Gamma 001 (2021).cbz';
  const tag = (name, t) => { const f = p.archives[name] && p.archives[name].fields; return f ? f.filter(([k]) => k === t).map(x => x[1]) : null; };
  const a13 = p.archives[N13], a14 = p.archives[N14];
  const cat = name => p.catalog[name];
  check('nested-only fixture 013 (a): the app tagged it', cat(N13) && cat(N13).status === 'tagged', { status: cat(N13) && cat(N13).status, error: cat(N13) && cat(N13).error });
  check('nested-only fixture 013 (b): after the app write there is ONE root ComicInfo.xml, no nested ComicInfo, the cover kept', a13 && a13.root.length === 1 && a13.root[0] === 'ComicInfo.xml' && a13.nested.length === 0 && a13.entries.includes('cover.png'), { entries: a13 && a13.entries, root: a13 && a13.root, nested: a13 && a13.nested });
  check('nested-only fixture 013 (c): the nested copy is merged in (Summary, Writer, Genre once each) beside the app\'s own fields', a13 && JSON.stringify(tag(N13, 'Summary')) === JSON.stringify(['Nested summary kept by QA 13.']) && JSON.stringify(tag(N13, 'Writer')) === JSON.stringify(['Nested Writer QA']) && JSON.stringify(tag(N13, 'Genre')) === JSON.stringify(['Nested Genre QA']) && JSON.stringify(tag(N13, 'Series')) === JSON.stringify(['Futaba QA Fixture']) && JSON.stringify(tag(N13, 'Number')) === JSON.stringify(['13']), { fields: a13 && a13.fields });
  check('nested "None" Number fixture 014 (a): the app tagged it', cat(N14) && cat(N14).status === 'tagged', { status: cat(N14) && cat(N14).status, error: cat(N14) && cat(N14).error });
  check('nested "None" Number fixture 014 (b): one root ComicInfo.xml, nested removed; Number is the real 14, never "None"; the nested Summary merged', a14 && a14.root.length === 1 && a14.nested.length === 0 && JSON.stringify(tag(N14, 'Number')) === JSON.stringify(['14']) && JSON.stringify(tag(N14, 'Summary')) === JSON.stringify(['Nested summary kept by QA 14.']) && !(a14.fields || []).some(([, v]) => v === 'None'), { fields: a14 && a14.fields });
  check('read side, control Alpha: its only ComicInfo is in a subfolder and the catalog read it as metadata (status embedded, Series/Number/Summary from it)', cat(A) && cat(A).status === 'embedded' && cat(A).metadata.Series === 'QA Nested Alpha' && cat(A).metadata.Number === '1' && cat(A).metadata.Summary === 'Alpha nested summary.', { status: cat(A) && cat(A).status, metadata: cat(A) && cat(A).metadata });
  check('read side, control Gamma: a nested "None" Number reads as blank (status embedded, Series and Summary read, no Number)', cat(G) && cat(G).status === 'embedded' && cat(G).metadata.Series === 'QA Nested Gamma' && cat(G).metadata.Summary === 'Gamma nested summary.' && !cat(G).metadata.Number, { status: cat(G) && cat(G).status, metadata: cat(G) && cat(G).metadata });
  check('read side, negative control Beta: two nested copies are ignored (not read as metadata)', cat(B) && cat(B).status !== 'embedded' && cat(B).status !== 'tagged' && !cat(B).metadata.Summary, { status: cat(B) && cat(B).status, metadata: cat(B) && cat(B).metadata });
  check('unmatched controls untouched on disk (Alpha, Beta, Gamma byte-identical to the fixture)', [A, B, G].every(n => p.archives[n] && p.archives[n].sha256 === H[n]), { alpha: p.archives[A] && p.archives[A].sha256 === H[A], beta: p.archives[B] && p.archives[B].sha256 === H[B], gamma: p.archives[G] && p.archives[G].sha256 === H[G] });
}

// 0.6.8 q2: a nested-only copy follows the merge's left-out rules (no store dates, no PageCount, no case twin, no year-like Volume)
function q2Verdict(p) {
  const N15 = 'Futaba QA Fixture 015 (2020).cbz', D = 'QA Nested Delta 001 (2021).cbz';
  const H = out.fixture.hashes;
  const cat = name => p.catalog[name];
  const fields = name => (p.archives[name] && p.archives[name].fields) || [];
  const tags = (name, t) => fields(name).filter(([k]) => k === t).map(x => x[1]);
  const d = cat(D), a15 = p.archives[N15];
  const left = ['Year', 'Month', 'Day', 'PageCount', 'Volume', 'writer'];
  check('q2 read side (positive-control comic with store dates, no source can match it): the catalog shows NO Year, Month, Day, PageCount, Volume (year-like) or case-twin "writer", while Series, Number, Summary and the properly-cased Writer are read from the nested copy', d && d.status === 'embedded' && left.every(k => !(k in d.metadata)) && d.metadata.Summary === 'Delta nested summary.' && d.metadata.Writer === 'Delta Writer' && d.metadata.Series === 'QA Nested Delta' && d.metadata.Number === '1', { status: d && d.status, metadataKeys: d && Object.keys(d.metadata).sort(), year: d && d.metadata.Year || '(none)' });
  check('q2: the store-dated control is byte-identical afterwards (the app wrote nothing)', p.archives[D] && p.archives[D].sha256 === H[D], { same: p.archives[D] && p.archives[D].sha256 === H[D] });
  check('q2 automatic write (matched nested-only comic whose nested copy has store dates 2019-12-31): tagged, ONE root ComicInfo, no nested copy; the root holds the COVER date (Year 2020, Month 1) and NOT the store date, no Day, no PageCount, no Volume, no "writer" twin; the nested Summary and Writer are kept', cat(N15) && cat(N15).status === 'tagged' && a15 && a15.root.length === 1 && a15.nested.length === 0 && JSON.stringify(tags(N15, 'Year')) === JSON.stringify(['2020']) && JSON.stringify(tags(N15, 'Month')) === JSON.stringify(['1']) && tags(N15, 'Day').length === 0 && tags(N15, 'PageCount').length === 0 && tags(N15, 'Volume').length === 0 && tags(N15, 'writer').length === 0 && JSON.stringify(tags(N15, 'Summary')) === JSON.stringify(['Store-dated nested summary QA 15.']) && JSON.stringify(tags(N15, 'Writer')) === JSON.stringify(['Store Dated Writer']), { status: cat(N15) && cat(N15).status, root: a15 && a15.root, nested: a15 && a15.nested, fields: fields(N15) });
  // the saved record of what was removed, before the rename
  const file = path.win32.join(run.state, 'data', 'removed-nested-copies.jsonl');
  const lines = fs.existsSync(file) ? fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l)) : [];
  const rec = lines.find(r => path.win32.basename(r.archive) === N15);
  const nestedText = '<?xml version="1.0"?><ComicInfo><Series>Futaba QA Fixture</Series><Number>15</Number><Summary>Store-dated nested summary QA 15.</Summary><Volume>2019</Volume><Year>2019</Year><Month>12</Month><Day>31</Day><PageCount>22</PageCount><writer>qa twin</writer><Writer>Store Dated Writer</Writer></ComicInfo>';
  const whys = rec && Array.isArray(rec.left_out) ? Object.fromEntries(rec.left_out.map(x => [x[0], x[2]])) : null;
  out.q2Record = rec && { kind: rec.kind, entry: rec.entry, left_out: rec.left_out, backup: path.win32.basename(rec.backup || ''), lines: lines.length, archives: lines.map(r => path.win32.basename(r.archive) + ':' + r.kind) };
  check('q2: data/removed-nested-copies.jsonl exists with one line per nested-only write (013, 014, 015, kind nested-only); the line for 015 holds the whole nested copy byte for byte (xml_base64) and what was left out with the reason (Year, Month, Day, PageCount, Volume, writer)', lines.length === 3 && lines.every(r => r.kind === 'nested-only') && rec && Buffer.from(rec.xml_base64, 'base64').toString('utf8') === nestedText && whys && ['Year', 'Month', 'Day'].every(k => whys[k] === 'nested date never copied') && whys.PageCount === 'PageCount never copied' && whys.Volume === 'Volume is a year' && whys.writer === 'same tag in another letter case', out.q2Record);
}

const scenarios = {
  // Smoke evidence in the 0.6.5 schema that create-local-promotion.mjs validates (spec, startup, trayBytes, markResources,
  // processing, paused, resumed, close, quitRequested ...). Every value is read in this run; nothing is copied from a
  // previous run. Writes <out>.promotion.json and <out>.asar.txt beside the scenario result.
  async 'promotion-smoke'() {
    const sha = b => crypto.createHash('sha256').update(b).digest('hex');
    const MANIFEST = 'I:/AI Projects/Temp/cmo-rc069/source-manifest-67c7b53.json';
    const RC = 'I:/AI Projects/Worktrees/Comics Meta Organizer/rc-069';
    const started = new Date().toISOString();
    const manifestRaw = fs.readFileSync(MANIFEST), manifest = JSON.parse(manifestRaw);
    const entry = name => manifest.files.find(f => f.path === name)?.sha256;
    const head = spawnSync('git', ['-C', RC, 'rev-parse', 'HEAD'], { encoding: 'utf8', windowsHide: true }).stdout.trim();
    const installerSha = sha(fs.readFileSync(RC + '/dist/Comic-Metadata-Setup-0.6.9.exe'));
    const feedSha = sha(LATEST_YML);
    check('identity read in this run: manifest head equals the repo head; feed served equals dist/latest.yml', manifest.head === head && sha(fs.readFileSync(RC + '/dist/latest.yml')) === feedSha, { head, manifestHead: manifest.head, manifestSha256: sha(manifestRaw), installerSha256: installerSha, feedSha256: feedSha });
    await startup('promo', async info => { emptyLibrary(info); });
    const expected = out.expectedTray;
    const tested = await run.qa('binaries()');
    out.testedRuntime = { exe: tested.exe, asar: tested.asar };
    const stateOf = r => { for (const [n, e] of Object.entries(expected)) if (e.bm1 === r.bm1 && e.bm05 === r.bm05) return n; return 'unknown'; };
    const walk = log => {
      const rows = [];
      for (const r of log) {
        if (r.type === 'image') {
          const state = stateOf(r);
          rows.push({ state, size1: r.size1, len1: r.len1, len05: r.len05, t: r.t, tooltip: null,
            exact: state !== 'unknown' && r.bm1 === expected[state].bm1 && r.bm05 === expected[state].bm05 && r.len1 === 4096 && r.len05 === 1024 && r.size1.width === 32 && r.size1.height === 32 });
        } else if (r.type === 'tip' && rows.length && rows[rows.length - 1].tooltip === null) rows[rows.length - 1].tooltip = r.tip;
      }
      return rows;
    };
    const shape = r => ({ exact: r.exact, state: r.state, size1: r.size1, len1: r.len1, len05: r.len05, tooltip: r.tooltip });
    // startup (setup screen, as in 0.6.5)
    await waitFor(async () => { const p = await run.qa('page()', true); return /setup\.html$/.test(p.url) && p.ready === 'complete'; }, 'setup page', 60000);
    const windows0 = await run.qa('windows()');
    const violations0 = await run.qa('violations');
    const menu0 = await run.qa('menuItems()');
    const engines0 = await run.engines();
    const token = await run.token();
    const startupHttp = await fetch('http://127.0.0.1:' + run.ports.engine + '/api/shell/startup', { headers: { 'X-ComicsMeta-Shell': token }, signal: AbortSignal.timeout(3000) });
    const startupBody = await startupHttp.json();
    const status0 = await run.shellStatus();
    const startupRec = { version: run.identity.version, packaged: run.identity.packaged, pid: run.identity.pid, enginePid: engines0[0].pid, violations: violations0,
      windows: windows0.map(w => ({ url: decodeURIComponent(w.url).split('/').slice(-3).join('/'), visible: w.visible, focused: w.focused, offscreen: w.offscreen })),
      quitEnabled: menu0.find(i => i.label === '&Quit')?.enabled === true,
      guards: run.identity.guards + ' guards, all installed: ' + (run.identity.guards === GUARDS_INTENDED),
      engine: { httpStatus: status0.http, owned: status0.body.owned, phase: startupBody.phase } };
    check('startup recorded', startupRec.packaged === true && startupRec.version === '0.6.9' && startupRec.engine.owned === true && startupRec.engine.httpStatus === 200 && startupRec.violations.length === 0, { windowUrl: startupRec.windows[0] && startupRec.windows[0].url, phase: startupRec.engine.phase, guards: startupRec.guards });
    // ready dashboard (private empty library through the real shell IPC)
    await setupLibrary(run, path.win32.join(run.root, 'library'));
    const processingRow = await waitFor(async () => { const rows = walk(await run.qa('trayLog')); return [...rows].reverse().find(r => r.state === 'processing' && r.tooltip === 'Comic Metadata \u2014 Processing enabled'); }, 'processing icon with its tooltip on the ready dashboard', 30000, 200);
    // Pause: the real tray callback
    const tPause = Date.now();
    await run.qa("click('&Pause && release GPU')", true);
    const pausedRow = await waitFor(async () => { const rows = walk(await run.qa('trayLog')); return rows.find(r => r.t >= tPause && r.state === 'paused' && r.tooltip !== null); }, 'paused icon after the Pause callback', 30000, 20);
    const statusAfterPause = await run.shellStatus();
    const control = { requested: statusAfterPause.body.control.requested, phase: statusAfterPause.body.control.phase };
    await waitFor(async () => (await run.qa('menuItems()')).some(i => i.label === '&Resume processing' && i.enabled), 'Resume item enabled', 30000, 200);
    // Resume: the real tray callback
    const tResume = Date.now();
    await run.qa("click('&Resume processing')", true);
    const resumedRow = await waitFor(async () => { const rows = walk(await run.qa('trayLog')); return rows.find(r => r.t >= tResume && r.state === 'processing' && r.tooltip !== null); }, 'processing icon after the Resume callback', 30000, 100);
    const allRows = walk(await run.qa('trayLog'));
    const windowsBefore = await run.qa('windows()');
    const violationsBefore = await run.qa('violations');
    const spawnsBefore = await run.qa('otherSpawns');
    const quit = await quitViaTray('promotion smoke');
    const events = run.readEvents();
    const quitClick = events.filter(e => e.kind === 'tray-click' && e.label === '&Quit').pop();
    const trayBytes = {}, files = {};
    let matches = 0;
    for (const n of ['processing', 'paused', 'verification', 'error']) {
      trayBytes[n] = { normal: expected[n].file, small: expected[n].file16 };
      if (expected[n].file === entry('desktop/assets/tray-' + n + '.png')) matches++;
      if (expected[n].file16 === entry('desktop/assets/tray-' + n + '-16.png')) matches++;
    }
    const markResources = { matches, distinctNormal: new Set(Object.values(expected).map(e => e.bm1)).size, distinctSmall: new Set(Object.values(expected).map(e => e.bm05)).size };
    const evidence = { schema: 1, mode: 'smoke', pass: false, started,
      spec: { sourceHead: head, manifest: sha(manifestRaw), installer: installerSha, feed: feedSha, exe: tested.exe, asar: tested.asar },
      ports: run.ports, steps: [], startup: startupRec, trayBytes, markResources,
      processing: shape(processingRow), paused: { ...shape(pausedRow), control }, resumed: shape(resumedRow),
      traySequence: allRows.map(r => r.state),
      windowsBeforeQuit: windowsBefore.map(w => ({ visible: w.visible, focused: w.focused, offscreen: w.offscreen })),
      violationsFinal: violationsBefore, otherSpawns: spawnsBefore,
      quitRequested: quitClick && quitClick.found === true ? 'actual tray Quit requested' : null, quitLabel: quitClick && quitClick.label,
      close: { code: quit.exit && quit.exit.code, signal: quit.exit && quit.exit.signal, remaining: quit.recordedPidsAliveAt12s, enginePortRefused: quit.enginePortRefused, locksClaims: quit.claimsAfter },
      feedRequests: run.stubs.counts.feed.length, modelRequests: run.stubs.counts.model.length, finished: new Date().toISOString() };
    evidence.pass = startupRec.quitEnabled && markResources.matches === 8 && markResources.distinctNormal === 4 && markResources.distinctSmall === 4
      && evidence.processing.exact && evidence.processing.state === 'processing' && evidence.paused.exact && evidence.paused.state === 'paused'
      && evidence.resumed.exact && evidence.resumed.state === 'processing' && evidence.close.code === 0 && evidence.close.signal === null
      && evidence.close.remaining.length === 0 && evidence.close.enginePortRefused === true && evidence.close.locksClaims.length === 0
      && violationsBefore.length === 0 && spawnsBefore.length === 0 && evidence.quitRequested === 'actual tray Quit requested'
      && windowsBefore.every(w => w.visible === false && w.focused === false && w.offscreen === true);
    fs.writeFileSync(outFile.replace(/\.result\.json$/, '.promotion.json'), JSON.stringify(evidence, null, 2) + '\n');
    let asarText = '# Tray PNGs read from the RUNNING packaged app (Electron asar fs): sha256 of file bytes. Source: ' + head + '\n# app.asar sha256 ' + tested.asar + '\n';
    for (const n of ['processing', 'paused', 'verification', 'error']) for (const [suffix, key] of [['', 'file'], ['-16', 'file16']]) {
      const name = 'desktop/assets/tray-' + n + suffix + '.png';
      asarText += name + ' ' + expected[n][key] + (expected[n][key] === entry(name) ? ' == source manifest' : ' != SOURCE MANIFEST ' + entry(name)) + '\n';
    }
    fs.writeFileSync(outFile.replace(/\.result\.json$/, '.asar.txt'), asarText);
    out.modelRequestLog = run.stubs.counts.model.slice(0, 40).map(r => r.url + (r.qa ? " (qa-marked)" : " (NOT qa-marked)"));
    check('promotion-schema evidence written from this run', evidence.pass, { pass: evidence.pass, sequence: evidence.traySequence, control, markResources, feedRequests: evidence.feedRequests, modelRequests: evidence.modelRequests });
    out.pass = evidence.pass && S.list.every(s => s.ok !== false);
  },

  // core smoke: launch, tray, close button, an ordinary pass over a library that also holds nested-ComicInfo fixtures, tray Quit.
  // 0.6.7: the library carries two matched fixtures whose only ComicInfo is in a subfolder (one with a nested "None" Number) and
  // three unmatched read-only controls; after the Quit nothing runs and nested_probe.py reads the archives and the catalog.
  async core() {
    const N = 12;
    await startup('core', fixtureState(N, true, true));
    await run.qa('sampleStart(40)');
    const expected = out.expectedTray;
    const pngSource = Object.fromEntries(fs.readFileSync(BASE + '/work/tray-png-source-hashes.txt', 'utf8').trim().split('\n').map(l => l.split(' ')).map(([f, h]) => [path.basename(f), h]));
    const pngOk = ['processing', 'paused', 'verification', 'error'].every(n => expected[n].file === pngSource['tray-' + n + '.png'] && expected[n].file16 === pngSource['tray-' + n + '-16.png']);
    const distinct = ['bm1', 'bm05'].every(k => new Set(Object.values(expected).map(e => e[k])).size === 4);
    check('packaged tray PNGs equal the source commit; four icon states distinct at both sizes', pngOk && distinct, { pngMatches: pngOk, distinct, len1: expected.processing.len1, len05: expected.processing.len05 });
    // setup screen
    await waitFor(async () => { const p = await run.qa('page()', true); return /setup\.html$/.test(p.url) && p.ready === 'complete'; }, 'setup page', 60000);
    await windowsClean('setup screen');
    await engineOwned('setup screen');
    const menu0 = await run.qa('menuItems()');
    check('tray menu on the setup screen: Open, Pause (disabled), Quit (enabled)', menu0.some(i => i.label === '&Open') && menu0.find(i => i.label === '&Quit')?.enabled === true, { menu: menu0 });
    const close0 = await run.qa('closeButton()');
    await sleep(500);
    check('close button on the setup screen keeps the process and window (tray-resident)', run.alive() && close0.after.destroyed === false && close0.after.count === close0.before.count, close0);
    // setup + dashboard + ordinary pass
    const saved = await setupLibrary(run, out.fixture.library);
    check('first-run setup saved through the real shell IPC', saved.configured === true, { configured: saved.configured });
    const state1 = await run.qa('state()', true);
    const page1 = await run.qa('page()', true);
    check('dashboard loaded after setup', /^http:\/\/127\.0\.0\.1:/.test(page1.url) && state1.service === 'ready', { url: page1.url.replace(/:\d+/, ':<port>'), service: state1.service });
    const t0 = Date.now();
    let last = null;
    const passed = await waitFor(async () => {
      const r = await run.apiState(); last = r.body.counts;
      const cbz = path.win32.join(out.fixture.library, 'Bundled Conversion 001.cbz');
      return (r.body.counts.tagged || 0) >= N + 3 && fs.existsSync(cbz) && !fs.existsSync(path.win32.join(out.fixture.library, 'Bundled Conversion 001.cb7')) && r.body.counts;
    }, 'ordinary pass (tagged fixtures incl. the two nested + cb7 conversion)', 240000, 1000).catch(e => null);
    out.passCounts = last;
    check('ordinary pass: every matched fixture tagged (12 plain + 3 nested), cb7 converted to cbz by the bundled 7-Zip', Boolean(passed), { counts: last, seconds: Math.round((Date.now() - t0) / 100) / 10, tagged: last && last.tagged });
    must(passed, 'ordinary pass finished');
    // read one written ComicInfo back through the bundled 7-Zip
    const one = path.win32.join(out.fixture.library, 'Futaba QA Fixture 001 (2020).cbz');
    const info = spawnSync(SEVENZ, ['e', '-so', one, 'ComicInfo.xml'], { windowsHide: true, encoding: 'utf8', timeout: 30000 });
    check('a tagged comic carries ComicInfo.xml with the fixture identity', /Futaba QA Fixture/.test(info.stdout) && /<Number>1<\/Number>/.test(info.stdout), { bytes: info.stdout.length, series: /<Series>([^<]*)</.exec(info.stdout)?.[1], number: /<Number>([^<]*)</.exec(info.stdout)?.[1] });
    // dashboard text must not carry the removed 0.6.6 banner / closure wording
    const dash = await run.qa("rend(\"document.body.innerText.slice(0,4000)\")", true);
    out.dashboardTextHead = String(dash).replace(/\s+/g, ' ').slice(0, 300);
    check('dashboard text carries none of the removed closure wording (B1-B4: could not be stopped / Task Manager)', !/could not be stopped|Task Manager|still closing/i.test(String(dash)), { chars: String(dash).length });
    await windowsClean('dashboard');
    // tray: processing, Pause, Resume, with the real callbacks and the real Tray.setImage bytes
    const tray0 = await run.qa('trayLog');
    const lastImage = [...tray0].reverse().find(r => r.type === 'image');
    check('tray shows the processing icon on the ready dashboard', lastImage && trayStateOf(lastImage, expected) === 'processing' && lastImage.len1 === 4096 && lastImage.len05 === 1024, { state: lastImage && trayStateOf(lastImage, expected) });
    const menu1 = await run.qa('menuItems()');
    check('tray menu on the dashboard: Open, Pause enabled, Quit enabled', menu1.find(i => i.label === '&Open') && menu1.find(i => i.label === '&Pause && release GPU')?.enabled === true && menu1.find(i => i.label === '&Quit')?.enabled === true, { menu: menu1 });
    await run.qa("click('&Pause && release GPU')", true);
    await waitFor(async () => { const log = await run.qa('trayLog'); return log.some(r => r.type === 'tip' && /Paused\. Gemma released/.test(r.tip)); }, 'paused tooltip', 30000, 300);
    const tray1 = await run.qa('trayLog');
    const pausedImage = [...tray1].reverse().find(r => r.type === 'image');
    check('Pause tray callback: paused icon, tooltip says paused and GPU released', pausedImage && trayStateOf(pausedImage, expected) === 'paused', { state: pausedImage && trayStateOf(pausedImage, expected), tips: tray1.filter(r => r.type === 'tip').map(r => r.tip).slice(-3) });
    await waitFor(async () => (await run.qa('menuItems()')).some(i => i.label === '&Resume processing' && i.enabled), 'Resume item', 20000, 300);
    await run.qa("click('&Resume processing')", true);
    await waitFor(async () => { const log = await run.qa('trayLog'); const img = [...log].reverse().find(r => r.type === 'image'); return trayStateOf(img, expected) === 'processing' && (await run.qa('menuItems()')).some(i => i.label === '&Pause && release GPU'); }, 'processing icon after Resume', 30000, 300);
    const seq = (await run.qa('trayLog')).filter(r => r.type === 'image').map(r => trayStateOf(r, expected));
    check('Resume tray callback: processing icon again', seq[seq.length - 1] === 'processing' && seq.includes('paused'), { sequence: seq });
    // close button on the dashboard, then tray Quit
    const close1 = await run.qa('closeButton()');
    await sleep(500);
    check('close button on the dashboard keeps the process and window (tray-resident)', run.alive() && close1.after.destroyed === false && close1.after.count === close1.before.count, close1);
    out.violationsFinal = await run.qa('violations');
    out.otherSpawns = await run.qa('otherSpawns');
    check('no guard violation and no other spawn through the whole run', out.violationsFinal.length === 0 && out.otherSpawns.length === 0, { violations: out.violationsFinal.length, otherSpawns: out.otherSpawns.length, guards: run.identity.guards });
    out.quit = await quitViaTray('dashboard');
    out.feedRequests = run.stubs.counts.feed.length; out.modelRequests = run.stubs.counts.model.length;
    // the normal Quit's dialog behaviour, as the sampler saw it from inside the app
    { const ev = run.readEvents(); const click = ev.filter(e => e.kind === 'tray-click' && e.label === '&Quit').pop();
      const dlg = ev.filter(e => e.kind === 'sample' && e.snap && e.snap.file === 'stopping.html' && click && e.t >= click.t);
      out.normalQuitDialog = { samples: dlg.length, texts: [...new Set(dlg.map(s => s.snap.status && s.snap.status.text))], firstMsAfterClick: dlg.length ? dlg[0].t - click.t : null };
      check('normal Quit from the ready dashboard (observation of the quit dialog)', true, out.normalQuitDialog); }
    // nested ComicInfo: the app has quit; read the archives and the catalog
    await nestedVerdict();
    q2Verdict(out.nestedProbe);
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  },

  // quit straight from the first-run setup screen
  async 'setup-quit'() {
    await startup('setupq', async info => { emptyLibrary(info); });
    await waitFor(async () => { const p = await run.qa('page()', true); return /setup\.html$/.test(p.url) && p.ready === 'complete'; }, 'setup page', 60000);
    await windowsClean('setup screen');
    await engineOwned('setup screen');
    out.quit = await quitViaTray('setup screen');
    out.feedRequests = run.stubs.counts.feed.length; out.modelRequests = run.stubs.counts.model.length;
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  },

  // quit while the engine is still starting (the startup screen)
  async 'startup-quit'() {
    await startup('startq', async info => { emptyLibrary(info); });
    const events = await waitFor(() => { const e = run.readEvents(); return e.some(x => x.kind === 'tray-menu') && e; }, 'tray menu', 30000, 50);
    const state = await run.qa('state()', true);
    const page = await run.qa('page()', true);
    check('quit requested on the startup screen', true, { service: state.service, phase: state.startupPhase, page: page.url.split('/').slice(-1)[0] });
    out.quit = await quitViaTray('startup screen', { delay: 100 });
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  },

  // item 1: the engine broker ended from outside; the exact 0.6.4 repro, then Quit
  async 'repro-064'() {
    await startup('repro', async info => { emptyLibrary(info); });
    await setupLibrary(run, path.win32.join(run.root, 'library'));
    await windowsClean('ready dashboard');
    await engineOwned('before');
    const k1 = await killBroker();
    check('engine broker ended from outside (exit code 1, not 0/75/125/126)', k1.exitCode === 1, k1);
    await sleep(1000);
    const s1 = await run.qa('state()', true), p1 = await run.qa('page()', true);
    check('one second later: shell state and screen', true, { service: s1.service, failure: s1.failure, phase: s1.startupPhase, retryVisible: p1.retryVisible, screen: p1.url.split('/').slice(-1)[0], text: p1.text.slice(0, 120) });
    const retry = await run.qa('action("retryService").catch(() => {}) && "sent"', false);
    check('Retry action sent (the same IPC the Retry button sends)', true, { result: retry });
    const ready = await readyEngine('after Retry', 2);
    { const ev = run.readEvents(); out.timeline1 = ev.filter(e => ['engine-exit', 'engine-start', 'retry-click'].includes(e.kind)).map(e => ({ kind: e.kind, pid: e.pid, code: e.code, t: e.t })); const base = out.timeline1[0] && out.timeline1[0].t; out.timeline1.forEach(e => { e.dtMs = e.t - base; delete e.t; }); }
    const engines = await run.engines();
    check('Retry brought a NEW engine broker up and ready (0.6.4 finding 2)', ready && ready.pid !== k1.pid && engines.length >= 2 && engines.slice(-1)[0].pid !== k1.pid, { oldPid: k1.pid, newPid: ready.pid, brokersStarted: engines.length });
    const dash = await run.qa('page()', true);
    check('dashboard screen is back', /^http:\/\/127\.0\.0\.1:/.test(dash.url), { url: dash.url.replace(/:\d+/, ':<port>') });
    await engineOwned('after Retry');
    const k2 = await killBroker();
    check('second outside end of the broker (exit code 1)', k2.exitCode === 1, k2);
    await sleep(1000);
    const s2 = await run.qa('state()', true);
    check('one second later (before Quit)', true, { service: s2.service, failure: s2.failure, phase: s2.startupPhase, brokersStarted: (await run.engines()).length });
    out.quit = await quitViaTray('after the broker was ended from outside', { delay: 200, timeout: 90000, staleClaimsOk: true });
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  },

  // item 1 continued: failed screen after repeated outside ends, close button, Retry from the screen, Quit from the failed screen
  async 'failed-screen'() {
    await startup('failed', async info => { emptyLibrary(info); });
    await setupLibrary(run, path.win32.join(run.root, 'library'));
    const kills = [];
    for (let i = 1; i <= 4; i++) {
      await readyEngine('before outside end ' + i, i);
      kills.push(await killBroker());
    }
    check('broker ended from outside four times within the restart window (exit code 1 each)', kills.every(k => k.exitCode === 1), { kills: kills.map(k => k.exitCode) });
    await waitFor(async () => { const s = await run.qa('state()', true); return s.service === 'failed' && s.failure === 'RESTART_EXHAUSTED'; }, 'failed screen state', 30000, 300);
    const page = await run.qa('page()', true);
    check('failed state shows a visible Retry (Try again) control', page.retryVisible === true || page.tryAgain === true, { screen: page.url.split('/').slice(-1)[0] || 'dashboard', notice: page.notice, startupRetry: page.retryVisible, noticeTryAgain: page.tryAgain });
    { const stale = run.claims(); const alive = stale.map(n => /-(\d+)-[0-9a-f]{12}\./.exec(n)).filter(Boolean).map(m => Number(m[1])).filter(pidAlive); check('engine port free and no engine claim holder alive once the tree ended', (await portFree(run.ports.engine)) && alive.length === 0, { staleClaimFiles: stale.length, holdersAlive: alive }); }
    await windowsClean('failed screen');
    const close = await run.qa('closeButton()');
    await sleep(500);
    check('close button on the failed screen keeps the process and window (tray-resident)', run.alive() && close.after.destroyed === false && close.after.count === close.before.count, close);
    const clicked = await run.qa('clickRetry()', true);
    check('Retry control clicked on the failed screen', Boolean(clicked), { clicked });
    const ready = await readyEngine('after Retry from the failed screen', 5);
    check('Retry from the failed screen brought a new broker up and the dashboard back', ready && (await run.qa('page()', true)).url.startsWith('http://127.0.0.1:'), { newPid: ready && ready.pid, brokers: (await run.engines()).length });
    // end it from outside once more: the restart budget is spent, so the app sits on the failed screen with a dead broker
    const k5 = await killBroker();
    let failedAgain = null;
    try { failedAgain = await waitFor(async () => { const s = await run.qa('state()', true); return s.service === 'failed' ? s : false; }, 'failed screen again', 20000, 300); } catch { }
    check('after another outside end: ' + (failedAgain ? 'failed screen again (no automatic restart left)' : 'engine restarted automatically'), true, { exitCode: k5.exitCode, failure: failedAgain && failedAgain.failure });
    out.quit = await quitViaTray(failedAgain ? 'from the failed screen' : 'after automatic restart', { delay: 200, timeout: 90000, staleClaimsOk: true });
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  },

  // Senua t1: tray Quit during Retry's wait. The engine port is held by this harness so the wait lasts; released later.
  async 'quit-in-retry'() {
    await startup('qretry', async info => { emptyLibrary(info); });
    await setupLibrary(run, path.win32.join(run.root, 'library'));
    for (let i = 1; i <= 4; i++) { await readyEngine('before outside end ' + i, i); await killBroker(); }
    await waitFor(async () => { const s = await run.qa('state()', true); return s.service === 'failed' && s.failure === 'RESTART_EXHAUSTED'; }, 'failed screen state', 30000, 300);
    const brokersBefore = (await run.engines()).length;
    let holder = net.createServer();
    await new Promise((resolve, reject) => { holder.once('error', reject); holder.listen(run.ports.engine, '127.0.0.1', resolve); });
    const tHold = Date.now();
    check('failed screen; engine port now held by the harness so the closure wait lasts', true, { brokers: brokersBefore });
    const clicked = await run.qa('clickRetry()', true);
    check('Retry control clicked (enters the closure wait)', Boolean(clicked), { clicked });
    await sleep(2000);
    await run.qa("clickLater('&Quit',100)");
    const quitAt = Date.now();
    run.detach();
    const releaseAfter = 3500;
    await sleep(releaseAfter);
    holder.close(); holder = null;
    const releasedAt = Date.now();
    const pids = new Set();
    const exit = await Promise.race([run.exited, sleep(90000).then(() => null)]);
    const events = run.readEvents();
    const click = events.find(e => e.kind === 'tray-click' && e.label === '&Quit');
    const starts = events.filter(e => e.kind === 'engine-start');
    const startsAfterQuit = starts.filter(e => click && e.t >= click.t);
    out.timeline = events.filter(e => ['retry-click', 'tray-click', 'engine-start', 'engine-exit', 'main-exit'].includes(e.kind)).map(e => ({ kind: e.kind, dtMs: e.t - tHold, label: e.label, pid: e.pid, code: e.code }));
    out.releasedAtMs = releasedAt - tHold; out.quitAtMs = quitAt - tHold;
    for (const e of starts) pids.add(e.pid);
    check('app result after Quit during Retry', exit !== null, { exit: exit && { code: exit.code, signal: exit.signal }, quitToExitMs: exit && click ? exit.t - click.t : null });
    check('0.6.7 (Quit during Retry cancels Retry): no new broker was started after Quit was pressed during Retry\'s wait', startsAfterQuit.length === 0, { newBrokersAfterQuit: startsAfterQuit.map(e => ({ pid: e.pid, dtMs: e.t - tHold })), brokersBefore, brokersTotal: starts.length });
    const claimsAtExit = run.claims();
    const claimPids = claimsAtExit.map(n => /-(\d+)-[0-9a-f]{12}\./.exec(n)).filter(Boolean).map(m => Number(m[1]));
    for (const p of claimPids) pids.add(p);
    const diedAfterExitMs = {};
    const sampleStart = Date.now();
    while (Date.now() - sampleStart < 15000) {
      for (const p of pids) if (diedAfterExitMs[p] === undefined && !pidAlive(p)) diedAfterExitMs[p] = exit ? Date.now() - exit.t : null;
      if ([...pids].every(p => diedAfterExitMs[p] !== undefined)) break;
      await sleep(50);
    }
    out.diedAfterExitMs = diedAfterExitMs;
    out.pidsAlive15s = [...pids].filter(pidAlive);
    out.enginePortRefused = await portRefused(run.ports.engine);
    out.claimsAfter = run.claims();
    out.claimPidsAliveAfter = out.claimsAfter.map(n => /-(\d+)-[0-9a-f]{12}\./.exec(n)).filter(Boolean).map(m => Number(m[1])).filter(pidAlive);
    check('nothing alive 15 s after exit (the late broker and its engine ended themselves); stale claim files listed', exit !== null && out.pidsAlive15s.length === 0 && out.enginePortRefused && out.claimPidsAliveAfter.length === 0, { recordedPids: [...pids], diedAfterExitMs, aliveAt15s: out.pidsAlive15s, staleClaimFiles: out.claimsAfter.length, portRefused: out.enginePortRefused });
    out.quit = { exit: exit && { code: exit.code, signal: exit.signal }, startsAfterQuit: startsAfterQuit.length };
    out.pass = exit !== null && exit.code === 0 && S.list.every(s => s.ok !== false);
  },


  // 0.6.7 item 1: the broker is frozen with tests/debug_hold.py --mode freeze, so the shell's own wait runs out with the quit
  // dialog's ending state on screen the whole time. closureWaitSeconds in the QA policy changes the number shown.
  async 'quit-frozen'() { await frozenQuit({ origin: 'tray', waitSeconds: null }); },
  async 'quit-frozen-40'() { await frozenQuit({ origin: 'tray', waitSeconds: null, holdSeconds: 40 }); },
  async 'quit-frozen-12'() { await frozenQuit({ origin: 'menu', waitSeconds: 12 }); },

  // After a frozen-broker Quit (quit-frozen-12 leaves leftover-<owner>.json written by the SHELL, members null): what does the next start do?
  async 'next-start-after-frozen'() {
    const tmp = win(BASE + '/tmp');
    const roots = fs.readdirSync(tmp).filter(n => /^illuminati-cmo-qa-frz12-/.test(n)).map(n => ({ n, m: fs.statSync(path.win32.join(tmp, n)).mtimeMs })).sort((a, b) => b.m - a.m);
    const root = path.win32.join(tmp, roots[0].n);
    const info = { tmp, root, state: path.win32.join(root, 'state'), locks: path.win32.join(root, 'locks') };
    const before = fs.readdirSync(info.locks).filter(n => /^leftover-/.test(n)).map(n => fs.readFileSync(path.win32.join(info.locks, n), 'utf8').slice(0, 300));
    check('the QA root left by the frozen-broker quit holds a shell-written leftover record (members null)', before.length === 1 && /"members": ?null/.test(before[0]), { records: before.length, text: before[0] });
    await openPrev('nextStart', info);
    const settled = await waitFor(async () => { const st = await run.qa('state()', true); return (['ready', 'setup', 'failed'].includes(st.service)) && st; }, 'start outcome', 60000, 250);
    const page = await run.qa('page()', true);
    const after = fs.readdirSync(info.locks).filter(n => /^leftover-/.test(n));
    out.nextStart = { service: settled.service, failure: settled.failure || null, screen: page.url.replace(/:d+/, ':<port>').split('/').slice(-1)[0] || 'dashboard', recordsAfter: after.length, text: (page.text || '').replace(/s+/g, ' ').slice(0, 120) };
    check('next start after a frozen-broker Quit: normal start (no previous-session screen), the record is gone', settled.service === 'ready' && after.length === 0, out.nextStart);
    out.quit = await quitViaTray('after the normal start on the frozen-quit root');
    run.cleanup();
    out.pass = out.quit.exit && out.quit.exit.code === 0 && S.list.every(s => s.ok !== false);
  },

  // 0.6.7 item 2: the previous-session screens (P1 / P2 / P3), driven by a leftover record naming a live dummy process.
  async 'prev-session'() {
    const mk = async name => { const info = await makeRoot(name); emptyLibrary(info); return info; };
    const dummy = () => { const child = spawn(PY, ['-B', '-I', '-c', 'import time; time.sleep(3000)'], { windowsHide: true, stdio: 'ignore' }); child.exitedFlag = false; child.once('exit', () => { child.exitedFlag = true; }); return child; };
    const infoA = await mk('prevA'); out.infoA = infoA;
    const dummyA = dummy(); await sleep(600);
    const holdA = await hold(dummyA.pid, { mode: 'exit', locks: infoA.locks, age: 0 });
    check('dummy A held by tests/debug_hold.py; leftover record (age 0) written naming it', pidAlive(dummyA.pid) && Boolean(holdA.record) && fs.existsSync(holdA.record), { dummyPid: dummyA.pid, holdArgs: holdA.args.map(a => a.startsWith('I:') ? path.win32.basename(a) : a.includes('illuminati-cmo-qa') ? '<QA locks>' : a), record: holdA.record && path.win32.basename(holdA.record) });

    // ---- A1: first start with a live previous session -> P1; Try again x5; widths; Quit from P1 (page button)
    await openPrev('prevA1', infoA);
    const p1 = await waitClass('P1', 0);
    const s = p1.snap;
    out.p1 = { status: s.status.text, detail: s.detail.text, checked: s.checked.text, buttons: [s.retry.text, s.logs.text, s.quit.text], titles: [s.retry.title, s.logs.title, s.quit.title], rects: [s.retry.rect, s.logs.rect, s.quit.rect] };
    check('P1 (first start, record 0 s old): heading, detail, Checked at exact; buttons Try again / Open log folder / Quit in order, all enabled, tooltips exact', s.status.text === STR.head && s.detail.text === STR.p1 && /^Checked at .+\.$/.test(s.checked.text) && s.checked.hidden === false && s.retry.text === 'Try again' && s.logs.text === 'Open log folder' && s.quit.text === 'Quit' && [s.retry, s.logs, s.quit].every(b => !b.disabled && !b.hidden) && s.actions.hidden === false && s.retry.rect[0] < s.logs.rect[0] && s.logs.rect[0] < s.quit.rect[0] && s.retry.title === STR.tipTry && s.logs.title === STR.tipLogs && s.quit.title === STR.tipQuit, out.p1);
    const tl = await run.qa('trayLog');
    const lastImg = [...tl].reverse().find(r => r.type === 'image'), lastTip = [...tl].reverse().find(r => r.type === 'tip');
    out.p1Tray = { state: lastImg && trayStateOf(lastImg, out.expectedTray), tip: lastTip && lastTip.tip, menu: await run.qa('menuItems()') };
    check('P1 tray: error icon, label says the previous session is still closing, Quit enabled', out.p1Tray.state === 'error' && /Previous session still closing/.test(out.p1Tray.tip || '') && out.p1Tray.menu.find(i => i.label === '&Quit')?.enabled === true, out.p1Tray);
    await windowsClean('P1');
    const attempts = []; let prevChecked = s.checked.text;
    for (let i = 1; i <= 5; i++) {
      await sleep(1100);
      const tc = Date.now();
      await run.qa('clickRetry()', true);
      const p2 = await waitClass('P2', tc);
      const res = await waitClass(['P1', 'P3'], p2.t);
      const range = await mainSamples(tc - 20, res.t + 20);
      const blank = range.filter(x => x.snap.error || !x.snap.status || x.snap.status.text === '' || x.snap.file !== 'startup.html');
      const q = p2.snap;
      attempts.push({ i, p2Ms: res.t - p2.t, p2: { status: q.status.text, retryDisabled: q.retry.disabled, ariaBusy: q.retry.busy, retryText: q.retry.text, retryTitle: q.retry.title, detailVisibility: q.detail.vis, checkedVisibility: q.checked.vis, logsEnabled: !q.logs.disabled, quitEnabled: !q.quit.disabled }, resultClass: klass(res.snap), checked: res.snap.checked.text, changed: res.snap.checked.text !== prevChecked, blankSamples: blank.length, samplesInRange: range.length });
      prevChecked = res.snap.checked.text;
    }
    out.attempts = attempts;
    check('Try again x5 with the part alive: P2 on screen >= 0.5 s each time, Try again disabled with aria-busy and the same label, then P1 with a different time each time, no blank frame', attempts.every(a => a.p2Ms >= 450 && a.p2.status === STR.checking && a.p2.retryDisabled === true && a.p2.ariaBusy === 'true' && a.p2.retryText === 'Try again' && a.p2.retryTitle === STR.checking && a.p2.detailVisibility === 'hidden' && a.p2.checkedVisibility === 'hidden' && a.p2.logsEnabled && a.p2.quitEnabled && a.resultClass === 'P1' && a.changed && a.blankSamples === 0), { p2Ms: attempts.map(a => a.p2Ms), checked: attempts.map(a => a.checked), changed: attempts.map(a => a.changed), blank: attempts.map(a => a.blankSamples), note: 'sampler every ~25 ms; durations are good to about +/- 60 ms' });
    const cycles = [];
    for (const [label, expr, a60] of [['content 1280 px', 'setContentWidth(1280,800)', true], ['content 1000 px', 'setContentWidth(1000,700)', false], ['content 640 px', 'setContentWidth(640,700)', false], ['narrowest window, outer 640 px', 'setOuter(640,700)', false]]) cycles.push(await cycle(label, expr, a60));
    out.cycles = cycles;
    for (const c of cycles) {
      check('layout ' + c.label + ' (inner ' + c.iw + ' px): buttons do not move between P1, P2 and P3; each >= 40 px high; no sideways scroll; text and buttons stack without overlap', c.buttonsDoNotMove && c.minButtonHeight >= 40 && c.noSidewaysScroll && c.stackedWithoutOverlap, { buttonsDoNotMove: c.buttonsDoNotMove, minButtonHeight: c.minButtonHeight, noSidewaysScroll: c.noSidewaysScroll, stackedWithoutOverlap: c.stackedWithoutOverlap, retryY: c.retryY, detailHeight: c.detailHeight, p3DetailWraps: c.p3DetailWraps });
      check('P3 detail line at ' + c.label + ' does not wrap (a wrap would move the buttons: flag for Judy)', c.p3DetailWraps === false, { p3DetailWraps: c.p3DetailWraps, detailHeight: c.detailHeight, detailWidth: c.detailWidth, retryY: c.retryY });
    }
    check('record age 3 min shows P3 text; age 1 min shows P1 text (record rewritten between checks)', cycles.every(c => c.p3Class === 'P3') && cycles[0].age60Class === 'P1', { p3: cycles.map(c => c.p3Class), age60: cycles[0].age60Class, p3Text: cycles[0].p3Text });
    out.quitP1 = await quitFlow('P1 via the page Quit button', 'button');
    check('Quit in P1 (page button) ends the process within 1 s, exit 0', out.quitP1.exit && out.quitP1.exit.code === 0 && out.quitP1.clickToExitMs <= 1000 && out.quitP1.enginePortRefused, out.quitP1);
    check('the leftover record is still there after Quit (the next start re-checks it)', out.quitP1.locksAfter.some(n => /^leftover-/.test(n)), { locks: out.quitP1.locksAfter.length });

    // ---- A2: the next start still shows P1 while the dummy lives; Quit from the tray
    setAge(infoA, 0);
    await openPrev('prevA2', infoA);
    const a2 = await waitClass(['P1', 'P3'], 0);
    check('next start with the dummy still alive shows the previous-session screen again (P1)', klass(a2.snap) === 'P1', { klass: klass(a2.snap), checked: a2.snap.checked.text });
    out.quitP1tray = await quitFlow('P1 via the tray Quit', 'tray');
    check('Quit from the tray in P1 ends the process within 1 s, exit 0', out.quitP1tray.exit && out.quitP1tray.exit.code === 0 && out.quitP1tray.clickToExitMs <= 1000 && out.quitP1tray.enginePortRefused, out.quitP1tray);

    // ---- A3: Quit while P2 is on screen (Try again pressed, Quit 250 ms later)
    setAge(infoA, 0);
    await openPrev('prevA3', infoA);
    await waitClass('P1', 0);
    await run.qa("pageClickLater('quit',250)");
    await run.qa('clickRetry()', true);
    run.detach();
    const exit3 = await Promise.race([run.exited, sleep(30000).then(() => null)]);
    { const ev = run.readEvents(); const qc = ev.filter(e => e.kind === 'page-click').pop(), rc = ev.filter(e => e.kind === 'retry-click').pop();
      const ss = ev.filter(e => e.kind === 'sample' && e.index === 0 && e.snap && e.snap.file === 'startup.html');
      out.quitP2 = { exit: exit3 && { code: exit3.code, signal: exit3.signal }, clickToExitMs: exit3 && qc ? exit3.t - qc.t : null, retryToQuitMs: qc && rc ? qc.t - rc.t : null, p2BeforeQuit: ss.some(x => klass(x.snap) === 'P2' && x.t < qc.t), resultBeforeQuit: ss.some(x => ['P1', 'P3'].includes(klass(x.snap)) && x.snap.retry.disabled === false && x.t > rc.t && x.t < qc.t), p2SeenAtMs: (ss.find(x => klass(x.snap) === 'P2' && x.t > rc.t) || { t: null }).t - rc.t, quitClickAtMs: qc.t - rc.t, mainExitAfterQuitMs: ((ev.find(e => e.kind === 'main-exit' && e.t >= qc.t) || { t: null }).t) - qc.t };
      check('Quit pressed while P2 (Checking the previous session) was on screen ends the process within 1 s, exit 0', out.quitP2.exit && out.quitP2.exit.code === 0 && out.quitP2.p2BeforeQuit && !out.quitP2.resultBeforeQuit && out.quitP2.clickToExitMs <= 1000, out.quitP2); }
    run.cleanup();

    // ---- A4: the previous session really ends -> a normal start
    setAge(infoA, 0);
    await openPrev('prevA4', infoA);
    await waitClass(['P1', 'P3'], 0);
    dummyA.kill();   // TerminateProcess: the debugger holds the exit event, as a part still finishing a disk operation would
    await sleep(1500);
    check('dummy A was ended (TerminateProcess) but its exit is held by the debugger, so it still counts as running', dummyA.exitedFlag === false, { exitedFlag: dummyA.exitedFlag });
    const held = await retryAndWait(0, ['P1', 'P3']);
    check('Try again while the held part still runs: P2 then the previous-session screen again with a new time', klass(held.res.snap) === 'P1', { klass: klass(held.res.snap), checked: held.res.snap.checked.text });
    await holdA.release(); await sleep(1500);
    check('hold released: dummy A is gone', dummyA.exitedFlag === true, { exitedFlag: dummyA.exitedFlag });
    const tcN = Date.now();
    await run.qa('clickRetry()', true);
    await waitClass('P2', tcN);
    await waitFor(async () => { const pg = await run.qa('page()', true); return /setup\.html$/.test(pg.url) && pg.ready === 'complete'; }, 'setup page after the check passed', 60000);
    // every heading change, logged from inside the page by the observer (status-mut events), in order
    const phases = run.readEvents().filter(e => e.kind === 'status-mut' && e.t >= tcN).map(e => e.s);
    const leftoverNow = fs.readdirSync(infoA.locks).filter(n => /^leftover-/.test(n));
    out.normalStart = { phases, leftoverNow };
    check('after the dummy ended: Try again passes the check, the normal start phases run, the setup page opens, the leftover record is gone', phases.includes(STR.checking) && phases.some(t => /^(Starting the local service|Opening the comic catalog|Preparing the local service|Checking the comic library|Preparing the dashboard|Opening the dashboard|Opening setup)/.test(t)) && leftoverNow.length === 0, out.normalStart);
    await engineOwned('after the normal start');
    await setupLibrary(run, path.win32.join(infoA.root, 'library'));
    out.windowsDash = await windowsClean('dashboard after the normal start');
    out.quitNormal = await quitViaTray('normal start after a previous session', { staleClaimsOk: false });
    run.cleanup();

    // ---- B: a record already 3 min old at the first start (tool --age 180) -> P3 at once
    const infoB = await mk('prevB');
    const dummyB = dummy(); await sleep(600);
    const holdB = await hold(dummyB.pid, { mode: 'exit', locks: infoB.locks, age: 180 });
    check('dummy B held; leftover record written 180 s ago (--age 180)', pidAlive(dummyB.pid) && fs.existsSync(holdB.record), { dummyPid: dummyB.pid });
    await openPrev('prevB1', infoB);
    const b1 = await waitClass(['P1', 'P3'], 0);
    const bs = b1.snap;
    out.p3 = { klass: klass(bs), status: bs.status.text, detail: bs.detail.text, checked: bs.checked.text, titles: [bs.retry.title, bs.logs.title, bs.quit.title], buttons: [bs.retry.text, bs.logs.text, bs.quit.text] };
    check('P3 on the first start (--age 180): heading, the restart-your-PC detail, Checked at, buttons enabled, tooltips exact', klass(bs) === 'P3' && bs.status.text === STR.head && bs.detail.text === STR.p3 && /^Checked at .+\.$/.test(bs.checked.text) && [bs.retry, bs.logs, bs.quit].every(b => !b.disabled && !b.hidden) && bs.retry.title === STR.tipTry && bs.logs.title === STR.tipLogs && bs.quit.title === STR.tipQuit, out.p3);
    out.quitP3 = await quitFlow('P3 via the page Quit button', 'button');
    check('Quit in P3 (page button) ends the process within 1 s, exit 0', out.quitP3.exit && out.quitP3.exit.code === 0 && out.quitP3.clickToExitMs <= 1000 && out.quitP3.enginePortRefused, out.quitP3);
    await openPrev('prevB2', infoB);
    await waitClass('P3', 0);
    out.quitP3tray = await quitFlow('P3 via the tray Quit', 'tray');
    check('Quit from the tray in P3 ends the process within 1 s, exit 0', out.quitP3tray.exit && out.quitP3tray.exit.code === 0 && out.quitP3tray.clickToExitMs <= 1000 && out.quitP3tray.enginePortRefused, out.quitP3tray);
    await holdB.release(); dummyB.kill();
    out.pass = S.list.every(x => x.ok !== false);
  },
};

// 0.6.8 scenarios (new068.mjs) share this file's helpers and its current app run
const E = { S, out, check, must, emptyLibrary, startup, readyEngine, quitViaTray, windowsClean, hold, spawnPy, quitFlow, killBroker, fixtureState, scenarios, get run() { return run; }, set run(v) { run = v; } };
register(E);
registerDelta(E);

try {
  if (!scenarios[scenario]) throw new Error('unknown scenario');
  await scenarios[scenario]();
} catch (error) {
  out.error = String(error && error.stack || error).slice(0, 2000);
  S.record('ERROR', { ok: false, message: String(error && error.message) });
} finally {
  if (run) {
    out.stderrTail = run.stderr().slice(-1500);
    out.finalEvents = run.readEvents().slice(-12);
    if (run.exitInfo === null) { try { run.child.kill(); } catch { } await Promise.race([run.exited, sleep(5000)]); out.killedByHarness = true; }
    run.cleanup();
  }
  out.finished = new Date().toISOString();
  fs.writeFileSync(outFile, JSON.stringify(out, null, 2) + '\n');
  console.log(JSON.stringify({ scenario, pass: out.pass, error: out.error ? out.error.split('\n')[0] : null }));
  process.exit(out.pass ? 0 : 1);
}
