Futaba tray-QA harness for Comic Metadata, 0.6.8 revision (the 0.6.7 harness repointed, plus the 0.6.8 delta scenarios; emits the same promotion-schema
evidence that scripts/packaging/install-update-qa/create-local-promotion.mjs validates; field sets equal the 0.6.7 files: 74 / 35 / 17 leaf fields).

Everything runs under the studio's owned-process supervisor (owned-run.mjs / run-scenario.sh): a private kill-on-close Job per scenario, a private QA root
under a scratch TEMP, private engine, feed, model and inspector ports. No install, no focus, no mouse; QA mode refuses 8765 and 11434. The merge tool runs
with --live <scratch state> and --engine <the packaged engine> only; TEMP, LOCALAPPDATA and APPDATA are redirected into BASE/tmp.
Paths here are the 0.6.8 ones (futaba-068, rc-068, cmo-rc068, source-manifest-da503b3); for the next candidate change the version, hashes and folders in lib.mjs
(BASE, ARTIFACT, LATEST_YML, policy priorVersion/nextVersion), scenarios.mjs, new068.mjs/merge068.mjs/more068.mjs/c7_068.mjs (RC, TOOL, 9d1ad1a = the previous
version's commit for the older-engine and 0.6.7-dialog controls), assemble-promotion.cjs, validate-promotion.mjs, asar-check.cjs, collect-evidence.cjs, run-all.sh.

Layout: BASE/extract (whole payload), BASE/work (scratch: extraction-two, runs/, dom/), BASE/tmp (TEMP of every launched process and the private QA roots),
BASE/evidence (kept; harness/ is this folder).

Order for a release candidate
 1. Extract the installer twice with the pinned 7za under owned-run.mjs: extract-full-cfg.json, extract-two-cfg.json (exe + asar, the binding proof).
 2. node engine-vs-manifest.cjs <manifest> <extract>/resources/engine <out.json> ; node asar-check.cjs <rc worktree> <extract>/resources/app.asar <out.txt>
 3. Write work/tray-png-source-hashes.txt (the 8 desktop/assets/tray-*.png lines of the source manifest: "<path> <sha256>").
 4. bash run-all.sh   (every scenario below, one after another; console in work/runs/all.console.txt; results in work/runs/<tag>.result.json / .owned.json)
 5. node assemble-promotion.cjs    (the five -promotion files from the fPromo run; stops if the exe/asar/installer hashes disagree)
 6. node validate-promotion.mjs <smoke> <owned> <binding> <asar> [report.md]   (replays lines 57 to 64 of create-local-promotion.mjs + 12 negative controls)
 7. node collect-evidence.cjs      (copies the final results into evidence/ under versioned names, prints the SHA-256 table)

Scenarios (run one with: bash run-scenario.sh <scenario> <tag> [timeoutMs])
  promotion-smoke   the smoke evidence in the promotion schema (tray PNG hashes read by the running app, Pause/Resume callbacks, tray Quit)
  core              launch, tray, close button, ordinary pass over a library with nested-ComicInfo fixtures (incl. 0.6.8 q2: store dates, PageCount, case twin,
                    year-like Volume), Pause/Resume, Quit; afterwards nested_probe.py reads the archives and the catalog read-only; q2Verdict reads
                    data/removed-nested-copies.jsonl
  setup-quit, startup-quit, failed-screen   Quit from the setup, startup and failed screens (the failed screen is made by four outside broker ends)
  quit-frozen, quit-frozen-12   the broker frozen with tests/debug_hold.py --mode freeze for 2*wait+40 s, tray / File > Exit Quit; the sampler records the
                    dialog; c7Checks (c7_068.mjs) applies Judy's rev 3 checks C7 1, 2, 3, 5, 7, 9 to the live samples
  c7-dom            the packaged stopping.html/js/css (extracted from app.asar) and the 0.6.7 copy (git) fed states in harness-only offscreen windows: C7 3 (source),
                    5 (+ 0.6.7 positive control), 7, 8, 9, 10, 11
  c7-healthy        five healthy tray Quits from the ready dashboard (C7 4)
  c7-quitnow        Quit now (a DOM click in the dialog) during Pausing with the broker frozen (C7 6)
  q2-quit-cut       Q2: Quit's closing cap (QA policy closureWaitSeconds 2) cuts a large manual Approve off mid-write; next start recovers it (undone)
  q2-after-rename   Q2: the catalog write lock is held by the harness so the engine waits at its history insert after the rename; every process is ended; next
                    start records it (recorded; History, Kept backups)
  r1-readonly       R1: a read-only comic through Approve: not verified, backup listed Save not verified; positive control a writable comic
  merge-resume, merge-recover, merge-torn, merge-misc, merge-stopped, merge-killed-app   the merge tool on scratch fixture libraries: kill mid-run
                    (temporary file growing, or after the rename), --resume, --recover, zero bytes appended to journal.jsonl (.torn), --help, an older engine
                    (the 0.6.7 source files) refused, a real stopped merge (a reader holding the written archive with FILE_SHARE_READ), Kept backups
  q1-claims         q1: a genuine claim pair of a crashed engine made read-only + a shell-written leftover record starts normally; positive control: a held
                    lock shows the previous-session screen, Quit from it, Try again after release; edge probe: read-only locks without their .json records
  q3-late-exit      Q3: the first broker is frozen and its engine ended while the shell is starting; the start fails (START_UNRESPONSIVE), Retry starts a new broker
                    beside the frozen one, the old broker thaws and exits late; the new engine must stay ready (25 s watch); positive control: ending the
                    current broker still restarts the engine
Helpers: fixture.py (library + synthetic GCD index), fixture_approve.py, fixture_merge.py, pstree.py (descendants of a process), holdclaim.py (holds a claim
lock), holdshare.py (opens a file FILE_SHARE_READ only), nested_probe.py (read-only archive and catalog probe).
Not run in 0.6.8 (unchanged code, run in 0.6.7): prev-session, repro-064, quit-in-retry, next-start-after-frozen.

observer.cjs (injected on the first call frame of the packaged main process through the private inspector): 28 guards (window show/focus, app/web-contents
focus, notifications, dialogs, shell, every child_process API), real tray menu callbacks, tray bitmaps, a 40 ms sampler of every shell page, DOM clicks in the
main window and in the quit dialog, harness-only offscreen windows for DOM feeds.
Backslashes: write JSON/JS that contains them with a file-writing tool, not a shell heredoc. A record's creation-time integers exceed 2^53: edit such JSON as text.
