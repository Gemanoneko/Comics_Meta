"""Futaba 0.6.9 QA fixture for the nested-ComicInfo merge tool scenarios (packaged python, -B -I). Touches only the QA root on the
command line: a scratch library of four archives that each hold a root ComicInfo.xml and exactly one nested ComicInfo.xml (the
second one large, so a stop can land inside its write), a config naming that library, and a scanned catalog.
Mode 'plain' (as the 0.6.8 fixture): the root holds only Series and Number.
Mode 'r7': the root also holds a Summary of its own, and the nested copy holds a different Summary with line breaks, a comma and quotes,
so the tool's dropped-nested-values.csv gets a row whose quoted value spans several lines (root wins) plus the Year row.
Usage: fixture_merge69.py <qa root> <library> <big_mb> [plain|r7]"""
import hashlib
import json
import os
import sys
import zipfile
from pathlib import Path

root, library, big_mb = Path(sys.argv[1]), Path(sys.argv[2]), int(sys.argv[3])
mode = sys.argv[4] if len(sys.argv) > 4 else 'plain'
state = root / 'state'
if Path(os.environ.get('COMICS_META_STATE_ROOT', '')) != state or not root.name.startswith('illuminati-cmo-qa-'):
    raise SystemExit('Refusing: COMICS_META_STATE_ROOT must equal the QA root state folder')
import app

library.mkdir(parents=True, exist_ok=True)
state.mkdir(parents=True, exist_ok=True)
(state / 'config.json').write_text(json.dumps({'automatic': {'library_root': str(library), 'root': str(library), 'enabled': False},
    'sources': {'disabled': ['ComicVine', 'Metron', 'Google Lens', 'Google Books', 'GCD', 'Dark Horse', 'Open Library local index', 'General free web', 'Wikipedia/wiki', 'Saved lead re-checks', 'GetComics', 'PREVIEWSworld', 'Publisher web'], 'enabled': []},
    'in_book': {'cover': False, 'publisher_agreement': False, 'credits_pages': False}, 'browser_search': {'enabled': False, 'lens': False}}), encoding='utf-8')

if mode == 'r7':
    ROOT = '<?xml version="1.0"?><ComicInfo><Series>Merge QA Series</Series><Number>%d</Number><Summary>Root summary %d.</Summary></ComicInfo>'
    NESTED = ('<?xml version="1.0"?><ComicInfo><Series>Merge QA Series</Series><Number>%d</Number>'
              '<Summary>Nested line one %d, with a comma.\nLine two says "quoted words" and, more commas.\nLine three %d ends here.</Summary>'
              '<Writer>Nested Writer %d</Writer><Genre>Nested Genre</Genre><Year>2019</Year></ComicInfo>')
else:
    ROOT = '<?xml version="1.0"?><ComicInfo><Series>Merge QA Series</Series><Number>%d</Number></ComicInfo>'
    NESTED = ('<?xml version="1.0"?><ComicInfo><Series>Merge QA Series</Series><Number>%d</Number><Summary>Nested summary %d.</Summary>'
              '<Writer>Nested Writer %d</Writer><Genre>Nested Genre</Genre><Year>2019</Year></ComicInfo>')
files = {}
for number, (letter, mb) in enumerate((('A', 0), ('B', big_mb), ('C', 0), ('D', 0)), 1):
    path = library / ('Merge %s %03d (2020).cbz' % (letter, number))
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=1) as archive:
        archive.writestr('Scans/page001.bin', os.urandom(4096))
        for index in range(mb // 12):
            archive.writestr('Scans/big%03d.bin' % index, os.urandom(12 * 1024 * 1024))
        if mode == 'r7':
            archive.writestr('Scans/ComicInfo.xml', NESTED % (number, number, number, number))
            archive.writestr('ComicInfo.xml', ROOT % (number, number))
        else:
            archive.writestr('Scans/ComicInfo.xml', NESTED % (number, number, number))
            archive.writestr('ComicInfo.xml', ROOT % number)
    files[path.name] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'size': path.stat().st_size}
app.scan([str(library)], recursive=True)
with app.db() as con:
    rows = con.execute('SELECT COUNT(*) FROM comics').fetchone()[0]
print(json.dumps({'prepared': True, 'mode': mode, 'library': str(library), 'files': files, 'catalogRows': rows}))
